# Templates Email MailerLite - Date Mature

## Vue d'ensemble

Ces templates HTML sont prêts à être copiés-collés dans vos automations MailerLite pour Date Mature.

## Configuration des Automations

### 1. Flash Reçu
- **Fichier**: `flash-received.html`
- **Sujet**: 💕 Quelqu'un s'intéresse à vous sur Date Mature !
- **Déclencheur**: Groupe `Flash Received` rejoint
- **Design**: Rose/Rouge (#e11d48) - Amour, romance

### 2. Nouveau Match
- **Fichier**: `new-match.html`
- **Sujet**: 🎉 C'est un match sur Date Mature !
- **Déclencheur**: Groupe `New Match` rejoint
- **Design**: Orange (#ea580c) - Énergie, célébration

### 3. Bienvenue Premium
- **Fichier**: `premium-welcome.html`
- **Sujet**: ✅ Bienvenue dans la communauté Premium Date Mature !
- **Déclencheur**: Groupe `Premium subscribers` rejoint
- **Design**: Vert (#059669) - Succès, Premium

## Étapes de Configuration dans MailerLite

1. **Connectez-vous à MailerLite**
2. **Allez dans Automations → Create workflow**
3. **Pour chaque automation** :
   - Créez un nouveau workflow
   - Choisissez le déclencheur "When subscriber joins group(s)"
   - Sélectionnez le groupe correspondant (voir ci-dessous)
   - Ajoutez une action "Send email"
   - Copiez-collez le HTML du fichier correspondant
   - Configurez le sujet
   - Activez l'automation

## Groupes MailerLite Requis

Créez ces groupes dans MailerLite (ils seront automatiquement créés par l'app si ils n'existent pas) :

- **Flash Received** - Pour les notifications de flash
- **New Match** - Pour les notifications de match
- **Premium subscribers** - Pour les bienvenues Premium
- **Gold subscribers** - Pour les bienvenues Gold (optionnel)
- **Newsletter prospects (popup)** - Pour la newsletter
- **Membres actifs (utilisateurs inscrits)** - Pour tous les utilisateurs

## Variables MailerLite

Les templates utilisent la variable `{$name}` qui sera automatiquement remplacée par le prénom du destinataire dans MailerLite.

## Design

- **Mobile-friendly**: Optimisé pour les seniors sur mobile
- **Lisibilité élevée**: Polices grandes, contrastes élevés
- **Call-to-actions clairs**: Boutons visibles et explicites
- **Branding cohérent**: Logo et couleurs Date Mature

## Validation

Une fois les automations configurées, testez avec vos propres emails :
- Faites un paiement → Email Premium automatique
- Simulez un flash → Email Flash automatique  
- Simulez un match → Email Match automatique

## Support

Votre système de segmentation automatique fonctionne parfaitement. Les contacts sont créés avec les bons tags à chaque action utilisateur. Les automations MailerLite se déclencheront automatiquement.