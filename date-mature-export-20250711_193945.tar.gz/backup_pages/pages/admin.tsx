import { useQuery, useMutation } from "@tanstack/react-query";
import { Shield, Users, Heart, Crown, Zap, RefreshCw, Trash2, LogOut } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function Admin() {
  const { toast } = useToast();

  // Get admin stats
  const { data: statsData } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const stats = (statsData as any) || {
    totalUsers: 0,
    totalMatches: 0,
    premiumUsers: 0,
    goldUsers: 0,
    dailyFlashesAverage: 0
  };

  // Generate test profiles mutation
  const generateProfilesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/admin/generate-profiles", {});
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Profils générés",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de générer les profils",
        variant: "destructive",
      });
    },
  });

  // Delete test profiles mutation
  const deleteProfilesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/admin/test-profiles", {});
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Profils supprimés",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de supprimer les profils",
        variant: "destructive",
      });
    },
  });

  // Get all users
  const { data: usersData } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const users = (usersData as any[]) || [];

  return (
    <div className="h-screen flex flex-col bg-gray-100">
      {/* Admin Header */}
      <div className="bg-gray-800 text-white p-6 flex items-center justify-between">
        <div className="flex items-center">
          <Shield className="h-6 w-6 mr-3" />
          <h2 className="text-xl font-semibold">Administration</h2>
        </div>
        <Button 
          variant="destructive"
          size="sm"
          onClick={() => window.location.href = "/"}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Déconnexion
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Statistics Cards */}
        <div className="p-6 grid grid-cols-2 gap-4">
          <Link href="/admin/users">
            <Card className="cursor-pointer hover:shadow-md transition-shadow duration-200 hover:bg-gray-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                  <Users className="h-4 w-4 mr-2 text-blue-500" />
                  Utilisateurs inscrits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-800">{stats.totalUsers}</div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/admin/users?tab=matches">
            <Card className="cursor-pointer hover:shadow-md transition-shadow duration-200 hover:bg-gray-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                  <Heart className="h-4 w-4 mr-2 text-red-500" />
                  Matches créés
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-800">{stats.totalMatches}</div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/admin/users?subscription=premium">
            <Card className="cursor-pointer hover:shadow-md transition-shadow duration-200 hover:bg-gray-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                  <Crown className="h-4 w-4 mr-2 text-purple-500" />
                  Utilisateurs Premium
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-800">{stats.premiumUsers}</div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/admin/users?subscription=gold">
            <Card className="cursor-pointer hover:shadow-md transition-shadow duration-200 hover:bg-gray-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                  <Crown className="h-4 w-4 mr-2 text-yellow-500" />
                  Utilisateurs Gold
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-800">{stats.goldUsers}</div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Daily Flash Stats */}
        <div className="px-6 pb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Zap className="h-4 w-4 mr-2 text-orange-500" />
                Flashs quotidiens moyens
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-800">{stats.dailyFlashesAverage}</div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Actions */}
        <div className="px-6 pb-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Actions d'administration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                className="w-full flex items-center justify-between text-left p-4 h-auto"
                variant="outline"
                onClick={() => generateProfilesMutation.mutate()}
                disabled={generateProfilesMutation.isPending}
              >
                <div className="flex items-center">
                  <RefreshCw className={`h-5 w-5 text-blue-500 mr-4 ${generateProfilesMutation.isPending ? 'animate-spin' : ''}`} />
                  <div>
                    <div className="font-medium">Générer profils de test</div>
                    <div className="text-sm text-gray-500">Créer de nouveaux profils de seniors</div>
                  </div>
                </div>
              </Button>
              
              <Link href="/admin/users">
                <Button
                  className="w-full flex items-center justify-between text-left p-4 h-auto"
                  variant="outline"
                >
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-green-500 mr-4" />
                    <div>
                      <div className="font-medium">Gérer les utilisateurs</div>
                      <div className="text-sm text-gray-500">Créer et modifier les profils</div>
                    </div>
                  </div>
                </Button>
              </Link>

              <Button
                className="w-full flex items-center justify-between text-left p-4 h-auto border-red-200 hover:bg-red-50"
                variant="outline"
                onClick={() => {
                  if (confirm("Êtes-vous sûr de vouloir supprimer tous les profils de test ?")) {
                    deleteProfilesMutation.mutate();
                  }
                }}
                disabled={deleteProfilesMutation.isPending}
              >
                <div className="flex items-center">
                  <Trash2 className="h-5 w-5 text-red-500 mr-4" />
                  <div>
                    <div className="font-medium text-red-600">Supprimer tous les profils de test</div>
                    <div className="text-sm text-gray-500">Action irréversible</div>
                  </div>
                </div>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* User Management */}
        <div className="px-6 pb-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Gestion des utilisateurs ({users.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {users.slice(0, 10).map((user: any) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-purple-600">
                          {user.firstName?.charAt(0) || '?'}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-sm">
                          {user.firstName} {user.lastName} ({user.age} ans)
                        </div>
                        <div className="text-xs text-gray-500">
                          {user.city} • {user.subscription}
                          {user.email?.includes('example.com') && ' • Test'}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {user.subscription === 'premium' && (
                        <Crown className="w-4 h-4 text-purple-500" />
                      )}
                      {user.subscription === 'gold' && (
                        <Crown className="w-4 h-4 text-yellow-500" />
                      )}
                    </div>
                  </div>
                ))}
                {users.length > 10 && (
                  <div className="text-center py-2 text-sm text-gray-500">
                    ... et {users.length - 10} autres utilisateurs
                  </div>
                )}
                {users.length === 0 && (
                  <div className="text-center py-4 text-gray-500">
                    Aucun utilisateur trouvé
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
