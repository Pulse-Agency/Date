import { useEffect, useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Crown, Star, CreditCard, Shield, Lock, AlertCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const CheckoutForm = ({ 
  plan, 
  amount, 
  promoCode,
  setPromoCode,
  promoDiscount,
  setPromoDiscount,
  promoApplied,
  setPromoApplied,
  setAmount,
  originalAmount
}: { 
  plan: string; 
  amount: number;
  promoCode: string;
  setPromoCode: (code: string) => void;
  promoDiscount: number;
  setPromoDiscount: (discount: number) => void;
  promoApplied: boolean;
  setPromoApplied: (applied: boolean) => void;
  setAmount: (amount: number) => void;
  originalAmount: number;
}) => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [cartCreated, setCartCreated] = useState(false);

  const validatePromoCode = async () => {
    if (!promoCode.trim()) {
      toast({
        title: "Code requis",
        description: "Veuillez saisir un code promo",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch('/api/promo/validate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          code: promoCode,
          plan: plan.toLowerCase() 
        }),
      });

      const data = await response.json();

      if (data.valid) {
        setPromoDiscount(data.discountPercent);
        setAmount(data.discountedPrice);
        setPromoApplied(true);
        toast({
          title: "Code promo appliqué !",
          description: `Réduction de ${data.discountPercent}% appliquée`,
        });
      } else {
        toast({
          title: "Code invalide",
          description: "Ce code promo n'est pas valide ou a expiré",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de valider le code promo",
        variant: "destructive",
      });
    }
  };

  const removePromoCode = () => {
    setPromoCode('');
    setPromoDiscount(0);
    setAmount(originalAmount);
    setPromoApplied(false);
  };

  // Créer un panier abandonné si l'utilisateur reste sur la page plus de 30 secondes
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (!cartCreated) {
        try {
          // Simulation d'un userId (dans un vrai cas, on récupérerait l'utilisateur connecté)
          const userId = Math.floor(Math.random() * 1000) + 1;
          const planName = plan.toLowerCase();
          
          await fetch('/api/abandoned-cart/create', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
              userId, 
              plan: planName === 'gold' ? 'gold' : 'premium' 
            }),
          });
          
          setCartCreated(true);
          console.log('Panier abandonné créé');
        } catch (error) {
          console.error('Erreur création panier abandonné:', error);
        }
      }
    }, 30000); // 30 secondes

    return () => clearTimeout(timer);
  }, [plan, cartCreated]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Validation basique
    if (!cardNumber || !expiryDate || !cvc || !name || !email) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir tous les champs.",
        variant: "destructive",
      });
      setIsProcessing(false);
      return;
    }

    // Simulation du paiement
    setTimeout(() => {
      if (cardNumber === '4242 4242 4242 4242' || cardNumber === '4242424242424242') {
        toast({
          title: "Paiement réussi !",
          description: `Bienvenue dans ${plan} ! Votre abonnement est maintenant actif.`,
        });
        setLocation("/home");
      } else {
        toast({
          title: "Erreur de paiement",
          description: "Utilisez la carte test : 4242 4242 4242 4242",
          variant: "destructive",
        });
      }
      setIsProcessing(false);
    }, 2000);
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="votre.email@exemple.com"
            className="text-lg py-3"
            required
          />
        </div>

        <div>
          <Label htmlFor="name">Nom complet</Label>
          <Input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Jean Dupont"
            className="text-lg py-3"
            required
          />
        </div>

        <div>
          <Label htmlFor="cardNumber" className="flex items-center space-x-2">
            <CreditCard className="h-4 w-4" />
            <span>Numéro de carte</span>
          </Label>
          <Input
            id="cardNumber"
            type="text"
            value={cardNumber}
            onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
            placeholder="4242 4242 4242 4242"
            maxLength={19}
            className="text-lg py-3 font-mono"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="expiryDate">Date d'expiration</Label>
            <Input
              id="expiryDate"
              type="text"
              value={expiryDate}
              onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
              placeholder="MM/AA"
              maxLength={5}
              className="text-lg py-3 font-mono"
              required
            />
          </div>
          <div>
            <Label htmlFor="cvc">CVC</Label>
            <Input
              id="cvc"
              type="text"
              value={cvc}
              onChange={(e) => setCvc(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))}
              placeholder="123"
              maxLength={3}
              className="text-lg py-3 font-mono"
              required
            />
          </div>
        </div>
      </div>

      {/* Code promo discret */}
      <div className="border-t pt-4">
        {!promoApplied ? (
          <div className="flex items-center space-x-2">
            <Label htmlFor="promo" className="text-sm text-gray-600 min-w-fit">Code promo :</Label>
            <Input
              id="promo"
              type="text"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              placeholder="(optionnel)"
              className="flex-1 h-9 text-sm"
            />
            <Button 
              type="button"
              onClick={validatePromoCode}
              variant="outline"
              size="sm"
              className="h-9 px-3 text-sm"
            >
              OK
            </Button>
          </div>
        ) : (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm font-medium text-green-800">Code appliqué: {promoCode}</span>
              </div>
              <Button 
                type="button"
                onClick={removePromoCode}
                variant="ghost" 
                size="sm"
                className="text-green-700 hover:text-green-900 h-6 px-2 text-xs"
              >
                Retirer
              </Button>
            </div>
            <p className="text-xs text-green-700 mt-1">
              Réduction de {promoDiscount}% appliquée
            </p>
          </div>
        )}
      </div>
      
      <Button 
        type="submit" 
        disabled={isProcessing}
        className="w-full py-4 text-lg font-semibold bg-primary hover:bg-primary/90"
      >
        {isProcessing ? (
          <div className="flex items-center space-x-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            <span>Traitement...</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <Lock className="h-4 w-4" />
            <span>Payer {amount}€/mois</span>
          </div>
        )}
      </Button>
      
      <div className="space-y-2 text-center">
        <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
          <Shield className="h-4 w-4" />
          <span>Paiement sécurisé SSL</span>
        </div>
        <p className="text-xs text-gray-400 px-4">
          Abonnement {plan === 'Gold' ? '12 mois' : '6 mois'} renouvelable. 
          Résiliation possible à tout moment depuis votre profil.
        </p>
      </div>
    </form>
  );
};

export default function Checkout() {
  const [plan, setPlan] = useState("Premium");
  const [amount, setAmount] = useState(10);
  const [originalAmount, setOriginalAmount] = useState(10);
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoApplied, setPromoApplied] = useState(false);
  const [billingType, setBillingType] = useState('annual');
  const { toast } = useToast();

  const validatePromoCode = async () => {
    if (!promoCode.trim()) {
      toast({
        title: "Code requis",
        description: "Veuillez saisir un code promo",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch('/api/promo/validate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          code: promoCode,
          plan: plan.toLowerCase() 
        }),
      });

      const data = await response.json();

      if (data.valid) {
        setPromoDiscount(data.discountPercent);
        setAmount(data.discountedPrice);
        setPromoApplied(true);
        toast({
          title: "Code promo appliqué !",
          description: `Réduction de ${data.discountPercent}% appliquée`,
        });
      } else {
        toast({
          title: "Code invalide",
          description: "Ce code promo n'est pas valide ou a expiré",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de valider le code promo",
        variant: "destructive",
      });
    }
  };

  const removePromoCode = () => {
    setPromoCode('');
    setPromoDiscount(0);
    setAmount(originalAmount);
    setPromoApplied(false);
  };

  useEffect(() => {
    // Récupérer les paramètres depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const planParam = urlParams.get('plan');
    const billingParam = urlParams.get('billing');
    
    if (planParam === 'gold') {
      setPlan('Gold');
      if (billingParam === 'monthly') {
        setAmount(25);
        setOriginalAmount(25);
        setBillingType('monthly');
      } else {
        setAmount(19);
        setOriginalAmount(19);
        setBillingType('annual');
      }
    } else {
      setPlan('Premium');
      if (billingParam === 'monthly') {
        setAmount(13);
        setOriginalAmount(13);
        setBillingType('monthly');
      } else {
        setAmount(10);
        setOriginalAmount(10);
        setBillingType('annual');
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-purple-600 text-white p-6 flex items-center">
        <Link href="/subscription">
          <Button variant="ghost" size="sm" className="mr-4 text-white hover:bg-white/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h2 className="text-xl font-semibold">Finaliser mon abonnement</h2>
      </div>

      <div className="max-w-md mx-auto p-6 space-y-6">
        {/* Plan Summary */}
        <Card className={`border-2 ${plan === 'Gold' ? 'border-yellow-400' : 'border-purple-300'}`}>
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {plan === 'Gold' ? (
                  <Crown className="h-6 w-6 text-yellow-500" />
                ) : (
                  <Star className="h-6 w-6 text-purple-500" />
                )}
                <CardTitle className="text-xl">{plan}</CardTitle>
              </div>
              <div className="text-right">
                {promoApplied && (
                  <div className="mb-1">
                    <span className="text-sm text-gray-400 line-through">{originalAmount}€</span>
                    <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                      -{promoDiscount}%
                    </span>
                  </div>
                )}
                <span className="text-2xl font-bold text-gray-800">{amount}€</span>
                <p className="text-sm text-gray-500">/mois</p>
                <p className="text-xs text-gray-400">
                  {billingType === 'monthly' ? 'Facturation mensuelle' : 
                   plan === 'Gold' ? 'Engagement 12 mois' : 'Engagement 6 mois'}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              {plan === 'Gold' ? 
                'Flashs illimités, navigation invisible, mise en avant profil et événements VIP' :
                '5 flashs par jour, conversations illimitées et support prioritaire'
              }
            </p>
          </CardContent>
        </Card>



        {/* Payment Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Informations de paiement</CardTitle>
          </CardHeader>
          <CardContent>
            <CheckoutForm 
              plan={plan} 
              amount={amount} 
              promoCode={promoCode}
              setPromoCode={setPromoCode}
              promoDiscount={promoDiscount}
              setPromoDiscount={setPromoDiscount}
              promoApplied={promoApplied}
              setPromoApplied={setPromoApplied}
              setAmount={setAmount}
              originalAmount={originalAmount}
            />
          </CardContent>
        </Card>

        {/* Engagement Warning */}
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-orange-600 mt-0.5" />
              <div className="text-sm">
                <h3 className="font-semibold text-orange-800 mb-1">Engagement contractuel</h3>
                <p className="text-orange-700">
                  Cet abonnement vous engage pour une durée de {plan === 'Gold' ? '12 mois' : '6 mois'}. 
                  L'annulation ne sera possible qu'à la fin de cette période. 
                  Le montant total de {plan === 'Gold' ? '228€' : '60€'} est dû immédiatement.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>


      </div>
    </div>
  );
}