import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { Heart, Camera, ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import PhotoUpload from "@/components/photo-upload";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertUserSchema } from "@shared/schema";
import { trackDateMatureEvents } from "@/lib/analytics";

const onboardingSchema = z.object({
  email: z.string().email("Veuillez saisir un email valide"),
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères"),
  gender: z.enum(["H", "F"], { required_error: "Veuillez sélectionner votre genre" }),
  age: z.number().min(40, "L'âge doit être entre 40 et 75 ans").max(75, "L'âge doit être entre 40 et 75 ans"),
  city: z.string().min(2, "La ville doit contenir au moins 2 caractères"),
  bio: z.string().optional(),
  interests: z.array(z.string()).default([]),
  photo: z.string().url().optional(),
  subscription: z.literal("gratuit").default("gratuit"),
});

type OnboardingData = z.infer<typeof onboardingSchema>;

const interests = [
  "Randonnée", "Cuisine", "Jardinage", "Lecture", "Voyages", "Musique",
  "Cinéma", "Peinture", "Photographie", "Danse", "Théâtre", "Bridge",
  "Marche", "Natation", "Yoga", "Tricot", "Pétanque", "Cyclisme",
  "Bricolage", "Histoire", "Art", "Nature", "Animaux", "Bénévolat"
];

export default function Onboarding() {
  const [step, setStep] = useState(0);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [selectedPhoto, setSelectedPhoto] = useState<string>("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<OnboardingData>({
    resolver: zodResolver(onboardingSchema),
    defaultValues: {
      email: "",
      firstName: "",
      gender: undefined,
      age: 45,
      city: "",
      bio: "",
      interests: [],
      subscription: "gratuit",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: OnboardingData) => {
      const response = await apiRequest("POST", "/api/auth/register", data);
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Profil créé avec succès:", data);
      toast({
        title: "Profil créé avec succès !",
        description: "Bienvenue sur Date Mature",
      });
      // Invalider le cache pour forcer le rechargement de l'utilisateur connecté
      queryClient.invalidateQueries({ queryKey: ["/api/users/current"] });
      // Attendre un peu avant de rediriger pour laisser le temps à la session de se sauvegarder
      setTimeout(() => {
        setLocation("/");
      }, 1500);
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de créer le profil",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: OnboardingData) => {
    // Empêcher les doubles soumissions
    if (registerMutation.isPending) return;
    
    const finalData = {
      ...data,
      interests: selectedInterests,
      photo: data.photo || selectedPhoto || `https://randomuser.me/api/portraits/men/${Math.floor(Math.random() * 100)}.jpg`,
    };
    
    console.log('Soumission profil:', finalData);
    
    // Tracking Google Analytics - Inscription utilisateur
    trackDateMatureEvents.signUp('onboarding_form');
    
    registerMutation.mutate(finalData);
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterests(prev => 
      prev.includes(interest) 
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  const steps = [
    {
      title: "Bienvenue sur Date Mature",
      content: (
        <div className="text-center">
          <Heart className="h-16 w-16 text-primary mx-auto mb-6" />
          <h1 className="text-xl md:text-3xl font-bold text-gray-800 mb-4">Date Mature</h1>
          <p className="text-sm md:text-lg text-gray-600 leading-relaxed mb-6">
            L'application de rencontre pensée pour vous, adultes matures de 40 à 75 ans
          </p>
          
          <div className="space-y-6">
            <div className="bg-pink-50 p-4 md:p-6 rounded-2xl border border-pink-100">
              <Heart className="h-6 w-6 md:h-8 md:w-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold text-base md:text-lg mb-2">Profils vérifiés</h3>
              <p className="text-gray-600 text-sm md:text-base">Rencontrez des personnes de votre âge dans votre région</p>
            </div>
            
            <div className="bg-orange-50 p-4 md:p-6 rounded-2xl border border-orange-100">
              <Heart className="h-6 w-6 md:h-8 md:w-8 text-secondary mx-auto mb-3" />
              <h3 className="font-semibold text-base md:text-lg mb-2">Messagerie sécurisée</h3>
              <p className="text-gray-600 text-sm md:text-base">Discutez uniquement avec vos compatibilités</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Informations personnelles",
      content: (
        <div className="space-y-6">
          <div className="text-center">
            <PhotoUpload
              currentPhoto={selectedPhoto}
              onPhotoSelected={(photoUrl) => {
                setSelectedPhoto(photoUrl);
                form.setValue('photo', photoUrl);
              }}
              className="mx-auto"
            />
            <p className="text-sm text-gray-600 mt-2">
              Ajoutez une photo pour augmenter vos chances de rencontres
            </p>
          </div>
          
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg font-medium">Email</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="votre.email@exemple.com" 
                      className="text-lg p-4" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg font-medium">Prénom</FormLabel>
                  <FormControl>
                    <Input placeholder="Votre prénom" className="text-lg p-4" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="gender"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg font-medium">Genre</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="text-lg p-4">
                        <SelectValue placeholder="Sélectionnez votre genre" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="H">Homme</SelectItem>
                      <SelectItem value="F">Femme</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="age"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg font-medium">Âge</FormLabel>
                  <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                    <FormControl>
                      <SelectTrigger className="text-lg p-4">
                        <SelectValue placeholder="Sélectionnez votre âge" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Array.from({ length: 36 }, (_, i) => i + 40).map(age => (
                        <SelectItem key={age} value={age.toString()}>
                          {age} ans
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg font-medium">Ville</FormLabel>
                  <FormControl>
                    <Input placeholder="Votre ville" className="text-lg p-4" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      )
    },
    {
      title: "Parlez-nous de vous",
      content: (
        <div className="space-y-6">
          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg font-medium">Bio (200 caractères max)</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Parlez-nous de vous..." 
                    rows={4} 
                    className="text-lg p-4 resize-none"
                    maxLength={200}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div>
            <Label className="text-lg font-medium mb-4 block">Centres d'intérêt</Label>
            <div className="grid grid-cols-2 gap-3">
              {interests.map((interest) => (
                <Button
                  key={interest}
                  type="button"
                  variant={selectedInterests.includes(interest) ? "default" : "outline"}
                  className={`p-4 text-left justify-start ${
                    selectedInterests.includes(interest) 
                      ? "bg-primary text-white" 
                      : "bg-gray-100 hover:bg-primary hover:text-white"
                  }`}
                  onClick={() => toggleInterest(interest)}
                >
                  {interest}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen w-full flex flex-col">
      {/* Header */}
      <div className="bg-primary text-white p-6 flex items-center">
        {step > 0 && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="mr-4 text-white hover:bg-white/20"
            onClick={() => setStep(step - 1)}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}
        <h2 className="text-xl font-semibold">{steps[step].title}</h2>
      </div>

      {/* Progress Bar */}
      <div className="bg-gray-200 h-2">
        <div 
          className="bg-primary h-full transition-all duration-300"
          style={{ width: `${((step + 1) / steps.length) * 100}%` }}
        />
      </div>

      {/* Content */}
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex-1 flex flex-col">
          <div className="flex-1 p-4 md:p-6 overflow-y-auto">
            {steps[step].content}
          </div>

          {/* Footer */}
          <div className="p-4 md:p-6 border-t border-gray-200">
            {step < steps.length - 1 ? (
              <Button
                type="button"
                className="w-full py-3 md:py-4 text-base md:text-lg font-semibold"
                onClick={(e) => {
                  e.preventDefault();
                  setStep(step + 1);
                }}
              >
                Continuer
                <ArrowRight className="h-4 w-4 md:h-5 md:w-5 ml-2" />
              </Button>
            ) : (
              <Button
                type="submit"
                className="w-full py-4 text-lg font-semibold"
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? "Création en cours..." : "Finaliser mon profil"}
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}
