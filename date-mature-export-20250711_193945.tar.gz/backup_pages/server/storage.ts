import { 
  users, 
  flashes, 
  matches, 
  messages, 
  notifications,
  referrals,
  abandonedCarts,
  type User, 
  type InsertUser, 
  type Flash, 
  type InsertFlash, 
  type Match, 
  type Message, 
  type InsertMessage,
  type Notification,
  type Referral,
  type InsertReferral,
  type AbandonedCart,
  type InsertAbandonedCart
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, gte, lte, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(excludeTestProfiles?: boolean): Promise<User[]>;
  getTestProfiles(): Promise<User[]>;
  deleteTestProfiles(): Promise<void>;
  
  // Flash methods
  createFlash(flash: InsertFlash): Promise<Flash>;
  getFlashsBetweenUsers(user1Id: number, user2Id: number): Promise<Flash[]>;
  getUserFlashesCount(userId: number, date: Date): Promise<number>;
  
  // Match methods
  createMatch(user1Id: number, user2Id: number): Promise<Match>;
  getUserMatches(userId: number): Promise<Match[]>;
  checkMatch(user1Id: number, user2Id: number): Promise<Match | undefined>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getConversationMessages(user1Id: number, user2Id: number): Promise<Message[]>;
  markMessagesAsRead(senderId: number, receiverId: number): Promise<void>;
  
  // Notification methods
  createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<void>;
  
  // Referral methods
  generateReferralCode(userId: number): Promise<string>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  getUserReferrals(userId: number): Promise<Referral[]>;
  processReferralReward(referralId: number): Promise<void>;
  applyReferralBonus(userId: number, bonusType: string, amount: number): Promise<void>;
  
  // Admin methods
  getStats(): Promise<{
    totalUsers: number;
    totalMatches: number;
    premiumUsers: number;
    goldUsers: number;
    dailyFlashesAverage: number;
  }>;
  
  // Abandoned cart methods
  createAbandonedCart(cart: InsertAbandonedCart): Promise<AbandonedCart>;
  getAbandonedCartsByUser(userId: number): Promise<AbandonedCart[]>;
  getAbandonedCartsForReminder(): Promise<AbandonedCart[]>;
  updateAbandonedCart(id: number, updates: Partial<AbandonedCart>): Promise<AbandonedCart | undefined>;
  validateDiscountCode(code: string): Promise<{valid: boolean; cart?: AbandonedCart}>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private flashes: Map<number, Flash> = new Map();
  private matches: Map<number, Match> = new Map();
  private messages: Map<number, Message> = new Map();
  private notifications: Map<number, Notification> = new Map();
  private referrals: Map<number, Referral> = new Map();
  private abandonedCarts: Map<number, AbandonedCart> = new Map();
  private currentUserId = 1;
  private currentFlashId = 1;
  private currentMatchId = 1;
  private currentMessageId = 1;
  private currentNotificationId = 1;
  private currentReferralId = 1;
  private currentAbandonedCartId = 1;

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.currentUserId++,
      firstName: insertUser.firstName,
      age: insertUser.age,
      city: insertUser.city,
      bio: insertUser.bio || null,
      interests: insertUser.interests || [],
      photo: insertUser.photo || null,
      subscription: insertUser.subscription || "gratuit",
      email: insertUser.email || null,
      dailyFlashesUsed: 0,
      lastFlashReset: new Date(),
      isTestProfile: insertUser.isTestProfile || false,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(excludeTestProfiles = false): Promise<User[]> {
    const allUsers = Array.from(this.users.values());
    return excludeTestProfiles ? allUsers.filter(user => !user.isTestProfile) : allUsers;
  }

  async getTestProfiles(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isTestProfile);
  }

  async deleteTestProfiles(): Promise<void> {
    const testProfileIds = Array.from(this.users.values())
      .filter(user => user.isTestProfile)
      .map(user => user.id);
    
    testProfileIds.forEach(id => this.users.delete(id));
  }

  async createFlash(insertFlash: InsertFlash): Promise<Flash> {
    const flash: Flash = {
      ...insertFlash,
      id: this.currentFlashId++,
      createdAt: new Date(),
    };
    this.flashes.set(flash.id, flash);
    return flash;
  }

  async getFlashsBetweenUsers(user1Id: number, user2Id: number): Promise<Flash[]> {
    return Array.from(this.flashes.values()).filter(
      flash => (flash.fromUserId === user1Id && flash.toUserId === user2Id) ||
                (flash.fromUserId === user2Id && flash.toUserId === user1Id)
    );
  }

  async getUserFlashesCount(userId: number, date: Date): Promise<number> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    return Array.from(this.flashes.values()).filter(
      flash => flash.fromUserId === userId && 
               flash.createdAt >= startOfDay && 
               flash.createdAt <= endOfDay
    ).length;
  }

  async createMatch(user1Id: number, user2Id: number): Promise<Match> {
    const match: Match = {
      id: this.currentMatchId++,
      user1Id,
      user2Id,
      createdAt: new Date(),
    };
    this.matches.set(match.id, match);
    return match;
  }

  async getUserMatches(userId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      match => match.user1Id === userId || match.user2Id === userId
    );
  }

  async checkMatch(user1Id: number, user2Id: number): Promise<Match | undefined> {
    return Array.from(this.matches.values()).find(
      match => (match.user1Id === user1Id && match.user2Id === user2Id) ||
                (match.user1Id === user2Id && match.user2Id === user1Id)
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const message: Message = {
      ...insertMessage,
      id: this.currentMessageId++,
      isRead: false,
      createdAt: new Date(),
    };
    this.messages.set(message.id, message);
    return message;
  }

  async getConversationMessages(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        (message.senderId === user1Id && message.receiverId === user2Id) ||
        (message.senderId === user2Id && message.receiverId === user1Id)
      )
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async markMessagesAsRead(senderId: number, receiverId: number): Promise<void> {
    Array.from(this.messages.values())
      .filter(message => message.senderId === senderId && message.receiverId === receiverId)
      .forEach(message => {
        message.isRead = true;
        this.messages.set(message.id, message);
      });
  }

  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const newNotification: Notification = {
      ...notification,
      id: this.currentNotificationId++,
      createdAt: new Date(),
    };
    this.notifications.set(newNotification.id, newNotification);
    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async markNotificationAsRead(id: number): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.isRead = true;
      this.notifications.set(id, notification);
    }
  }

  async getStats(): Promise<{
    totalUsers: number;
    totalMatches: number;
    premiumUsers: number;
    goldUsers: number;
    dailyFlashesAverage: number;
  }> {
    const allUsers = Array.from(this.users.values());
    const totalUsers = allUsers.length;
    const totalMatches = this.matches.size;
    const premiumUsers = allUsers.filter(user => user.subscription === 'premium').length;
    const goldUsers = allUsers.filter(user => user.subscription === 'gold').length;
    
    const today = new Date();
    const todayFlashes = Array.from(this.flashes.values()).filter(flash => {
      const flashDate = new Date(flash.createdAt);
      return flashDate.toDateString() === today.toDateString();
    });
    const dailyFlashesAverage = todayFlashes.length;

    return {
      totalUsers,
      totalMatches,
      premiumUsers,
      goldUsers,
      dailyFlashesAverage,
    };
  }

  // Referral methods
  async generateReferralCode(userId: number): Promise<string> {
    const code = `MATURE${userId}${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const user = this.users.get(userId);
    if (user) {
      this.users.set(userId, { ...user, referralCode: code });
    }
    return code;
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.referralCode === code) {
        return user;
      }
    }
    return undefined;
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const referral: Referral = {
      id: this.currentReferralId++,
      ...insertReferral,
      createdAt: new Date(),
      completedAt: null,
      rewardedAt: null,
    };
    this.referrals.set(referral.id, referral);
    return referral;
  }

  async getUserReferrals(userId: number): Promise<Referral[]> {
    return Array.from(this.referrals.values()).filter(r => r.referrerId === userId);
  }

  async processReferralReward(referralId: number): Promise<void> {
    const referral = this.referrals.get(referralId);
    if (!referral || referral.status === 'rewarded') return;

    const referrer = this.users.get(referral.referrerId);
    if (!referrer) return;

    // Marquer le parrainage comme récompensé
    this.referrals.set(referralId, {
      ...referral,
      status: 'rewarded',
      rewardedAt: new Date(),
    });

    // Appliquer la récompense
    await this.applyReferralBonus(referral.referrerId, referral.rewardType, referral.rewardAmount);

    // Créer une notification
    await this.createNotification({
      userId: referral.referrerId,
      type: 'referral_bonus',
      title: 'Félicitations ! Parrainage réussi',
      message: `Vous avez gagné ${referral.rewardAmount} flashes bonus grâce à votre parrainage !`,
      isRead: false,
    });
  }

  async applyReferralBonus(userId: number, bonusType: string, amount: number): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;

    if (bonusType === 'bonus_flashes') {
      this.users.set(userId, {
        ...user,
        bonusFlashes: (user.bonusFlashes || 0) + amount,
      });
    } else if (bonusType === 'free_month') {
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + amount);
      this.users.set(userId, {
        ...user,
        subscriptionEndDate: endDate,
        subscription: 'premium',
      });
    }
  }

  // Abandoned cart methods
  async createAbandonedCart(insertCart: InsertAbandonedCart): Promise<AbandonedCart> {
    const cart: AbandonedCart = {
      id: this.currentAbandonedCartId++,
      ...insertCart,
      createdAt: new Date(),
      lastReminderSent: null,
    };
    this.abandonedCarts.set(cart.id, cart);
    return cart;
  }

  async getAbandonedCartsByUser(userId: number): Promise<AbandonedCart[]> {
    return Array.from(this.abandonedCarts.values()).filter(cart => cart.userId === userId);
  }

  async getAbandonedCartsForReminder(): Promise<AbandonedCart[]> {
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    return Array.from(this.abandonedCarts.values()).filter(cart => {
      // Cart créé il y a plus de 24h et pas encore de rappel envoyé
      return cart.createdAt < oneDayAgo && 
             !cart.lastReminderSent && 
             !cart.discountUsed;
    });
  }

  async updateAbandonedCart(id: number, updates: Partial<AbandonedCart>): Promise<AbandonedCart | undefined> {
    const cart = this.abandonedCarts.get(id);
    if (!cart) return undefined;

    const updatedCart = { ...cart, ...updates };
    this.abandonedCarts.set(id, updatedCart);
    return updatedCart;
  }

  async validateDiscountCode(code: string): Promise<{valid: boolean; cart?: AbandonedCart}> {
    const cart = Array.from(this.abandonedCarts.values()).find(c => c.discountCode === code);
    if (!cart || cart.discountUsed) {
      return { valid: false };
    }
    return { valid: true, cart };
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getAllUsers(excludeTestProfiles = false): Promise<User[]> {
    const query = db.select().from(users);
    if (excludeTestProfiles) {
      return await query.where(eq(users.isTestProfile, false));
    }
    return await query;
  }

  async getTestProfiles(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isTestProfile, true));
  }

  async deleteTestProfiles(): Promise<void> {
    await db.delete(users).where(eq(users.isTestProfile, true));
  }

  async createFlash(insertFlash: InsertFlash): Promise<Flash> {
    const [flash] = await db
      .insert(flashes)
      .values(insertFlash)
      .returning();
    return flash;
  }

  async getFlashsBetweenUsers(user1Id: number, user2Id: number): Promise<Flash[]> {
    return await db
      .select()
      .from(flashes)
      .where(
        or(
          and(eq(flashes.fromUserId, user1Id), eq(flashes.toUserId, user2Id)),
          and(eq(flashes.fromUserId, user2Id), eq(flashes.toUserId, user1Id))
        )
      );
  }

  async getUserFlashesCount(userId: number, date: Date): Promise<number> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const result = await db
      .select()
      .from(flashes)
      .where(
        and(
          eq(flashes.fromUserId, userId),
          gte(flashes.createdAt, startOfDay),
          lte(flashes.createdAt, endOfDay)
        )
      );
    return result.length;
  }

  async createMatch(user1Id: number, user2Id: number): Promise<Match> {
    const [match] = await db
      .insert(matches)
      .values({ user1Id, user2Id })
      .returning();
    return match;
  }

  async getUserMatches(userId: number): Promise<Match[]> {
    return await db
      .select()
      .from(matches)
      .where(or(eq(matches.user1Id, userId), eq(matches.user2Id, userId)));
  }

  async checkMatch(user1Id: number, user2Id: number): Promise<Match | undefined> {
    const [match] = await db
      .select()
      .from(matches)
      .where(
        or(
          and(eq(matches.user1Id, user1Id), eq(matches.user2Id, user2Id)),
          and(eq(matches.user1Id, user2Id), eq(matches.user2Id, user1Id))
        )
      );
    return match || undefined;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getConversationMessages(user1Id: number, user2Id: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, user1Id), eq(messages.receiverId, user2Id)),
          and(eq(messages.senderId, user2Id), eq(messages.receiverId, user1Id))
        )
      )
      .orderBy(messages.createdAt);
  }

  async markMessagesAsRead(senderId: number, receiverId: number): Promise<void> {
    await db
      .update(messages)
      .set({ isRead: true })
      .where(and(eq(messages.senderId, senderId), eq(messages.receiverId, receiverId)));
  }

  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }

  async getStats(): Promise<{
    totalUsers: number;
    totalMatches: number;
    premiumUsers: number;
    goldUsers: number;
    dailyFlashesAverage: number;
  }> {
    const allUsers = await db.select().from(users);
    const allMatches = await db.select().from(matches);
    
    const today = new Date();
    const startOfDay = new Date(today);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);
    
    const todayFlashes = await db
      .select()
      .from(flashes)
      .where(and(gte(flashes.createdAt, startOfDay), lte(flashes.createdAt, endOfDay)));

    return {
      totalUsers: allUsers.length,
      totalMatches: allMatches.length,
      premiumUsers: allUsers.filter(user => user.subscription === 'premium').length,
      goldUsers: allUsers.filter(user => user.subscription === 'gold').length,
      dailyFlashesAverage: todayFlashes.length,
    };
  }
}

export const storage = new MemStorage();
