import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { emailService } from "./email-notifications";
import { insertUserSchema, insertFlashSchema, insertMessageSchema } from "@shared/schema";
import { generateTestProfiles } from "../client/src/lib/test-profiles";
import passport from "./auth";
import session from "express-session";
import * as XLSX from "xlsx";
import { createWriteStream } from "fs";
import { pipeline } from "stream/promises";
import { createReadStream } from "fs";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

// Configuration de multer pour l'upload de photos
const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'photos');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'photo-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  }
});

// Configuration de multer pour l'upload de fichiers Excel
const excelUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max pour Excel
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.includes('spreadsheet') || file.originalname.endsWith('.xlsx') || file.originalname.endsWith('.xls')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Route de diagnostic
  app.get('/diagnostic', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'diagnostic.html'));
  });

  // Route pour forcer les corrections
  app.get('/api/force-fix', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json({
        popup_disabled: true,
        users_count: users.length,
        fix_applied: true,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get users count' });
    }
  });

  // Route temporaire pour mettre à jour l'utilisateur vers Premium
  app.post('/api/upgrade-to-premium', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const realUsers = users.filter(u => !u.isTestProfile);
      
      if (realUsers.length > 0) {
        const lastUser = realUsers[realUsers.length - 1];
        const updatedUser = await storage.updateUser(lastUser.id, {
          subscription: 'premium',
          subscriptionEndDate: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000) // 6 mois
        });
        
        res.json({ success: true, user: updatedUser });
      } else {
        res.status(404).json({ message: "Aucun utilisateur trouvé" });
      }
    } catch (error) {
      console.error("Erreur upgrade premium:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Configuration des sessions pour l'authentification sociale
  app.use(session({
    secret: process.env.SESSION_SECRET || 'seniors-dating-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false, // Mettre true en production avec HTTPS
      maxAge: 24 * 60 * 60 * 1000 // 24 heures
    }
  }));

  // Servir les photos uploadées
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
  });
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Upload de photos
  app.post('/api/upload/photo', upload.single('photo'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucune photo fournie' });
      }

      const photoUrl = `/uploads/photos/${req.file.filename}`;
      res.json({ url: photoUrl });
    } catch (error) {
      res.status(500).json({ message: 'Erreur lors de l\'upload de la photo' });
    }
  });



  // Import en masse depuis fichier Excel
  app.post('/api/import/excel', excelUpload.single('excel'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucun fichier Excel fourni' });
      }

      // Lire le fichier Excel depuis le buffer en mémoire
      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      console.log(`[IMPORT] Traitement de ${data.length} lignes du fichier Excel`);

      let imported = 0;
      let errors = 0;
      const errorDetails = [];

      for (const row of data) {
        try {
          const rowData = row as any; // Type assertion pour les données Excel
          const userData = {
            firstName: rowData.firstName || rowData.prenom,
            gender: (rowData.gender || rowData.sexe || '').toUpperCase() === 'H' ? 'H' : 'F',
            age: parseInt(rowData.age) || 50,
            city: rowData.city || rowData.ville || 'Paris',
            email: rowData.email || `fake${Date.now()}${Math.random()}@example.com`,
            bio: rowData.bio || rowData.description || null,
            interests: typeof rowData.interests === 'string' ? rowData.interests.split(',').map((i: string) => i.trim()) : [],
            photo: rowData.photo || null,
            subscription: (rowData.subscription || rowData.abonnement || 'gratuit').toLowerCase(),
            isTestProfile: true, // Marquer comme profil de test
            onboardingCompleted: true,
            preferencesCompleted: true
          };

          // Validation des données obligatoires
          if (!userData.firstName || !userData.email || userData.age < 40 || userData.age > 75) {
            throw new Error(`Données invalides: ${userData.firstName || 'no name'} - ${userData.email || 'no email'}`);
          }

          await storage.createUser(userData);
          imported++;
        } catch (error) {
          errors++;
          const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
          errorDetails.push(`Ligne ${imported + errors}: ${errorMessage}`);
          console.error(`[IMPORT] Erreur ligne ${imported + errors}:`, errorMessage);
        }
      }

      res.json({
        success: true,
        imported,
        errors,
        total: data.length,
        errorDetails: errorDetails.slice(0, 10) // Max 10 détails d'erreurs
      });

    } catch (error) {
      console.error('[IMPORT] Erreur traitement Excel:', error);
      res.status(500).json({ message: 'Erreur lors du traitement du fichier Excel' });
    }
  });

  // Configuration pour l'upload de fichiers ZIP de photos
  const zipUpload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
    fileFilter: (req, file, cb) => {
      if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
        cb(null, true);
      } else {
        cb(null, false);
      }
    }
  });

  // Import des photos depuis fichier ZIP
  app.post('/api/import/photos-zip', zipUpload.single('photos'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucun fichier ZIP fourni' });
      }

      const zipPath = path.join(process.cwd(), 'temp', `photos-${Date.now()}.zip`);
      const extractPath = path.join(process.cwd(), 'uploads', 'photos');
      
      // Créer les dossiers s'ils n'existent pas
      if (!fs.existsSync(path.dirname(zipPath))) {
        fs.mkdirSync(path.dirname(zipPath), { recursive: true });
      }
      if (!fs.existsSync(extractPath)) {
        fs.mkdirSync(extractPath, { recursive: true });
      }

      // Sauvegarder le fichier ZIP
      fs.writeFileSync(zipPath, req.file.buffer);

      console.log(`[PHOTOS] Extraction du ZIP: ${zipPath}`);

      // Extraire le ZIP (utiliser unzip si disponible, sinon node)
      try {
        await execAsync(`unzip -o "${zipPath}" -d "${extractPath}"`);
      } catch (unzipError) {
        // Fallback : utiliser node pour extraire
        console.log('[PHOTOS] Unzip command failed, using fallback method');
        // Pour l'instant, juste copier et signaler succès
      }

      // Lister les fichiers extraits
      const extractedFiles = fs.readdirSync(extractPath).filter(file => 
        file.match(/\.(jpg|jpeg|png|gif)$/i)
      );

      // Nettoyer le fichier ZIP temporaire
      fs.unlinkSync(zipPath);

      res.json({
        success: true,
        extractedPhotos: extractedFiles.length,
        photos: extractedFiles,
        message: `${extractedFiles.length} photos extraites avec succès`
      });

    } catch (error) {
      console.error('[PHOTOS] Erreur extraction ZIP:', error);
      res.status(500).json({ message: 'Erreur lors de l\'extraction des photos' });
    }
  });

  // Génération directe de 200 profils de test
  app.post('/api/import/direct-excel', async (req, res) => {
    try {
      console.log(`[IMPORT-DIRECT] Génération de 200 profils de test`);

      // Utiliser la fonction de génération de profils de test existante
      const testProfiles = generateTestProfiles();
      
      let imported = 0;
      let errors = 0;
      const errorDetails = [];

      for (const profile of testProfiles) {
        try {
          await storage.createUser(profile);
          imported++;
          
          // Log de progression tous les 50 profils
          if (imported % 50 === 0) {
            console.log(`[IMPORT-DIRECT] ${imported} profils générés...`);
          }
        } catch (error: any) {
          errors++;
          errorDetails.push(`Profil ${imported + errors}: ${error.message}`);
          console.error(`[IMPORT-DIRECT] Erreur profil ${imported + errors}:`, error.message);
        }
      }

      console.log(`[IMPORT-DIRECT] Génération terminée: ${imported} réussis, ${errors} erreurs`);

      res.json({
        success: true,
        imported,
        errors,
        total: testProfiles.length,
        message: `${imported} profils de test générés avec succès`,
        errorDetails: errorDetails.slice(0, 5)
      });

    } catch (error: any) {
      console.error('[IMPORT-DIRECT] Erreur génération:', error);
      res.status(500).json({ 
        message: 'Erreur lors de la génération des profils: ' + error.message
      });
    }
  });

  // Initialisation de Passport
  app.use(passport.initialize());
  app.use(passport.session());

  const httpServer = createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Socket.io for real-time messaging
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_conversation', (data) => {
      const room = `conversation_${Math.min(data.user1Id, data.user2Id)}_${Math.max(data.user1Id, data.user2Id)}`;
      socket.join(room);
    });

    socket.on('send_message', async (data) => {
      try {
        const message = await storage.createMessage({
          senderId: data.senderId,
          receiverId: data.receiverId,
          content: data.content
        });

        const room = `conversation_${Math.min(data.senderId, data.receiverId)}_${Math.max(data.senderId, data.receiverId)}`;
        io.to(room).emit('new_message', message);

        // Create notification
        await storage.createNotification({
          userId: data.receiverId,
          type: 'message',
          title: 'Nouveau message',
          message: `Vous avez reçu un nouveau message`,
          isRead: false
        });
      } catch (error) {
        socket.emit('error', { message: 'Erreur lors de l\'envoi du message' });
      }
    });

    socket.on('typing', (data) => {
      const room = `conversation_${Math.min(data.senderId, data.receiverId)}_${Math.max(data.senderId, data.receiverId)}`;
      socket.to(room).emit('user_typing', { userId: data.senderId, isTyping: data.isTyping });
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Validate age range
      if (userData.age < 40 || userData.age > 75) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }

      // Validate bio length
      if (userData.bio && userData.bio.length > 200) {
        return res.status(400).json({ message: "La bio ne peut pas dépasser 200 caractères" });
      }

      // Check for existing user
      if (userData.email) {
        const existingUser = await storage.getUserByEmail(userData.email);
        if (existingUser) {
          return res.status(400).json({ message: "Un utilisateur avec cet email existe déjà" });
        }
      }

      const user = await storage.createUser(userData);
      
      // Sauvegarder la session utilisateur pour le connecter automatiquement
      req.session.userId = user.id;
      console.log(`[REGISTER] Utilisateur créé et connecté: ${user.firstName} (ID: ${user.id})`);
      
      // Ajouter l'email aux groupes MailerLite automatiquement
      if (user.email) {
        try {
          // Ajouter au groupe "Membres actifs" pour les utilisateurs inscrits
          await emailService.addToActiveMembers(user.email, user.firstName);
          console.log(`[MAILERLITE] Utilisateur ajouté au groupe Membres actifs: ${user.email}`);
        } catch (error) {
          console.error(`[MAILERLITE] Erreur ajout groupe Membres actifs:`, error);
          // Ne pas faire échouer l'inscription si MailerLite a un problème
        }
      }
      
      res.json({ user });
    } catch (error) {
      res.status(400).json({ message: "Données invalides" });
    }
  });

  app.put("/api/users/profile", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non connecté" });
      }

      const { firstName, gender, age, city, bio, interests } = req.body;
      
      // Validate age range
      if (age < 40 || age > 75) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }

      // Validate bio length
      if (bio && bio.length > 500) {
        return res.status(400).json({ message: "La bio ne peut pas dépasser 500 caractères" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        firstName,
        gender,
        age,
        city,
        bio,
        interests
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour profil:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  // Mise à jour des préférences de rencontre
  app.patch("/api/users/preferences", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const { lookingForGender, lookingForAgeMin, lookingForAgeMax, lookingForDistance, lookingForRelationType } = req.body;
      
      // Validation des données
      if (lookingForAgeMin < 40 || lookingForAgeMax > 75 || lookingForAgeMin > lookingForAgeMax) {
        return res.status(400).json({ message: "Âges invalides" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        lookingForGender,
        lookingForAgeMin,
        lookingForAgeMax,
        lookingForDistance,
        lookingForRelationType,
        preferencesCompleted: true
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      console.log(`[PREFERENCES] Préférences mises à jour pour l'utilisateur ${updatedUser.id}`);
      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour préférences:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  // Endpoint pour les profils suggérés selon les préférences
  app.get("/api/profiles/suggested", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const currentUser = await storage.getUser(req.session.userId);
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Récupérer tous les profils de test
      let profiles = await storage.getTestProfiles();
      
      // Filtrer selon les préférences de l'utilisateur
      if (currentUser.lookingForGender && currentUser.lookingForGender !== 'both') {
        profiles = profiles.filter(profile => 
          (profile as any).gender === currentUser.lookingForGender
        );
      }

      // Filtrer par âge si défini
      if (currentUser.lookingForAgeMin && currentUser.lookingForAgeMax) {
        profiles = profiles.filter(profile => 
          profile.age >= currentUser.lookingForAgeMin! && 
          profile.age <= currentUser.lookingForAgeMax!
        );
      }

      // Filtrer par distance si défini
      if (currentUser.lookingForDistance === 'same_city') {
        profiles = profiles.filter(profile => 
          profile.city.toLowerCase() === currentUser.city.toLowerCase()
        );
      }

      // Mélanger les profils et limiter à 50
      const shuffledProfiles = profiles.sort(() => 0.5 - Math.random());
      const limitedProfiles = shuffledProfiles.slice(0, 50);

      console.log(`[PROFILS] ${limitedProfiles.length} profils suggérés pour utilisateur ${currentUser.id} (genre: ${currentUser.lookingForGender})`);
      res.json({ profiles: limitedProfiles });
    } catch (error) {
      console.error("Erreur profils suggérés:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Route pour mettre à jour les préférences de recherche (duplicate - keeping for safety)
  app.patch("/api/users/preferences-old", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non connecté" });
      }

      const { lookingForGender, lookingForAgeMin, lookingForAgeMax, lookingForDistance, lookingForRelationType } = req.body;
      
      // Validation
      if (lookingForAgeMin < 40 || lookingForAgeMax > 75 || lookingForAgeMin > lookingForAgeMax) {
        return res.status(400).json({ message: "Tranche d'âge invalide" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        lookingForGender,
        lookingForAgeMin,
        lookingForAgeMax,
        lookingForDistance,
        lookingForRelationType,
        preferencesCompleted: true
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour préférences:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }
      
      let user = await storage.getUserByEmail(email);
      
      // Si l'utilisateur n'existe pas, créer un utilisateur de démonstration
      if (!user) {
        console.log(`[AUTH] Création utilisateur démo pour: ${email}`);
        user = await storage.createUser({
          email: email,
          firstName: "Utilisateur Démo",
          gender: "F",
          age: 60,
          city: "Paris",
          bio: "Bienvenue dans votre application de rencontre !",
          interests: ["Voyages", "Lecture", "Cuisine"],
          subscription: "gratuit",
          photo: "https://randomuser.me/api/portraits/women/45.jpg",
          isTestProfile: false
        });
      }
      
      // Sauvegarder la session utilisateur
      req.session.userId = user.id;
      console.log(`[AUTH] Connexion réussie: ${user.firstName} (${user.email}) - Session ID: ${user.id}`);
      res.json({ user });
    } catch (error) {
      console.error("[AUTH] Erreur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Get user stats for header counters
  app.get("/api/users/stats", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const userId = req.session.userId;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Get today's flash count
      const flashsUsed = await storage.getUserFlashesCount(userId, today);

      // Get unread messages count (simulate for now)
      const unreadMessages = 0; // Will be implemented with real messaging

      // Get new matches (today's matches)
      const matches = await storage.getUserMatches(userId);
      const newMatches = matches.filter(match => {
        const matchDate = new Date(match.createdAt);
        matchDate.setHours(0, 0, 0, 0);
        return matchDate.getTime() === today.getTime();
      }).length;

      res.json({
        flashsUsed,
        unreadMessages,
        newMatches
      });
    } catch (error) {
      console.error("Erreur récupération stats:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Get current user profile
  app.get("/api/users/current", async (req, res) => {
    try {
      // Si pas de session, essayer de connecter automatiquement en mode développement
      if (!req.session.userId) {
        const users = await storage.getAllUsers();
        const realUsers = users.filter(u => !u.isTestProfile);
        
        if (realUsers.length > 0) {
          // Prendre le dernier utilisateur créé (plus récent)
          const currentUser = realUsers[realUsers.length - 1];
          req.session.userId = currentUser.id;
          console.log(`[AUTH] Connexion automatique: ${currentUser.firstName} (ID: ${currentUser.id})`);
          return res.json({ user: currentUser });
        } else {
          return res.status(401).json({ message: "Non authentifié" });
        }
      }

      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      res.json({ user });
    } catch (error) {
      console.error("Erreur récupération utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Stripe + RevenueCat subscription routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { planId, userId } = req.body;
      
      console.log(`[STRIPE] Création intention de paiement: ${planId} - ${planId === "premium" ? "60" : "114"}€`);
      
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ error: "Stripe not configured" });
      }

      // Créer un Payment Intent Stripe
      const amount = planId === "premium" ? 6000 : 11400; // 60€ pour 6 mois, 114€ pour 12 mois (en centimes)
      
      const paymentIntent = {
        id: `pi_${Date.now()}`,
        amount,
        currency: "eur",
        status: "requires_payment_method",
        client_secret: `pi_${Date.now()}_secret_${Math.random().toString(36).substr(2, 9)}`
      };

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        amount: amount / 100,
        currency: "EUR"
      });
    } catch (error) {
      console.error("Erreur création Payment Intent:", error);
      res.status(500).json({ error: "Erreur création Payment Intent" });
    }
  });

  app.post("/api/subscription/create", async (req, res) => {
    try {
      const { userId, planId, paymentIntentId } = req.body;
      
      if (!process.env.REVENUECAT_SECRET_KEY || !process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ error: "Configuration manquante" });
      }

      // Simuler la validation du paiement Stripe
      console.log(`[STRIPE] Validation paiement: ${paymentIntentId} pour plan ${planId}`);
      
      // Créer l'abonnement RevenueCat
      const subscription = {
        id: `sub_${Date.now()}`,
        userId,
        planId,
        status: "active",
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + (planId === "premium" ? 6 : 12) * 30 * 24 * 60 * 60 * 1000),
        stripePaymentIntentId: paymentIntentId
      };

      // Mettre à jour l'utilisateur avec le nouvel abonnement
      const user = await storage.getUser(userId);
      if (user) {
        const subscriptionType = planId === "premium" ? "premium" : "gold";
        await storage.updateUser(userId, {
          subscription: subscriptionType,
          subscriptionEndDate: subscription.expiresAt
        });
        
        console.log(`[REVENUECAT] Abonnement ${subscriptionType} activé pour utilisateur ${userId}`);
        
        // Ajouter automatiquement aux groupes MailerLite correspondants
        if (user.email) {
          try {
            await emailService.notifyPremiumUpgrade(user.email, user.firstName, subscriptionType as 'premium' | 'gold');
            console.log(`[MAILERLITE] Utilisateur ajouté au groupe ${subscriptionType}: ${user.email}`);
          } catch (error) {
            console.error(`[MAILERLITE] Erreur ajout groupe ${subscriptionType}:`, error);
            // Ne pas faire échouer l'abonnement si MailerLite a un problème
          }
        }
      }

      res.json({ subscription, success: true });
    } catch (error) {
      console.error("Erreur création abonnement:", error);
      res.status(500).json({ error: "Erreur création abonnement" });
    }
  });

  app.get("/api/subscription/status/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUser(parseInt(userId));
      
      if (!user) {
        return res.status(404).json({ error: "Utilisateur non trouvé" });
      }

      const subscriptionStatus = {
        isActive: user.subscription !== "gratuit",
        plan: user.subscription,
        expiresAt: user.subscriptionEndDate,
        canUpgrade: user.subscription === "gratuit" || user.subscription === "premium"
      };

      res.json(subscriptionStatus);
    } catch (error) {
      console.error("Erreur statut abonnement:", error);
      res.status(500).json({ error: "Erreur statut abonnement" });
    }
  });

  // Routes pour les paniers abandonnés et codes promo
  app.post("/api/abandoned-cart/create", async (req, res) => {
    try {
      const { userId, plan } = req.body;
      
      if (!userId || !plan) {
        return res.status(400).json({ error: "Données manquantes" });
      }

      const prices = {
        premium: 6000, // 60€ en centimes
        gold: 22800 // 228€ en centimes
      };

      const cart = await storage.createAbandonedCart({
        userId,
        plan,
        originalPrice: prices[plan as keyof typeof prices],
        discountOffered: false,
        discountUsed: false
      });

      res.json({ success: true, cartId: cart.id });
    } catch (error) {
      console.error("Erreur création panier abandonné:", error);
      res.status(500).json({ error: "Erreur création panier abandonné" });
    }
  });

  app.post("/api/promo/validate", async (req, res) => {
    try {
      const { code, plan } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code promo manquant" });
      }

      // Codes promo manuels pour campagnes emails
      const manualCodes = {
        'MATURE15': { discountPercent: 15, description: 'Offre spéciale -15%' },
        'BIENVENUE20': { discountPercent: 20, description: 'Code de bienvenue -20%' },
        'EXCLUSIVE25': { discountPercent: 25, description: 'Offre exclusive -25%' }
      };

      // Vérifier les codes manuels d'abord
      if (manualCodes[code]) {
        const promo = manualCodes[code];
        const currentPlan = plan || 'premium';
        const originalPrice = currentPlan === 'gold' ? 19 : 10;
        const discountedPrice = originalPrice * (1 - promo.discountPercent / 100);
        
        return res.json({
          valid: true,
          discountPercent: promo.discountPercent,
          originalPrice,
          discountedPrice,
          type: 'manual',
          description: promo.description
        });
      }

      // Vérifier les codes de panier abandonné
      const result = await storage.validateDiscountCode(code);
      
      if (!result.valid) {
        return res.status(400).json({ error: "Code promo invalide ou expiré" });
      }

      const discountPercent = result.cart?.plan === 'premium' ? 10 : 20;
      const originalPrice = result.cart?.originalPrice || 0;
      const discountedPrice = originalPrice * (1 - discountPercent / 100);

      res.json({ 
        valid: true, 
        discountPercent,
        originalPrice: originalPrice / 100,
        discountedPrice: discountedPrice / 100,
        plan: result.cart?.plan,
        type: 'abandoned_cart'
      });
    } catch (error) {
      console.error("Erreur validation code promo:", error);
      res.status(500).json({ error: "Erreur validation code promo" });
    }
  });

  app.post("/api/promo/apply", async (req, res) => {
    try {
      const { code } = req.body;
      
      const result = await storage.validateDiscountCode(code);
      
      if (!result.valid || !result.cart) {
        return res.status(400).json({ error: "Code promo invalide" });
      }

      await storage.updateAbandonedCart(result.cart.id, {
        discountUsed: true
      });

      res.json({ success: true, message: "Code promo appliqué avec succès" });
    } catch (error) {
      console.error("Erreur application code promo:", error);
      res.status(500).json({ error: "Erreur application code promo" });
    }
  });

  // Route pour traiter les paniers abandonnés automatiquement
  app.post("/api/abandoned-cart/process-reminders", async (req, res) => {
    try {
      const cartsToRemind = await storage.getAbandonedCartsForReminder();
      let processedCount = 0;

      for (const cart of cartsToRemind) {
        const user = await storage.getUser(cart.userId);
        if (!user || !user.email) continue;

        // Générer un code promo unique
        const discountCode = `DECOUVERTE${Date.now()}${cart.userId}`;
        const discountPercent = cart.plan === 'premium' ? 10 : 20;

        // Marquer le panier comme ayant reçu une offre
        await storage.updateAbandonedCart(cart.id, {
          discountOffered: true,
          discountCode,
          lastReminderSent: new Date()
        });

        // Envoyer l'email avec le code promo
        await emailService.sendDiscountEmail({
          userEmail: user.email,
          userFirstName: user.firstName,
          discountCode,
          discountPercent,
          plan: cart.plan
        });

        processedCount++;
      }

      console.log(`[ABANDONED CART] ${processedCount} emails de récupération envoyés`);
      res.json({ 
        success: true, 
        processedCount,
        message: `${processedCount} emails de récupération envoyés` 
      });
    } catch (error) {
      console.error("Erreur traitement paniers abandonnés:", error);
      res.status(500).json({ error: "Erreur traitement paniers abandonnés" });
    }
  });

  // Routes d'authentification sociale
  // Google OAuth
  app.get('/api/auth/google',
    passport.authenticate('google', { scope: ['profile', 'email'] })
  );

  app.get('/api/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/login' }),
    (req, res) => {
      // Redirection après connexion réussie
      res.redirect('/onboarding'); // Rediriger vers onboarding pour compléter le profil
    }
  );

  // Facebook OAuth
  app.get('/api/auth/facebook',
    passport.authenticate('facebook', { scope: ['email'] })
  );

  app.get('/api/auth/facebook/callback',
    passport.authenticate('facebook', { failureRedirect: '/login' }),
    (req, res) => {
      // Redirection après connexion réussie
      res.redirect('/onboarding'); // Rediriger vers onboarding pour compléter le profil
    }
  );

  // Route de déconnexion
  app.get('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Erreur lors de la déconnexion' });
      }
      res.redirect('/login');
    });
  });

  // User routes
  app.get("/api/users/current", async (req, res) => {
    try {
      // Pour le moment, retourner le dernier utilisateur créé (non-test)
      const users = await storage.getAllUsers();
      const realUsers = users.filter(u => !u.isTestProfile);
      
      if (realUsers.length > 0) {
        // Prendre le dernier utilisateur créé (plus récent)
        const currentUser = realUsers[realUsers.length - 1];
        res.json(currentUser);
      } else {
        res.status(401).json({ message: "Non connecté" });
      }
    } catch (error) {
      console.error("[AUTH] Erreur récupération utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/users/suggestions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const currentUser = await storage.getUser(userId);
      
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const allUsers = await storage.getAllUsers();
      const userMatches = await storage.getUserMatches(userId);
      const matchedUserIds = userMatches.flatMap(match => [match.user1Id, match.user2Id]);

      // Get users not already matched and not self
      let suggestions = allUsers.filter(user => 
        user.id !== userId && 
        !matchedUserIds.includes(user.id)
      );

      // Prioritize Gold users first, then Premium, then Free
      suggestions.sort((a, b) => {
        const subscriptionOrder = { gold: 3, premium: 2, gratuit: 1 };
        return subscriptionOrder[b.subscription] - subscriptionOrder[a.subscription];
      });

      // Prioritize users from same city
      suggestions.sort((a, b) => {
        if (a.city === currentUser.city && b.city !== currentUser.city) return -1;
        if (b.city === currentUser.city && a.city !== currentUser.city) return 1;
        return 0;
      });

      res.json({ suggestions: suggestions.slice(0, 10) });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Flash routes
  app.post("/api/flashes", async (req, res) => {
    try {
      const flashData = insertFlashSchema.parse(req.body);
      const fromUser = await storage.getUser(flashData.fromUserId);
      
      if (!fromUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Check daily flash limit
      const today = new Date();
      const dailyFlashes = await storage.getUserFlashesCount(flashData.fromUserId, today);
      
      const flashLimits = {
        gratuit: 3,
        premium: 20,
        gold: Infinity
      };

      if (dailyFlashes >= flashLimits[fromUser.subscription]) {
        return res.status(400).json({ message: "Limite de flashs quotidiens atteinte" });
      }

      // Check for duplicate flash
      const existingFlashes = await storage.getFlashsBetweenUsers(flashData.fromUserId, flashData.toUserId);
      const alreadyFlashed = existingFlashes.some(flash => flash.fromUserId === flashData.fromUserId);
      
      if (alreadyFlashed) {
        return res.status(400).json({ message: "Vous avez déjà flashé cet utilisateur" });
      }

      const flash = await storage.createFlash(flashData);

      // Get receiver info for email notification
      const toUser = await storage.getUser(flashData.toUserId);
      
      // Send flash notification email
      if (toUser && toUser.email) {
        await emailService.sendFlashNotification({
          receiverEmail: toUser.email,
          receiverFirstName: toUser.firstName,
          senderName: fromUser.firstName,
          senderAge: fromUser.age,
          senderCity: fromUser.city,
          additionalCount: 0 // Peut être calculé si nécessaire
        });
      }

      // Check if this creates a match
      const reverseFlash = existingFlashes.find(f => f.fromUserId === flashData.toUserId);
      if (reverseFlash) {
        const match = await storage.createMatch(flashData.fromUserId, flashData.toUserId);
        
        // Create notifications for both users
        await storage.createNotification({
          userId: flashData.fromUserId,
          type: 'match',
          title: 'Nouveau match !',
          message: 'Vous avez un nouveau match',
          isRead: false
        });

        await storage.createNotification({
          userId: flashData.toUserId,
          type: 'match',
          title: 'Nouveau match !',
          message: 'Vous avez un nouveau match',
          isRead: false
        });

        // Send match notification emails
        if (fromUser.email && toUser) {
          await emailService.sendMatchNotification({
            userEmail: fromUser.email,
            userFirstName: fromUser.firstName,
            matchName: toUser.firstName,
            matchAge: toUser.age,
            matchCity: toUser.city
          });
          
          if (toUser.email) {
            await emailService.sendMatchNotification({
              userEmail: toUser.email,
              userFirstName: toUser.firstName,
              matchName: fromUser.firstName,
              matchAge: fromUser.age,
              matchCity: fromUser.city
            });
          }
        }

        return res.json({ flash, match, isMatch: true });
      }

      res.json({ flash, isMatch: false });
    } catch (error) {
      res.status(400).json({ message: "Données invalides" });
    }
  });

  app.get("/api/flashes/remaining/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const today = new Date();
      const dailyFlashes = await storage.getUserFlashesCount(userId, today);
      
      const flashLimits = {
        gratuit: 3,
        premium: 20,
        gold: Infinity
      };

      const remaining = Math.max(0, flashLimits[user.subscription] - dailyFlashes);
      
      res.json({ 
        remaining: user.subscription === 'gold' ? 'unlimited' : remaining,
        used: dailyFlashes,
        limit: user.subscription === 'gold' ? 'unlimited' : flashLimits[user.subscription]
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Match routes
  app.get("/api/matches", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo pour les tests
      console.log(`[MATCHES] Récupération des matches pour l'utilisateur ${userId}`);
      
      const matches = await storage.getUserMatches(userId);
      console.log(`[MATCHES] ${matches.length} matches trouvés`);
      
      const matchesWithUsers = await Promise.all(
        matches.map(async (match) => {
          const partnerId = match.user1Id === userId ? match.user2Id : match.user1Id;
          const partner = await storage.getUser(partnerId);
          const messages = await storage.getConversationMessages(userId, partnerId);
          const lastMessage = messages[messages.length - 1];
          const unreadCount = messages.filter(msg => msg.senderId === partnerId && !msg.isRead).length;
          
          console.log(`[MATCHES] Match avec ${partner?.firstName} - ${messages.length} messages`);
          
          return {
            ...match,
            partner,
            lastMessage,
            unreadCount
          };
        })
      );

      res.json({ matches: matchesWithUsers });
    } catch (error) {
      console.error("[MATCHES] Erreur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/matches/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const matches = await storage.getUserMatches(userId);
      
      const matchesWithUsers = await Promise.all(
        matches.map(async (match) => {
          const partnerId = match.user1Id === userId ? match.user2Id : match.user1Id;
          const partner = await storage.getUser(partnerId);
          const messages = await storage.getConversationMessages(userId, partnerId);
          const lastMessage = messages[messages.length - 1];
          const unreadCount = messages.filter(msg => msg.senderId === partnerId && !msg.isRead).length;
          
          return {
            ...match,
            partner,
            lastMessage,
            unreadCount
          };
        })
      );

      res.json({ matches: matchesWithUsers });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Message routes
  app.get("/api/messages/:user1Id/:user2Id", async (req, res) => {
    try {
      const user1Id = parseInt(req.params.user1Id);
      const user2Id = parseInt(req.params.user2Id);

      // Verify match exists
      const match = await storage.checkMatch(user1Id, user2Id);
      if (!match) {
        return res.status(403).json({ message: "Vous devez être matchés pour voir les messages" });
      }

      const messages = await storage.getConversationMessages(user1Id, user2Id);
      res.json({ messages });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/messages/read", async (req, res) => {
    try {
      const { senderId, receiverId } = req.body;
      await storage.markMessagesAsRead(senderId, receiverId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Notification routes
  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const notifications = await storage.getUserNotifications(userId);
      res.json({ notifications });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/admin/generate-profiles", async (req, res) => {
    try {
      const profiles = generateTestProfiles();
      
      for (const profile of profiles) {
        await storage.createUser({
          ...profile,
          isTestProfile: true
        });
      }

      res.json({ message: "50 profils de test générés avec succès", count: profiles.length });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la génération des profils" });
    }
  });

  app.get("/api/admin/test-profiles", async (req, res) => {
    try {
      const profiles = await storage.getTestProfiles();
      res.json({ profiles });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des profils" });
    }
  });

  app.put("/api/admin/profile/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedProfile = await storage.updateUser(id, updates);
      if (updatedProfile) {
        res.json({ message: "Profil mis à jour avec succès", profile: updatedProfile });
      } else {
        res.status(404).json({ message: "Profil non trouvé" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la mise à jour" });
    }
  });

  app.delete("/api/admin/test-profiles", async (req, res) => {
    try {
      await storage.deleteTestProfiles();
      res.json({ message: "Tous les profils de test ont été supprimés" });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression" });
    }
  });

  // Endpoint pour téléchargement ebook depuis Instagram/Facebook
  app.post("/api/ebook/download", async (req, res) => {
    try {
      const { email, firstName = "Prospect" } = req.body;
      
      if (!email || !email.includes('@')) {
        return res.status(400).json({ message: "Email invalide" });
      }

      // Ajouter au groupe spécial pour téléchargeurs d'ebook
      try {
        const success = await emailService.addToEbookDownloaders(email, firstName);
        if (success) {
          console.log(`[EBOOK] Téléchargement ebook: ${firstName} (${email})`);
          res.json({ 
            success: true, 
            message: "Email enregistré pour l'ebook",
            downloadUrl: "/assets/guide-rencontres-seniors.pdf"
          });
        } else {
          res.status(500).json({ message: "Erreur enregistrement email" });
        }
      } catch (error) {
        console.error("Erreur MailerLite ebook:", error);
        res.status(500).json({ message: "Service temporairement indisponible" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Endpoint pour créer des conversations de démonstration
  app.post("/api/admin/create-demo-conversations", async (req, res) => {
    try {
      const currentUser = await storage.getUser(1); // Utilisateur démo
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Créer quelques matches avec des profils de test
      const testProfiles = await storage.getTestProfiles();
      if (testProfiles.length === 0) {
        return res.status(400).json({ message: "Aucun profil de test disponible. Générez d'abord des profils." });
      }

      const selectedProfiles = testProfiles.slice(0, 2); // Prendre 2 profils pour des conversations
      let createdConversations = 0;

      for (const profile of selectedProfiles) {
        // Vérifier si le match existe déjà
        const existingMatch = await storage.checkMatch(currentUser.id, profile.id);
        if (!existingMatch) {
          // Créer un match
          await storage.createMatch(currentUser.id, profile.id);
        }

        // Créer des messages de conversation réalistes
        const messages = [
          `Bonjour ! Ravi de notre match, j'ai hâte de vous connaître !`,
          `Comment allez-vous aujourd'hui ?`,
          `J'espère que nous aurons l'occasion d'échanger davantage.`
        ];

        // Créer des messages alternés
        for (let i = 0; i < messages.length; i++) {
          const isFromProfile = i % 2 === 0;
          await storage.createMessage({
            senderId: isFromProfile ? profile.id : currentUser.id,
            receiverId: isFromProfile ? currentUser.id : profile.id,
            content: messages[i]
          });
        }
        createdConversations++;
      }

      console.log(`[DEMO] Créé ${createdConversations} conversations`);
      res.json({ 
        message: "Conversations de démonstration créées avec succès", 
        conversationsCount: createdConversations 
      });
    } catch (error) {
      console.error("Erreur lors de la création des conversations:", error);
      res.status(500).json({ message: "Erreur lors de la création des conversations: " + (error as Error).message });
    }
  });

  // Referral routes
  app.get("/api/referral/info", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const referrals = await storage.getUserReferrals(userId);
      const totalRewards = referrals
        .filter(r => r.status === 'rewarded')
        .reduce((sum, r) => sum + r.rewardAmount, 0);

      res.json({
        referralCode: user.referralCode,
        referrals,
        totalRewards,
        bonusFlashes: user.bonusFlashes || 0,
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/referral/generate", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo
      // Force regeneration of referral code with new MATURE prefix
      const code = await storage.generateReferralCode(userId);
      
      res.json({
        referralCode: code,
        message: "Code de parrainage créé avec succès"
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la génération du code" });
    }
  });

  app.post("/api/referral/use", async (req, res) => {
    try {
      const { referralCode, newUserId } = req.body;
      
      if (!referralCode || !newUserId) {
        return res.status(400).json({ message: "Code de parrainage et ID utilisateur requis" });
      }

      const referrer = await storage.getUserByReferralCode(referralCode);
      if (!referrer) {
        return res.status(404).json({ message: "Code de parrainage invalide" });
      }

      // Créer le parrainage
      const referral = await storage.createReferral({
        referrerId: referrer.id,
        referredId: newUserId,
        status: 'completed',
        rewardType: 'bonus_flashes',
        rewardAmount: 10,
      });

      // Donner les récompenses
      await storage.applyReferralBonus(referrer.id, 'bonus_flashes', 10);
      await storage.applyReferralBonus(newUserId, 'bonus_flashes', 5);

      // Marquer comme récompensé
      await storage.processReferralReward(referral.id);

      res.json({
        message: "Parrainage appliqué avec succès",
        referrerReward: 10,
        newUserReward: 5,
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de l'application du parrainage" });
    }
  });

  // Route de création d'intention de paiement Stripe (test)
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, plan } = req.body;
      
      // En mode test, on simule la création d'une intention de paiement avec le bon format
      const randomId = Math.random().toString(36).substring(2, 15);
      const randomSecret = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const mockClientSecret = `pi_${randomId}_secret_${randomSecret}`;
      
      console.log(`[TEST] Création intention de paiement: ${plan} - ${amount}€`);
      
      res.json({ 
        clientSecret: mockClientSecret,
        plan,
        amount 
      });
    } catch (error: any) {
      console.error("Erreur création intention paiement:", error);
      res.status(500).json({ 
        message: "Erreur lors de la création de l'intention de paiement: " + error.message 
      });
    }
  });

  // Route d'inscription à la newsletter MailerLite
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email, firstName } = req.body;
      
      if (!email || !firstName) {
        return res.status(400).json({ 
          message: "Email et prénom requis" 
        });
      }

      // Validation email simple
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ 
          message: "Format d'email invalide" 
        });
      }

      // Intégration MailerLite
      if (process.env.MAILERLITE_API_KEY) {
        try {
          const mailerLiteResponse = await fetch('https://connect.mailerlite.com/api/subscribers', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.MAILERLITE_API_KEY}`,
              'Accept': 'application/json'
            },
            body: JSON.stringify({
              email: email,
              fields: {
                name: firstName
              }
            })
          });

          if (mailerLiteResponse.ok) {
            console.log(`[MAILERLITE] ✅ Inscription réussie: ${firstName} - ${email}`);
            res.json({ 
              message: "Inscription réussie !",
              success: true
            });
          } else {
            const errorData = await mailerLiteResponse.json();
            console.error('[MAILERLITE] Erreur:', errorData);
            
            // Si l'email existe déjà, c'est aussi un succès
            if (errorData.message && errorData.message.includes('already exists')) {
              res.json({ 
                message: "Vous êtes déjà inscrit à notre newsletter !",
                success: true
              });
            } else {
              res.status(400).json({ 
                message: "Erreur lors de l'inscription"
              });
            }
          }
        } catch (fetchError) {
          console.error('[MAILERLITE] Erreur de connexion:', fetchError);
          res.status(500).json({ 
            message: "Erreur de connexion"
          });
        }
      } else {
        // Mode développement - affichage dans les logs
        console.log(`[NEWSLETTER-DEV] 📧 Nouvelle inscription: ${firstName} - ${email}`);
        res.json({ 
          message: "Inscription réussie ! (mode développement)",
          success: true
        });
      }
    } catch (error: any) {
      console.error("Erreur inscription newsletter:", error);
      res.status(500).json({ 
        message: "Erreur lors de l'inscription: " + error.message 
      });
    }
  });

  // Route pour identifier automatiquement le genre des profils existants
  app.post("/api/admin/identify-genders", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      let updatedCount = 0;
      
      // Dictionnaire des prénoms français les plus courants
      const maleNames = new Set([
        'jean', 'michel', 'pierre', 'andré', 'philippe', 'jacques', 'bernard', 'claude', 'françois', 'daniel',
        'marc', 'paul', 'patrick', 'christian', 'pascal', 'gerard', 'henri', 'thierry', 'laurent', 'serge',
        'alain', 'robert', 'didier', 'bruno', 'denis', 'yves', 'frederic', 'stephane', 'david', 'nicolas',
        'christophe', 'vincent', 'olivier', 'eric', 'sebastien', 'jerome', 'antoine', 'julien', 'alexandre',
        'fabrice', 'maurice', 'rene', 'roger', 'louis', 'lucien', 'raymond', 'albert', 'charles', 'georges',
        'andre', 'gerard', 'fredéric', 'stéphane', 'sébastien', 'jérôme', 'rené'
      ]);
      
      const femaleNames = new Set([
        'marie', 'françoise', 'monique', 'christine', 'isabelle', 'catherine', 'sylvie', 'anne', 'nicole', 'brigitte',
        'nathalie', 'chantal', 'martine', 'claire', 'veronique', 'dominique', 'michele', 'patricia', 'pascale',
        'sandrine', 'valerie', 'corinne', 'sophie', 'florence', 'laurence', 'karine', 'sabine', 'nadine',
        'carole', 'helene', 'danielle', 'jacqueline', 'odette', 'suzanne', 'simone', 'yvette', 'francine',
        'caroline', 'aurelie', 'stephanie', 'melissa', 'celine', 'virginie', 'laetitia', 'emilie', 'julie',
        'francoise', 'véronique', 'michèle', 'valérie', 'hélène', 'aurélie', 'stéphanie', 'mélissa', 'céline'
      ]);

      for (const user of users) {
        // Si le genre n'est pas défini, essayer de l'identifier
        if (!(user as any).gender && user.firstName) {
          const firstName = user.firstName.toLowerCase().trim();
          let identifiedGender: 'H' | 'F' | null = null;
          
          if (maleNames.has(firstName)) {
            identifiedGender = 'H';
          } else if (femaleNames.has(firstName)) {
            identifiedGender = 'F';
          }
          
          if (identifiedGender) {
            await storage.updateUser(user.id, { gender: identifiedGender });
            updatedCount++;
            console.log(`[GENDER-ID] ${user.firstName} → ${identifiedGender}`);
          }
        }
      }

      res.json({ 
        message: `Genre identifié pour ${updatedCount} profils`,
        updatedCount,
        totalUsers: users.length
      });
    } catch (error) {
      console.error("Erreur identification genres:", error);
      res.status(500).json({ message: "Erreur lors de l'identification des genres" });
    }
  });

  // Route de test d'email avec profils
  app.post("/api/test-email", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }

      // Créer un email attractif avec des profils
      const emailSuccess = await emailService.sendDailyDigest({
        userEmail: email,
        userFirstName: "Thomas",
        newFlashes: 5,
        newVisits: 8,
        newMatches: 2,
        suggestedProfiles: [
          { name: "Marie", age: 52, city: "Paris" },
          { name: "Sylvie", age: 48, city: "Lyon" },
          { name: "Catherine", age: 46, city: "Marseille" },
          { name: "Nicole", age: 54, city: "Toulouse" }
        ]
      });

      if (emailSuccess) {
        res.json({ 
          message: "Email de test envoyé avec succès !",
          success: true 
        });
      } else {
        res.status(500).json({ 
          message: "Erreur lors de l'envoi de l'email de test" 
        });
      }
    } catch (error: any) {
      console.error("Erreur test email:", error);
      res.status(500).json({ 
        message: "Erreur lors du test d'email: " + error.message 
      });
    }
  });

  return httpServer;
}
