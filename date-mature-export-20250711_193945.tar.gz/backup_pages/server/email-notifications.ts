interface EmailNotificationData {
  to: string;
  firstName: string;
  subject: string;
  htmlContent: string;
  textContent: string;
}

interface FlashNotificationData {
  receiverEmail: string;
  receiverFirstName: string;
  senderName: string;
  senderAge: number;
  senderCity: string;
  additionalCount: number;
}

interface MatchNotificationData {
  userEmail: string;
  userFirstName: string;
  matchName: string;
  matchAge: number;
  matchCity: string;
}

interface DailyDigestData {
  userEmail: string;
  userFirstName: string;
  newFlashes: number;
  newVisits: number;
  newMatches: number;
  suggestedProfiles: Array<{
    name: string;
    age: number;
    city: string;
  }>;
}

interface DiscountEmailData {
  userEmail: string;
  userFirstName: string;
  discountCode: string;
  discountPercent: number;
  plan: 'premium' | 'gold';
}

interface DownsellEmailData {
  userEmail: string;
  userFirstName: string;
  originalPlan: 'premium' | 'gold';
  monthlyPrice: number;
  annualSavings: string;
}

export class EmailNotificationService {
  private apiKey: string | undefined;

  constructor() {
    this.apiKey = process.env.MAILERLITE_API_KEY;
  }

  // Ajouter un subscriber à un groupe MailerLite spécifique
  private async addToMailerLiteGroup(email: string, firstName: string, groupName: string): Promise<boolean> {
    if (!this.apiKey) {
      console.warn("MailerLite API key not configured");
      return false;
    }

    try {
      // D'abord créer/mettre à jour le subscriber
      const subscriberResponse = await fetch('https://connect.mailerlite.com/api/subscribers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          fields: {
            name: firstName
          }
        })
      });

      if (subscriberResponse.ok || subscriberResponse.status === 422) {
        // 422 = déjà existant, c'est OK
        
        // Récupérer les groupes pour trouver l'ID du groupe correspondant
        const groupsResponse = await fetch('https://connect.mailerlite.com/api/groups', {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Accept': 'application/json'
          }
        });

        if (groupsResponse.ok) {
          const groups = await groupsResponse.json();
          const targetGroup = groups.data.find((g: any) => g.name === groupName);
          
          if (targetGroup) {
            // Ajouter le subscriber au groupe
            const assignResponse = await fetch(`https://connect.mailerlite.com/api/subscribers/${email}/groups/${targetGroup.id}`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Accept': 'application/json'
              }
            });

            if (assignResponse.ok) {
              console.log(`[EMAIL] ✅ ${email} ajouté au groupe "${groupName}"`);
              return true;
            }
          } else {
            console.warn(`[EMAIL] Groupe "${groupName}" non trouvé dans MailerLite`);
          }
        }
      }
    } catch (error) {
      console.error(`[EMAIL] Erreur ajout groupe ${groupName} pour ${email}:`, error);
    }
    
    return false;
  }

  // Créer des subscribers avec des groupes/tags pour automations MailerLite
  private async createSubscriberWithTags(email: string, firstName: string, tags: string[]): Promise<boolean> {
    if (!this.apiKey) {
      console.warn("MailerLite API key not configured");
      return false;
    }

    try {
      const response = await fetch('https://connect.mailerlite.com/api/subscribers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          fields: {
            name: firstName
          }
        })
      });

      if (response.ok || response.status === 422) {
        console.log(`[EMAIL] ✅ Subscriber ${email} créé/mis à jour dans MailerLite`);
        return true;
      }
    } catch (error) {
      console.error(`[EMAIL] Erreur MailerLite pour ${email}:`, error);
    }
    
    return false;
  }

  // Flash notification - ajouter à MailerLite pour automation
  async sendFlashNotification(data: FlashNotificationData): Promise<boolean> {
    console.log(`[EMAIL] 💖 Flash notification: ${data.senderName} → ${data.receiverFirstName}`);
    
    // Créer subscriber avec tag "flash_received" pour automation MailerLite
    const success = await this.createSubscriberWithTags(
      data.receiverEmail, 
      data.receiverFirstName, 
      ['flash_received', 'app_user']
    );

    if (success) {
      console.log(`[EMAIL] ✅ Subscriber prêt pour automation "Flash reçu"`);
      console.log(`[EMAIL] 📧 Créez une automation MailerLite avec déclencheur "tag ajouté: flash_received"`);
    }

    return success;
  }

  // Match notification - ajouter à MailerLite pour automation  
  async sendMatchNotification(data: MatchNotificationData): Promise<boolean> {
    console.log(`[EMAIL] 🎉 Match notification: ${data.userFirstName} ↔ ${data.matchName}`);
    
    // Créer subscriber avec tag "new_match" pour automation MailerLite
    const success = await this.createSubscriberWithTags(
      data.userEmail, 
      data.userFirstName, 
      ['new_match', 'app_user']
    );

    if (success) {
      console.log(`[EMAIL] ✅ Subscriber prêt pour automation "Nouveau match"`);
      console.log(`[EMAIL] 📧 Créez une automation MailerLite avec déclencheur "tag ajouté: new_match"`);
    }

    return success;
  }

  // Daily digest - ajouter à MailerLite pour automation quotidienne
  async sendDailyDigest(data: DailyDigestData): Promise<boolean> {
    console.log(`[EMAIL] 📊 Daily digest: ${data.userFirstName} - ${data.newFlashes + data.newVisits + data.newMatches} activités`);
    
    // Créer subscriber avec tag "daily_digest" pour automation MailerLite
    const success = await this.createSubscriberWithTags(
      data.userEmail, 
      data.userFirstName, 
      ['daily_digest', 'app_user']
    );

    if (success) {
      console.log(`[EMAIL] ✅ Subscriber prêt pour automation "Résumé quotidien"`);
      console.log(`[EMAIL] 📧 Créez une automation MailerLite récurrente quotidienne`);
      console.log(`[EMAIL] 📝 Données disponibles: ${data.newFlashes} flashs, ${data.newVisits} visites, ${data.newMatches} matchs`);
    }

    return success;
  }

  // Inscription Premium/Gold - ajouter aux groupes MailerLite correspondants
  async notifyPremiumUpgrade(email: string, firstName: string, subscriptionType: 'premium' | 'gold'): Promise<boolean> {
    console.log(`[EMAIL] 💎 Upgrade notification: ${firstName} → ${subscriptionType.toUpperCase()}`);
    
    // Ajouter au groupe correspondant dans MailerLite
    const groupName = subscriptionType === 'premium' ? 'Premium subscribers' : 'Gold subscribers';
    const success = await this.addToMailerLiteGroup(email, firstName, groupName);

    if (success) {
      console.log(`[EMAIL] ✅ Utilisateur ajouté au groupe ${groupName} - automation de bienvenue déclenchée`);
    }

    return success;
  }

  // Newsletter signup - ajouter au groupe Newsletter prospects
  async addToNewsletter(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 📰 Newsletter signup: ${firstName}`);
    
    // Ajouter au groupe "Newsletter prospects (popup)" dans MailerLite
    const success = await this.addToMailerLiteGroup(email, firstName, "Newsletter prospects (popup)");

    if (success) {
      console.log(`[EMAIL] ✅ Subscriber ajouté au groupe Newsletter prospects - automation déclenchée`);
    }

    return success;
  }

  // Ajouter un utilisateur au groupe "Membres actifs" lors de l'inscription
  async addToActiveMembers(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 👤 New user registration: ${firstName} (${email})`);
    
    const success = await this.addToMailerLiteGroup(email, firstName, "Membres actifs (utilisateurs inscrits)");

    if (success) {
      console.log(`[EMAIL] ✅ Nouvel utilisateur ajouté au groupe Membres actifs`);
    }

    return success;
  }

  // Ajouter un utilisateur qui télécharge l'ebook (depuis Instagram/Facebook)
  async addToEbookDownloaders(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 📖 Ebook download: ${firstName} (${email})`);
    
    // Vous pouvez créer un groupe "Ebook downloaders" dans MailerLite pour cette automation
    // Pour l'instant, on l'ajoute au groupe Newsletter prospects
    const success = await this.addToMailerLiteGroup(email, firstName, "Newsletter prospects (popup)");
    
    if (success) {
      console.log(`[EMAIL] ✅ Téléchargeur ebook ajouté aux prospects newsletter`);
    }

    return success;
  }

  // Envoyer un email de récupération de panier abandonné avec code promo
  async sendDiscountEmail(data: DiscountEmailData): Promise<boolean> {
    console.log(`[EMAIL] 🛒 Discount email: ${data.userFirstName} (${data.discountPercent}% off ${data.plan})`);
    
    const planName = data.plan === 'premium' ? 'Premium' : 'Gold';
    const originalPrice = data.plan === 'premium' ? '60€' : '228€';
    const newPrice = data.plan === 'premium' ? '54€' : '182€';
    
    // Créer le subscriber avec tags spéciaux pour automation
    const success = await this.createSubscriberWithTags(data.userEmail, data.userFirstName, [
      'abandoned_cart_discount',
      `discount_${data.plan}`,
      `discount_${data.discountPercent}pct`
    ]);
    
    if (success) {
      console.log(`[EMAIL] ✅ Email récupération panier envoyé avec code ${data.discountCode}`);
      
      // Optionnel : ajouter à un groupe spécifique "Panier abandonné"
      await this.addToMailerLiteGroup(data.userEmail, data.userFirstName, "Panier abandonné");
    }

    return success;
  }
}

export const emailService = new EmailNotificationService();