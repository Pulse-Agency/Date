# Date Mature - Application de Rencontres Seniors

## Overview

This is a full-stack mature dating application built for users aged 40-75. The app features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data persistence and Socket.io for real-time messaging. The application includes a comprehensive matching system, subscription tiers, and real-time chat functionality designed for mature adults seeking meaningful relationships.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and building
- **UI Framework**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom theming
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Real-time**: Socket.io client for messaging

### Backend Architecture
- **Runtime**: Node.js with Express server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Real-time**: Socket.io server for chat functionality
- **Session Management**: Express sessions with PostgreSQL store
- **Build**: esbuild for production bundling

### Mobile-First Design
- **Responsive**: Optimized for mobile devices with max-width container
- **PWA Ready**: Configured for progressive web app deployment
- **Touch Optimized**: Gesture-friendly interface for senior users

## Key Components

### User Management System
- **Registration/Onboarding**: Multi-step process including profile creation, interests selection, and photo upload
- **Profile System**: Comprehensive user profiles with bio, interests, city, and subscription status
- **Subscription Tiers**: Three levels with balanced progression:
  - **Gratuit**: 3 flashs/jour, messages basiques
  - **Premium €60/6 mois**: 20 flashs/jour, voir qui vous a flashé, support amélioré
  - **Gold €114/12 mois**: Flashs illimités, messages illimités, profil prioritaire, mode incognito, badges exclusifs

### Matching & Flash System
- **Flash Mechanism**: Like system with daily limits based on subscription tier
- **Mutual Matching**: Automatic match creation when both users flash each other
- **Smart Suggestions**: Location-based profile prioritization with Gold user prominence

### Real-time Messaging
- **Socket.io Integration**: Live chat between matched users only
- **Message Threading**: Conversation management with read receipts
- **Typing Indicators**: Real-time typing status updates
- **Access Control**: Messaging restricted to matched users

### Notification System
- **Local Notifications**: New match alerts, unread message notifications, daily flash reminders
- **Database Storage**: Persistent notification tracking
- **Real-time Updates**: Instant notification delivery via WebSocket

## Data Flow

### User Registration Flow
1. Multi-step onboarding process
2. Profile data validation and sanitization
3. Interest selection from predefined categories
4. Photo upload handling
5. Database user creation with default free subscription

### Matching Flow
1. User views profile suggestions sorted by proximity and subscription tier
2. Flash action triggers validation (daily limits, duplicate prevention)
3. System checks for mutual flash to create automatic match
4. Match notification displayed to both users
5. Chat functionality unlocked between matched users

### Real-time Messaging Flow
1. User joins conversation room via Socket.io
2. Message validation and spam protection
3. Message persistence to database
4. Real-time broadcast to conversation participants
5. Notification creation for offline users

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React Hook Form, TanStack Query
- **UI Components**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Database**: Drizzle ORM, Neon Database serverless PostgreSQL
- **Real-time**: Socket.io for client-server communication

### Development Tools
- **Build Tools**: Vite, esbuild, TypeScript compiler
- **Code Quality**: ESLint configuration, TypeScript strict mode
- **Development**: Replit-specific plugins for debugging and development

### Third-party Integrations
- **Payment Processing**: RevenueCat Web SDK for subscription management with Stripe backend
- **Profile Photos**: RandomUser API for generating test profile images
- **Geolocation**: Browser geolocation API for city-based matching

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Database**: Neon Database PostgreSQL with connection pooling
- **Environment Variables**: DATABASE_URL configuration required
- **Admin Tools**: Development-only admin panel for testing and statistics

### Production Build
- **Frontend**: Static build output to `dist/public` directory
- **Backend**: esbuild bundle to `dist/index.js`
- **Database Migrations**: Drizzle Kit for schema management
- **Static Assets**: Served via Express static middleware

### Replit-Specific Configuration
- **Runtime Error Overlay**: Development error modal integration
- **Cartographer**: Replit development tool integration
- **Environment Detection**: Automatic development/production mode switching

## Déploiement

### Clés API Configurées
- ✅ `REVENUECAT_SECRET_KEY` - Gestion des abonnements
- ✅ `STRIPE_SECRET_KEY` + `VITE_STRIPE_PUBLIC_KEY` - Paiements sécurisés  
- ✅ `MAILERLITE_API_KEY` - Intégration newsletter et emails automatiques

### Domaine Choisi
- **Domaine principal** : `date-mature.com` (acheté chez Hostinger)
- **Configuration DNS** : À pointer vers Replit Deployments
- **SSL** : Automatique via Replit

### État de Déploiement
- ✅ Application entièrement fonctionnelle
- ✅ Base de données PostgreSQL configurée
- ✅ Interface mobile-first optimisée seniors
- ✅ Système complet de matching et messagerie
- ✅ Stripe + RevenueCat configurés pour paiements sécurisés
- ✅ Système de parrainage avec codes d'invitation
- ✅ Système d'emails automatiques MailerLite configuré et fonctionnel
- ✅ **Domaine date-mature.com en ligne avec SSL** (July 2, 2025)
- ✅ **Bugs critiques résolus : popup newsletter, upload photos, interface admin** (July 2, 2025)
- ✅ **Processus de déploiement maîtrisé par l'utilisateur** (July 2, 2025)

## Changelog
```
Changelog:
- June 29, 2025. Initial setup
- June 29, 2025. Sistema de newsletter avec popup intelligent ajouté
- June 29, 2025. Intégration MailerLite et système de paiement préparés
- June 29, 2025. Système de connexion automatique configuré
- June 29, 2025. Durées d'engagement ajoutées : Premium 6 mois, Gold 12 mois
- June 29, 2025. Messages de bienvenue personnalisés avec prénom et salutations temporelles
- June 29, 2025. Système de social proof ajouté : notifications discrètes d'abonnements
- June 29, 2025. Système de parrainage complet avec codes d'invitation et récompenses
- June 29, 2025. Migration vers RevenueCat pour la gestion des abonnements
- June 29, 2025. Intégration complète Stripe + RevenueCat pour paiements sécurisés
- June 29, 2025. Tests complets des abonnements Premium et Gold réussis
- June 30, 2025. Pages navigation complètes : Aide, Sécurité, Paramètres, Modifier profil
- June 30, 2025. Récapitulatifs économies intégrés dans cartes abonnements
- June 30, 2025. Rééquilibrage plans : Premium 20 flashs/jour, Gold fonctionnalités exclusives
- June 30, 2025. Navigation home avec logo cœur ajoutée en haut et bas de toutes les pages
- June 30, 2025. Système de notifications visuelles ajouté : cœur qui vibre pour matches, animations pour flashs/messages
- June 30, 2025. Header enrichi avec compteurs temps réel : flashs restants, messages non lus, nouveaux matches
- June 30, 2025. Préparation système email MailerLite pour notifications personnalisées par événement
- June 30, 2025. Élargissement tranche d'âge cible : 40-75 ans au lieu de 50-75 ans pour augmenter la base utilisateurs
- June 30, 2025. Configuration complète MailerLite avec clé API pour emails automatiques (flashs, matches, digest quotidien)
- July 01, 2025. Rebranding complet vers "Date Mature" : header, pages, codes de parrainage (MATURE prefix)
- July 01, 2025. Mise à jour tranche d'âge cohérente : messages "après 40 ans" au lieu de "après 50 ans"
- July 01, 2025. Optimisation notifications sociales : âges 40-65 ans pour cibler la démographie correcte
- July 02, 2025. Corrections techniques majeures : popup newsletter intelligente (30s + 1x/jour), upload photos fonctionnel, textes optimisés
- July 02, 2025. Intégration MailerLite API complète avec clé secrète pour automation emails
- July 02, 2025. Processus de déploiement maîtrisé : corrections dev → bouton Deploy → production live
- July 02, 2025. Email obligatoire dans inscription : plus de confusion de connexion, intégration MailerLite automatique
- July 02, 2025. Upload photos entièrement fonctionnel : synchronisation PhotoUpload/formulaire, endpoint /api/upload/photo opérationnel
- July 02, 2025. Modification de profil corrigée : chargement données utilisateur, gestion types TypeScript, interface stable
- July 02, 2025. Interface admin améliorée : recherche par nom/email/ville, pagination 10 par page, bouton upgrade Premium temporaire
- July 03, 2025. Système récupération panier abandonné complet : codes promo "offre découverte" (-10% Premium, -20% Gold), détection automatique après 24h, intégration MailerLite avec tags spécialisés, interface checkout avec validation temps réel
```

## User Preferences
```
Preferred communication style: Simple, everyday language.
```