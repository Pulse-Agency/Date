import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NewsletterPopup from "@/components/newsletter-popup";
import { useNewsletterPopup } from "@/hooks/use-newsletter-popup";
import SimpleNotifications, { useNotificationEvents, MatchAnimation } from "@/components/simple-notifications";
import EmergencyFix from "@/components/emergency-fix";
import { useState, useEffect } from "react";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";
import Landing from "@/pages/landing";
import AccueilV2 from "@/pages/accueil-v2";
import Home from "@/pages/home";
import Onboarding from "@/pages/onboarding";
import Messages from "@/pages/messages";
import Chat from "@/pages/chat";
import Subscription from "@/pages/subscription";
import Checkout from "@/pages/checkout";
import Profile from "@/pages/profile";
import AdminFixed from "@/pages/admin-fixed";
import Profiles from "@/pages/profiles";
import Referral from "@/pages/referral";
import RevenueCatSubscription from "@/pages/revenuecat-subscription";
import Login from "@/pages/login";
import NotFound from "@/pages/not-found";
import Help from "@/pages/help";
import Security from "@/pages/security";
import Settings from "@/pages/settings";
import EditProfile from "@/pages/edit-profile";
import CGV from "@/pages/legal/cgv";
import MentionsLegales from "@/pages/legal/mentions-legales";
import PolitiqueConfidentialite from "@/pages/legal/politique-confidentialite";
import AdminUsers from "@/pages/admin-users-perfect";
import AdminDebug from "@/pages/admin-debug";
import AdminSimpleWorking from "@/pages/admin-simple-working";
import AdminWorking from "@/pages/admin-working";
import AdminDashboard from "@/pages/admin-dashboard";
import AdminSimple from "@/pages/admin-simple";
import AdminPage from "@/pages/admin";
import FixPopup from "@/pages/fix-popup";
import Preferences from "@/pages/preferences";
import MonthlyOffer from "@/pages/monthly-offer";
import DemoAnimations from "@/pages/demo-animations";
import ResetPopup from "@/pages/reset-popup";
import TestPopup from "@/pages/test-popup";
import ResetPopupEbook from "@/pages/reset-popup-ebook";
import DiagnosticPopup from "@/pages/diagnostic-popup";
import TestPopupSimple from "@/pages/test-popup-simple";
import DebugPopup from "@/pages/debug-popup";
import TestPopupFinal from "@/pages/test-popup-final";
import TestFlashBonus from "@/pages/test-flash-bonus";
import EbookPage from "@/pages/ebook";

function AuthenticatedRoute() {
  const { data: currentUser, isLoading } = useQuery({
    queryKey: ["/api/users/current"],
    retry: false
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  // Si utilisateur connecté, vérifier s'il a complété ses préférences
  if (currentUser) {
    // Si les préférences ne sont pas complétées, rediriger vers la page préférences
    if (!(currentUser as any).preferencesCompleted) {
      return <Preferences />;
    }
    return <Home />;
  }

  // Pour les visiteurs non connectés, toujours afficher la landing page
  return <Landing />;
}

function Router() {
  // Tracking automatique des pages vues avec Google Analytics
  useAnalytics();
  
  return (
    <Switch>
      <Route path="/" component={AuthenticatedRoute} />
      <Route path="/accueil-v2" component={AccueilV2} />
      <Route path="/demo-animations" component={DemoAnimations} />
      <Route path="/reset-popup" component={ResetPopup} />
      <Route path="/reset-popup-ebook" component={ResetPopupEbook} />
      <Route path="/diagnostic-popup" component={DiagnosticPopup} />
      <Route path="/test-popup-simple" component={TestPopupSimple} />
      <Route path="/debug-popup" component={DebugPopup} />
      <Route path="/test-popup-final" component={TestPopupFinal} />
      <Route path="/test-popup" component={TestPopup} />
      <Route path="/test-flash-bonus" component={TestFlashBonus} />
      <Route path="/login" component={Login} />
      <Route path="/home" component={Home} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/messages" component={Messages} />
      <Route path="/chat/:partnerId" component={Chat} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/revenuecat-subscription" component={RevenueCatSubscription} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/profile" component={Profile} />
      <Route path="/edit-profile" component={EditProfile} />
      <Route path="/settings" component={Settings} />
      <Route path="/help" component={Help} />
      <Route path="/security" component={Security} />
      <Route path="/referral" component={Referral} />
      <Route path="/admin" component={AdminUsers} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/debug" component={AdminDebug} />
      <Route path="/admin-simple" component={AdminSimple} />
      <Route path="/landing" component={Landing} />
      <Route path="/fix-popup" component={FixPopup} />
      <Route path="/profiles" component={Profiles} />
      <Route path="/legal/mentions-legales" component={MentionsLegales} />
      <Route path="/legal/cgv" component={CGV} />
      <Route path="/legal/politique-confidentialite" component={PolitiqueConfidentialite} />
      <Route path="/preferences" component={Preferences} />
      <Route path="/monthly-offer" component={MonthlyOffer} />
      <Route path="/ebook" component={EbookPage} />
      <Route path="/guide" component={EbookPage} />
      <Route path="/conseils" component={EbookPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { showPopup, closePopup } = useNewsletterPopup();
  const notificationEvents = useNotificationEvents();
  const [showMatchAnimation, setShowMatchAnimation] = useState(false);
  const [matchedUserName, setMatchedUserName] = useState("");

  // Initialiser Google Analytics au chargement de l'app
  useEffect(() => {
    // Vérifier si la clé Google Analytics est présente
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);

  // Exposer les notifications globalement pour les autres composants
  (window as any).showNotifications = {
    match: (name: string) => {
      notificationEvents.showMatchNotification(name);
      setMatchedUserName(name);
      setShowMatchAnimation(true);
    },
    flash: notificationEvents.showFlashNotification,
    message: notificationEvents.showMessageNotification,
    visit: notificationEvents.showVisitNotification,
    upgrade: notificationEvents.showUpgradeNotification
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="w-full min-h-screen bg-white relative overflow-hidden">
          <Toaster />
          <Router />

          {/* Newsletter popup avec déclencheurs multiples */}
          {showPopup && (
            <NewsletterPopup 
              isVisible={showPopup} 
              onClose={closePopup}
            />
          )}
          
          {/* Animations de notifications */}
          <SimpleNotifications 
            events={notificationEvents.events}
            onEventComplete={notificationEvents.removeNotification}
          />
          
          {/* Animation plein écran pour les matches */}
          <MatchAnimation
            isVisible={showMatchAnimation}
            matchName={matchedUserName}
            onComplete={() => setShowMatchAnimation(false)}
          />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
