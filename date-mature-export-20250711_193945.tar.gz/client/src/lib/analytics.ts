// Définir la fonction gtag globalement
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Initialiser Google Analytics
export const initGA = () => {
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    return;
  }

  // Ajouter le script Google Analytics dans le head
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  // Initialiser gtag
  const script2 = document.createElement('script');
  script2.innerHTML = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}');
  `;
  document.head.appendChild(script2);
};

// Suivre les pages vues - utile pour les applications single-page
export const trackPageView = (url: string) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
  if (!measurementId) return;
  
  window.gtag('config', measurementId, {
    page_path: url
  });
};

// Suivre les événements personnalisés
export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value,
  });
};

// Événements spécifiques à Date Mature
export const trackDateMatureEvents = {
  // Inscription
  signUp: (method: string) => trackEvent('sign_up', 'engagement', method),
  
  // Préférences
  completePreferences: (preferences: any) => trackEvent('complete_preferences', 'onboarding', `age_${preferences.ageRange}_gender_${preferences.genderPreference}`),
  
  // Interactions sociales
  flashSent: () => trackEvent('flash_sent', 'social'),
  matchCreated: () => trackEvent('match_created', 'social'),
  messageSent: () => trackEvent('message_sent', 'social'),
  
  // Abonnements
  subscriptionUpgrade: (plan: string) => trackEvent('subscription_upgrade', 'conversion', plan),
  subscriptionView: (plan: string) => trackEvent('subscription_view', 'conversion', plan),
  
  // Navigation
  profileView: () => trackEvent('profile_view', 'engagement'),
  searchPerformed: () => trackEvent('search_performed', 'engagement'),
};