export const generateTestProfiles = () => {
  const frenchNames = {
    female: [
      "Marie", "Françoise", "Nicole", "Sylvie", "Catherine", "Christine", "Brigitte", 
      "Martine", "Monique", "Jacqueline", "Danielle", "Annie", "Colette", "Simone",
      "Michèle", "Claudine", "Éliane", "Janine", "Ginette", "Denise", "Paulette",
      "Jeannine", "Yvette", "Andrée", "Odette"
    ],
    male: [
      "Jean", "Pierre", "Michel", "André", "Philippe", "Alain", "Bernard", "Robert",
      "Jacques", "Daniel", "Claude", "Gérard", "François", "Roger", "Marcel", 
      "Christian", "Henri", "Louis", "Paul", "Maurice", "Raymond", "Lucien",
      "Albert", "Georges", "René"
    ]
  };

  const cities = [
    "Paris", "Lyon", "Marseille", "Toulouse", "Nice", "Nantes", "Strasbourg",
    "Montpellier", "Bordeaux", "Lille", "Rennes", "Reims", "Le Havre", "Saint-Étienne",
    "Toulon", "Grenoble", "Dijon", "Angers", "Villeurbanne", "Le Mans", "Aix-en-Provence",
    "Clermont-Ferrand", "Brest", "Tours", "Limoges", "Amiens", "Perpignan", "Metz",
    "Besançon", "Boulogne-Billancourt"
  ];

  const interests = [
    "Randonnée", "Cuisine", "Jardinage", "Lecture", "Voyages", "Musique", 
    "Cinéma", "Peinture", "Photographie", "Danse", "Théâtre", "Bridge",
    "Marche", "Natation", "Yoga", "Tricot", "Pétanque", "Cyclisme",
    "Bricolage", "Histoire", "Art", "Nature", "Animaux", "Bénévolat"
  ];

  const bios = [
    "Passionnée par la vie, j'aime partager de bons moments autour d'un bon repas.",
    "Ancien professeur, je cultive ma curiosité à travers les voyages et la lecture.",
    "Retraité actif, je partage mon temps entre mes petits-enfants et mes passions.",
    "Amoureuse de la nature, je profite de ma retraite pour découvrir de nouveaux horizons.",
    "Ex-cadre d'entreprise, je savoure enfin le temps libre pour mes loisirs favoris.",
    "Veuve depuis peu, je souhaite retrouver la joie de partager avec quelqu'un de spécial.",
    "Épicurien dans l'âme, j'apprécie les plaisirs simples de la vie.",
    "Sportive dans l'âme, je maintiens ma forme et cherche un partenaire actif.",
    "Artiste amateur, je peins et dessine pour exprimer ma créativité.",
    "Grand-père comblé, je cherche une compagne pour profiter pleinement de la retraite."
  ];

  const subscriptions: Array<"gratuit" | "premium" | "gold"> = ["gratuit", "premium", "gold"];

  const profiles = [];

  // Generate 25 female profiles
  for (let i = 0; i < 25; i++) {
    const name = frenchNames.female[i % frenchNames.female.length];
    const age = Math.floor(Math.random() * 36) + 40; // 40-75
    const city = cities[Math.floor(Math.random() * cities.length)];
    const bio = bios[Math.floor(Math.random() * bios.length)];
    const subscription = subscriptions[Math.floor(Math.random() * subscriptions.length)];
    
    // Select 2-4 random interests
    const selectedInterests = [];
    const numberOfInterests = Math.floor(Math.random() * 3) + 2; // 2-4 interests
    const shuffledInterests = [...interests].sort(() => 0.5 - Math.random());
    for (let j = 0; j < numberOfInterests; j++) {
      selectedInterests.push(shuffledInterests[j]);
    }

    profiles.push({
      firstName: name,
      gender: "F" as const,
      age,
      city,
      bio,
      interests: selectedInterests,
      photo: `https://randomuser.me/api/portraits/women/${Math.floor(Math.random() * 30) + 40}.jpg`,
      subscription,
      email: `${name.toLowerCase()}${age}@example.com`,
      isTestProfile: true
    });
  }

  // Generate 25 male profiles
  for (let i = 0; i < 25; i++) {
    const name = frenchNames.male[i % frenchNames.male.length];
    const age = Math.floor(Math.random() * 36) + 40; // 40-75
    const city = cities[Math.floor(Math.random() * cities.length)];
    const bio = bios[Math.floor(Math.random() * bios.length)];
    const subscription = subscriptions[Math.floor(Math.random() * subscriptions.length)];
    
    // Select 2-4 random interests
    const selectedInterests = [];
    const numberOfInterests = Math.floor(Math.random() * 3) + 2; // 2-4 interests
    const shuffledInterests = [...interests].sort(() => 0.5 - Math.random());
    for (let j = 0; j < numberOfInterests; j++) {
      selectedInterests.push(shuffledInterests[j]);
    }

    profiles.push({
      firstName: name,
      gender: "H" as const,
      age,
      city,
      bio,
      interests: selectedInterests,
      photo: `https://randomuser.me/api/portraits/men/${Math.floor(Math.random() * 30) + 40}.jpg`,
      subscription,
      email: `${name.toLowerCase()}${age}@example.com`,
      isTestProfile: true
    });
  }

  return profiles;
};
