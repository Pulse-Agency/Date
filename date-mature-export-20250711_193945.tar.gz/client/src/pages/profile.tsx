import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Edit, Settings, Crown, HelpCircle, Shield, LogOut, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BottomNavigation from "@/components/bottom-navigation";

export default function Profile() {
  // Get current user
  const { data: currentUserData } = useQuery({
    queryKey: ["/api/users/current"],
  });

  const currentUser = currentUserData?.user;

  // Get user stats (matches, messages, etc.)
  const { data: matchesData } = useQuery({
    queryKey: ["/api/matches", currentUser?.id],
    enabled: !!currentUser?.id,
  });

  const matches = matchesData?.matches || [];
  const totalConversations = matches.length;
  const unreadMessages = matches.reduce((total: number, match: any) => 
    total + match.unreadCount, 0);

  // Mock stats for demo
  const stats = {
    totalFlashes: 47,
    matches: totalConversations,
    conversations: totalConversations
  };

  const getSubscriptionBadge = () => {
    if (!currentUser) return null;
    
    if (currentUser.subscription === 'gold') {
      return (
        <Badge className="bg-yellow-500 text-white px-4 py-2 text-sm font-semibold">
          <Crown className="h-4 w-4 mr-2" />
          Membre Gold
        </Badge>
      );
    }
    if (currentUser.subscription === 'premium') {
      return (
        <Badge className="bg-purple-600 text-white px-4 py-2 text-sm font-semibold">
          <Crown className="h-4 w-4 mr-2" />
          Membre Premium
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="px-4 py-2 text-sm font-semibold">
        Membre Gratuit
      </Badge>
    );
  };

  if (!currentUser) {
    return (
      <div className="h-screen flex items-center justify-center">
        <p>Chargement...</p>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-primary to-pink-600 text-white p-6 relative">
        <Link href="/">
          <Button variant="ghost" size="sm" className="absolute top-6 left-6 text-white hover:bg-white/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        
        <div className="text-center pt-8">
          <img
            src={currentUser.photo || "https://randomuser.me/api/portraits/men/45.jpg"}
            alt="Mon profil"
            className="w-24 h-24 rounded-full mx-auto border-4 border-white/20 object-cover mb-4"
          />
          <h2 className="text-2xl font-bold">
            {currentUser.firstName}, {currentUser.age} ans
          </h2>
          <p className="opacity-90 mb-3">
            📍 {currentUser.city}
          </p>
          {getSubscriptionBadge()}
        </div>
      </div>

      {/* Profile Stats */}
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="grid grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-2xl font-bold text-primary">{stats.totalFlashes}</div>
            <div className="text-sm text-gray-600">Flashs envoyés</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-500">{stats.matches}</div>
            <div className="text-sm text-gray-600">Matches</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-500">{stats.conversations}</div>
            <div className="text-sm text-gray-600">Conversations</div>
          </div>
        </div>
      </div>

      {/* Profile Menu */}
      <div className="flex-1 bg-gray-50 overflow-y-auto">
        <div className="p-6 space-y-4">
          
          <Card>
            <CardContent className="p-0 divide-y divide-gray-100">
              <Link href="/edit-profile">
                <Button
                  variant="ghost"
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-gray-50 h-auto"
                >
                  <div className="flex items-center">
                    <Edit className="h-5 w-5 text-primary mr-4" />
                    <span className="font-medium text-lg">Modifier mon profil</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </Button>
              </Link>
              
              <Link href="/settings">
                <Button
                  variant="ghost"
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-gray-50 h-auto"
                >
                  <div className="flex items-center">
                    <Settings className="h-5 w-5 text-primary mr-4" />
                    <span className="font-medium text-lg">Paramètres</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </Button>
              </Link>
              
              <Link href="/subscription">
                <Button
                  variant="ghost"
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-gray-50 h-auto"
                >
                  <div className="flex items-center">
                    <Crown className="h-5 w-5 text-yellow-500 mr-4" />
                    <span className="font-medium text-lg">Gérer mon abonnement</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-0 divide-y divide-gray-100">
              <Link href="/help">
                <Button
                  variant="ghost"
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-gray-50 h-auto"
                >
                  <div className="flex items-center">
                    <HelpCircle className="h-5 w-5 text-primary mr-4" />
                    <span className="font-medium text-lg">Centre d'aide</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </Button>
              </Link>
              
              <Link href="/security">
                <Button
                  variant="ghost"
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-gray-50 h-auto"
                >
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-primary mr-4" />
                    <span className="font-medium text-lg">Sécurité et confidentialité</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-0">
              <Button
                variant="ghost"
                className="w-full p-5 flex items-center text-left hover:bg-red-50 text-red-500 h-auto"
              >
                <LogOut className="h-5 w-5 mr-4" />
                <span className="font-medium text-lg">Se déconnecter</span>
              </Button>
            </CardContent>
          </Card>
          
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation unreadMessages={unreadMessages} />
    </div>
  );
}
