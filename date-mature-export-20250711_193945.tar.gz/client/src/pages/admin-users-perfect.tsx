import { useQuery, useMutation } from "@tanstack/react-query";
import { Shield, Users, Crown, Mail, MapPin, Calendar, ArrowLeft, Plus, UserX, Edit, Search, Upload, Download } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import PhotoUpload from "@/components/photo-upload";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  gender: "H" | "F";
  age: number;
  city: string;
  subscription: string;
  bio?: string;
  photo?: string;
  isTestProfile?: boolean;
  region?: string;
  photos?: string[];
}

export default function AdminUsersPerfect() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [previewUser, setPreviewUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilters, setGenderFilters] = useState({ H: false, F: false });
  const [citySearch, setCitySearch] = useState('');
  const [subscriptionFilters, setSubscriptionFilters] = useState({ gratuit: false, premium: false, gold: false });
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [isImporting, setIsImporting] = useState(false);
  const [isImportingPhotos, setIsImportingPhotos] = useState(false);
  const [isImportingDirect, setIsImportingDirect] = useState(false);

  // Appliquer les filtres automatiquement selon les paramètres d'URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const subscription = urlParams.get('subscription');
    
    // Réinitialiser tous les filtres d'abonnement d'abord
    if (subscription === 'premium') {
      setSubscriptionFilters({ gratuit: false, premium: true, gold: false });
    } else if (subscription === 'gold') {
      setSubscriptionFilters({ gratuit: false, premium: false, gold: true });
    } else if (subscription === null) {
      // Si pas de paramètre subscription, montrer tous les abonnements
      setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
    }
    
    // Réinitialiser la page à 1 quand on change de filtre
    setCurrentPage(1);
  }, [location]);
  const [newUser, setNewUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    age: 50,
    city: '',
    subscription: 'gratuit',
    bio: '',
    photo: '',
    isTestProfile: true
  });

  const { data: usersData, isLoading } = useQuery({
    queryKey: ["/api/admin/users"],
    refetchInterval: 5000,
    staleTime: 0,
    cacheTime: 0,
  });

  const users = usersData?.users || [];
  const stats = usersData?.stats || { total: 0, premium: 0, gold: 0, withPhotos: 0, starProfiles: 0 };

  // Filtrer les utilisateurs selon les critères
  const filteredUsers = users.filter((user: User) => {
    const matchesSearch = !searchTerm || 
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGender = (!genderFilters.H && !genderFilters.F) || 
      (genderFilters.H && user.gender === 'H') ||
      (genderFilters.F && user.gender === 'F');
      
    const matchesCity = !citySearch || user.city.toLowerCase().includes(citySearch.toLowerCase());
    
    const matchesSubscription = (!subscriptionFilters.gratuit && !subscriptionFilters.premium && !subscriptionFilters.gold) ||
      (subscriptionFilters.gratuit && user.subscription === 'gratuit') ||
      (subscriptionFilters.premium && user.subscription === 'premium') ||
      (subscriptionFilters.gold && user.subscription === 'gold');
    
    return matchesSearch && matchesGender && matchesCity && matchesSubscription;
  });

  // Tri alphabétique par prénom
  const sortedUsers = [...filteredUsers].sort((a, b) => {
    return a.firstName.localeCompare(b.firstName, 'fr', { sensitivity: 'base' });
  });

  // Pagination
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = sortedUsers.slice(indexOfFirstUser, indexOfLastUser);
  const totalPages = Math.ceil(sortedUsers.length / usersPerPage);

  const createUserMutation = useMutation({
    mutationFn: (userData: any) => apiRequest("/api/admin/users", "POST", userData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Utilisateur créé avec succès" });
      setShowAddUser(false);
      setNewUser({
        firstName: '',
        lastName: '',
        email: '',
        age: 50,
        city: '',
        subscription: 'gratuit',
        bio: '',
        photo: '',
        isTestProfile: true
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de créer l'utilisateur",
        variant: "destructive"
      });
    }
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ id, ...userData }: any) => apiRequest(`/api/admin/users/${id}`, "PUT", userData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Utilisateur mis à jour avec succès" });
      setEditingUser(null);
      setPreviewUser(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de mettre à jour l'utilisateur",
        variant: "destructive"
      });
    }
  });

  const deleteUserMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/users/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Utilisateur supprimé avec succès" });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de supprimer l'utilisateur",
        variant: "destructive"
      });
    }
  });

  const handleUpdateUser = (id: number, userData: any) => {
    updateUserMutation.mutate({ id, ...userData });
  };

  const handleCreateUser = () => {
    createUserMutation.mutate(newUser);
  };

  const handleDeleteUser = (id: number) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer cet utilisateur ?")) {
      deleteUserMutation.mutate(id);
    }
  };

  const handleImportUsers = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un fichier JSON",
        variant: "destructive"
      });
      return;
    }

    setIsImporting(true);
    
    try {
      const text = await file.text();
      const users = JSON.parse(text);
      
      if (!Array.isArray(users)) {
        throw new Error("Le fichier doit contenir un tableau d'utilisateurs");
      }

      const response = await fetch('/api/admin/import-users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ users }),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de l\'import');
      }

      const result = await response.json();
      
      toast({
        title: "Import réussi",
        description: `${result.imported} utilisateurs importés avec succès`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
    } catch (error) {
      console.error('Erreur import:', error);
      toast({
        title: "Erreur d'import",
        description: error instanceof Error ? error.message : "Une erreur s'est produite",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const handleExportUsers = () => {
    const dataStr = JSON.stringify(users, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `users-backup-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportPhotos = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un fichier JSON",
        variant: "destructive"
      });
      return;
    }

    setIsImportingPhotos(true);
    
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      
      const response = await fetch('/api/admin/import-photos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Erreur lors de l\'import des photos');
      }

      toast({
        title: "Import des photos réussi",
        description: `${result.updated} photos mises à jour`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
    } catch (error) {
      console.error('Erreur import photos:', error);
      toast({
        title: "Erreur d'import des photos",
        description: error instanceof Error ? error.message : "Une erreur s'est produite",
        variant: "destructive"
      });
    } finally {
      setIsImportingPhotos(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const handleDirectImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un fichier JSON",
        variant: "destructive"
      });
      return;
    }

    setIsImportingDirect(true);
    
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      
      const response = await fetch('/api/admin/direct-import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Erreur lors de l\'import direct');
      }

      toast({
        title: "Import direct réussi",
        description: `${result.imported} utilisateurs importés`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
    } catch (error) {
      console.error('Erreur import direct:', error);
      toast({
        title: "Erreur d'import direct",
        description: error instanceof Error ? error.message : "Une erreur s'est produite",
        variant: "destructive"
      });
    } finally {
      setIsImportingDirect(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-4">
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Gestion des utilisateurs</h1>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Premium</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">{stats.premium}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Gold</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{stats.gold}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avec photo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{stats.withPhotos}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Profils ⭐</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{stats.starProfiles}</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-4 mb-6">
          <Button onClick={() => setShowAddUser(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nouvel utilisateur
          </Button>
          <Button onClick={handleExportUsers} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exporter
          </Button>
          <div className="flex gap-2">
            <label className="cursor-pointer">
              <input
                type="file"
                accept=".json"
                onChange={handleImportUsers}
                className="hidden"
              />
              <Button variant="outline" disabled={isImporting} asChild>
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  {isImporting ? 'Import...' : 'Importer JSON'}
                </span>
              </Button>
            </label>
            <label className="cursor-pointer">
              <input
                type="file"
                accept=".json"
                onChange={handleImportPhotos}
                className="hidden"
              />
              <Button variant="outline" disabled={isImportingPhotos} asChild>
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  {isImportingPhotos ? 'Import...' : 'Photos'}
                </span>
              </Button>
            </label>
            <label className="cursor-pointer">
              <input
                type="file"
                accept=".json"
                onChange={handleDirectImport}
                className="hidden"
              />
              <Button variant="outline" disabled={isImportingDirect} asChild>
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  {isImportingDirect ? 'Import...' : 'Direct'}
                </span>
              </Button>
            </label>
          </div>
        </div>

        {/* Filtres */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Input
                  placeholder="Rechercher par nom ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
                <Input
                  placeholder="Rechercher par ville..."
                  value={citySearch}
                  onChange={(e) => setCitySearch(e.target.value)}
                  className="flex-1"
                />
              </div>
              
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Genre:</label>
                  <label className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={genderFilters.H}
                      onChange={(e) => setGenderFilters({...genderFilters, H: e.target.checked})}
                    />
                    <span>♂️ Hommes</span>
                  </label>
                  <label className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={genderFilters.F}
                      onChange={(e) => setGenderFilters({...genderFilters, F: e.target.checked})}
                    />
                    <span>♀️ Femmes</span>
                  </label>
                </div>
                
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Abonnement:</label>
                  <label className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={subscriptionFilters.gratuit}
                      onChange={(e) => setSubscriptionFilters({...subscriptionFilters, gratuit: e.target.checked})}
                    />
                    <span>🆓 Gratuit</span>
                  </label>
                  <label className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={subscriptionFilters.premium}
                      onChange={(e) => setSubscriptionFilters({...subscriptionFilters, premium: e.target.checked})}
                    />
                    <span>⭐ Premium</span>
                  </label>
                  <label className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={subscriptionFilters.gold}
                      onChange={(e) => setSubscriptionFilters({...subscriptionFilters, gold: e.target.checked})}
                    />
                    <span>👑 Gold</span>
                  </label>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Utilisateurs ({sortedUsers.length} résultats)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currentUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 cursor-pointer hover:ring-2 hover:ring-red-300 transition-all"
                      onClick={() => setPreviewUser(user)}
                      title="Cliquer pour voir le profil complet"
                    >
                      <img 
                        src={user.photo || user.photos?.[0] || '/placeholder.jpg'} 
                        alt={user.firstName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{user.firstName} {user.lastName}</p>
                      <p className="text-sm text-gray-600">{user.city} • {user.age} ans</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={user.gender === 'H' ? 'default' : 'secondary'}>
                      {user.gender === 'H' ? '♂️' : '♀️'}
                    </Badge>
                    
                    <Badge variant={
                      user.subscription === 'gold' ? 'default' : 
                      user.subscription === 'premium' ? 'secondary' : 'outline'
                    }>
                      {user.subscription === 'gold' ? '👑 Gold' : 
                       user.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                    </Badge>
                    
                    <Button size="sm" variant="ghost" onClick={() => setEditingUser(user)}>
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <UserX className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} sur {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de prévisualisation */}
      {previewUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex flex-col items-center mb-4">
              <img 
                src={previewUser.photo || previewUser.photos?.[0] || '/placeholder.jpg'} 
                alt={previewUser.firstName}
                className="w-24 h-24 rounded-full object-cover mb-4"
              />
              <h2 className="text-2xl font-bold mb-2">{previewUser.firstName} {previewUser.lastName}</h2>
              <div className="flex gap-2 mb-4">
                <Badge variant={previewUser.gender === 'H' ? 'default' : 'secondary'}>
                  {previewUser.gender === 'H' ? '♂️ Homme' : '♀️ Femme'}
                </Badge>
                <Badge variant={
                  previewUser.subscription === 'gold' ? 'default' : 
                  previewUser.subscription === 'premium' ? 'secondary' : 'outline'
                }>
                  {previewUser.subscription === 'gold' ? '👑 Gold' : 
                   previewUser.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                </Badge>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <span>{previewUser.age} ans</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span>{previewUser.city}</span>
              </div>
              {previewUser.region && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span>{previewUser.region}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-500" />
                <span className="text-sm">{previewUser.email}</span>
              </div>
              {previewUser.bio && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Bio:</h4>
                  <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">
                    {previewUser.bio}
                  </p>
                </div>
              )}
            </div>
            
            <div className="flex gap-2 mt-6">
              <Button 
                variant="outline" 
                onClick={() => setPreviewUser(null)}
                className="flex-1"
              >
                Fermer
              </Button>
              <Button 
                onClick={() => {
                  setPreviewUser(null);
                  setEditingUser(previewUser);
                }}
                className="flex-1"
              >
                Modifier
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal d'édition */}
      {editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Modifier {editingUser.firstName}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Prénom</Label>
                <Input
                  id="firstName"
                  value={editingUser.firstName}
                  onChange={(e) => setEditingUser({...editingUser, firstName: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="lastName">Nom</Label>
                <Input
                  id="lastName"
                  value={editingUser.lastName || ''}
                  onChange={(e) => setEditingUser({...editingUser, lastName: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({...editingUser, email: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="age">Âge</Label>
                <Input
                  id="age"
                  type="number"
                  min="18"
                  max="100"
                  value={editingUser.age}
                  onChange={(e) => setEditingUser({...editingUser, age: parseInt(e.target.value)})}
                />
              </div>
              
              <div>
                <Label htmlFor="city">Ville</Label>
                <Input
                  id="city"
                  value={editingUser.city}
                  onChange={(e) => setEditingUser({...editingUser, city: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="gender">Genre</Label>
                <Select value={editingUser.gender} onValueChange={(value) => setEditingUser({...editingUser, gender: value as "H" | "F"})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner le genre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="H">♂️ Homme</SelectItem>
                    <SelectItem value="F">♀️ Femme</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="subscription">Abonnement</Label>
                <Select value={editingUser.subscription} onValueChange={(value) => setEditingUser({...editingUser, subscription: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner l'abonnement" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gratuit">🆓 Gratuit</SelectItem>
                    <SelectItem value="premium">⭐ Premium</SelectItem>
                    <SelectItem value="gold">👑 Gold</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="md:col-span-2">
                <Label htmlFor="bio">Bio</Label>
                <textarea
                  id="bio"
                  value={editingUser.bio || ''}
                  onChange={(e) => setEditingUser({...editingUser, bio: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  rows={3}
                />
              </div>
              
              <div className="md:col-span-2">
                <Label>Photo</Label>
                <PhotoUpload
                  currentPhoto={editingUser.photo}
                  onPhotoUploaded={(photoUrl) => setEditingUser({...editingUser, photo: photoUrl})}
                />
              </div>
            </div>
            
            <div className="flex gap-2 mt-6">
              <Button 
                variant="outline" 
                onClick={() => setEditingUser(null)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button 
                onClick={() => handleUpdateUser(editingUser.id, editingUser)}
                className="flex-1"
                disabled={updateUserMutation.isPending}
              >
                {updateUserMutation.isPending ? 'Sauvegarde...' : 'Sauvegarder'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de création */}
      {showAddUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Nouvel utilisateur</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="newFirstName">Prénom</Label>
                <Input
                  id="newFirstName"
                  value={newUser.firstName}
                  onChange={(e) => setNewUser({...newUser, firstName: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="newLastName">Nom</Label>
                <Input
                  id="newLastName"
                  value={newUser.lastName}
                  onChange={(e) => setNewUser({...newUser, lastName: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="newEmail">Email</Label>
                <Input
                  id="newEmail"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="newAge">Âge</Label>
                <Input
                  id="newAge"
                  type="number"
                  min="18"
                  max="100"
                  value={newUser.age}
                  onChange={(e) => setNewUser({...newUser, age: parseInt(e.target.value)})}
                />
              </div>
              
              <div>
                <Label htmlFor="newCity">Ville</Label>
                <Input
                  id="newCity"
                  value={newUser.city}
                  onChange={(e) => setNewUser({...newUser, city: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="newSubscription">Abonnement</Label>
                <Select value={newUser.subscription} onValueChange={(value) => setNewUser({...newUser, subscription: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner l'abonnement" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gratuit">🆓 Gratuit</SelectItem>
                    <SelectItem value="premium">⭐ Premium</SelectItem>
                    <SelectItem value="gold">👑 Gold</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="md:col-span-2">
                <Label htmlFor="newBio">Bio</Label>
                <textarea
                  id="newBio"
                  value={newUser.bio}
                  onChange={(e) => setNewUser({...newUser, bio: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  rows={3}
                />
              </div>
              
              <div className="md:col-span-2">
                <Label>Photo</Label>
                <PhotoUpload
                  currentPhoto={newUser.photo}
                  onPhotoUploaded={(photoUrl) => setNewUser({...newUser, photo: photoUrl})}
                />
              </div>
            </div>
            
            <div className="flex gap-2 mt-6">
              <Button 
                variant="outline" 
                onClick={() => setShowAddUser(false)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button 
                onClick={handleCreateUser}
                className="flex-1"
                disabled={createUserMutation.isPending}
              >
                {createUserMutation.isPending ? 'Création...' : 'Créer'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}