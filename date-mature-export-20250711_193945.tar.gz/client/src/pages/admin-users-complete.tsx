// Interface admin complète avec tous les modes de sélection avancés
import { Shield, Users, Crown, Mail, MapPin, Calendar, ArrowLeft, Plus, UserX, Edit, Search, Upload, Download, Trash2, Check, X, Eye, Filter, SortAsc, ChevronLeft, ChevronRight } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import PhotoUpload from "@/components/photo-upload";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  gender: "H" | "F";
  age: number;
  city: string;
  region: string;
  subscription: string;
  bio?: string;
  photos?: string[];
  isTestProfile?: boolean;
}

export default function AdminUsersComplete() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilters, setGenderFilters] = useState({ H: false, F: false });
  const [citySearch, setCitySearch] = useState('');
  const [subscriptionFilters, setSubscriptionFilters] = useState({ gratuit: false, premium: false, gold: false });
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [selectedUsers, setSelectedUsers] = useState<Set<number>>(new Set());
  const [selectMode, setSelectMode] = useState(false);
  const [bulkAction, setBulkAction] = useState('');
  const [showPhotoFilter, setShowPhotoFilter] = useState(false);
  const [photoFilter, setPhotoFilter] = useState('all'); // 'all', 'with', 'without'
  const [sortBy, setSortBy] = useState('firstName');
  const [sortOrder, setSortOrder] = useState('asc');
  const [viewMode, setViewMode] = useState('table'); // 'table', 'cards'
  const [isImporting, setIsImporting] = useState(false);
  const [isImportingPhotos, setIsImportingPhotos] = useState(false);
  const [isImportingDirect, setIsImportingDirect] = useState(false);

  // États pour les données
  const [usersData, setUsersData] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    premium: 0,
    gold: 0,
    withPhotos: 0,
    starProfiles: 0
  });

  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/admin/users');
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsersData(data.users || []);
      setStats(data.stats || {});
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({ title: "Erreur", description: "Impossible de charger les utilisateurs", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const users = (usersData as User[]) || [];

  // Filtrage avancé des utilisateurs
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.firstName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCity = user.city.toLowerCase().includes(citySearch.toLowerCase());
    
    const selectedGenders = Object.keys(genderFilters).filter(gender => genderFilters[gender as "H" | "F"]);
    const matchesGender = selectedGenders.length === 0 || selectedGenders.includes(user.gender);
    
    const selectedSubscriptions = Object.keys(subscriptionFilters).filter(sub => subscriptionFilters[sub as "gratuit" | "premium" | "gold"]);
    const matchesSubscription = selectedSubscriptions.length === 0 || selectedSubscriptions.includes(user.subscription);
    
    // Filtre par photos
    let matchesPhoto = true;
    if (photoFilter === 'with') {
      matchesPhoto = user.photos && user.photos.length > 0;
    } else if (photoFilter === 'without') {
      matchesPhoto = !user.photos || user.photos.length === 0;
    }
    
    return matchesSearch && matchesCity && matchesGender && matchesSubscription && matchesPhoto;
  });

  // Tri des utilisateurs
  const sortedUsers = [...filteredUsers].sort((a, b) => {
    let aValue = a[sortBy as keyof User];
    let bValue = b[sortBy as keyof User];
    
    if (typeof aValue === 'string') {
      aValue = aValue.toLowerCase();
    }
    if (typeof bValue === 'string') {
      bValue = bValue.toLowerCase();
    }
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  // Pagination
  const totalPages = Math.ceil(sortedUsers.length / usersPerPage);
  const startIndex = (currentPage - 1) * usersPerPage;
  const paginatedUsers = sortedUsers.slice(startIndex, startIndex + usersPerPage);

  // Gestion de la sélection
  const handleSelectUser = (userId: number) => {
    const newSelected = new Set(selectedUsers);
    if (newSelected.has(userId)) {
      newSelected.delete(userId);
    } else {
      newSelected.add(userId);
    }
    setSelectedUsers(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedUsers.size === paginatedUsers.length) {
      setSelectedUsers(new Set());
    } else {
      setSelectedUsers(new Set(paginatedUsers.map(u => u.id)));
    }
  };

  // Actions en lot
  const handleBulkAction = async () => {
    if (selectedUsers.size === 0) return;
    
    const userIds = Array.from(selectedUsers);
    
    try {
      if (bulkAction === 'delete') {
        if (!confirm(`Êtes-vous sûr de vouloir supprimer ${userIds.length} utilisateurs ?`)) return;
        
        const response = await fetch('/api/admin/users/bulk-delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userIds })
        });
        
        if (response.ok) {
          toast({ title: "Succès", description: `${userIds.length} utilisateurs supprimés` });
          fetchUsers();
          setSelectedUsers(new Set());
        }
      } else if (bulkAction === 'upgrade-premium') {
        const response = await fetch('/api/admin/users/bulk-upgrade', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userIds, subscription: 'premium' })
        });
        
        if (response.ok) {
          toast({ title: "Succès", description: `${userIds.length} utilisateurs passés en Premium` });
          fetchUsers();
          setSelectedUsers(new Set());
        }
      } else if (bulkAction === 'upgrade-gold') {
        const response = await fetch('/api/admin/users/bulk-upgrade', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userIds, subscription: 'gold' })
        });
        
        if (response.ok) {
          toast({ title: "Succès", description: `${userIds.length} utilisateurs passés en Gold` });
          fetchUsers();
          setSelectedUsers(new Set());
        }
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Action impossible", variant: "destructive" });
    }
  };

  // Sauvegarde
  const handleDownloadBackup = async () => {
    try {
      const response = await fetch('/api/admin/backup');
      const backup = await response.json();
      
      const dataStr = JSON.stringify(backup, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `backup_${new Date().toISOString().split('T')[0]}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      toast({ title: "Sauvegarde téléchargée", description: "Backup créé avec succès" });
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de créer la sauvegarde", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header avec statistiques */}
      <div className="bg-gray-800 text-white p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/admin">
              <Button variant="ghost" size="sm" className="text-white hover:bg-gray-700 mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Retour
              </Button>
            </Link>
            <Shield className="h-6 w-6 mr-3" />
            <h2 className="text-xl font-semibold">Gestion des Utilisateurs</h2>
          </div>
          
          <div className="flex gap-4 text-sm">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{stats.total}</div>
              <div className="text-gray-300">Total</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-400">{stats.premium}</div>
              <div className="text-gray-300">Premium</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">{stats.gold}</div>
              <div className="text-gray-300">Gold</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{stats.withPhotos}</div>
              <div className="text-gray-300">Avec photos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-400">{stats.starProfiles}</div>
              <div className="text-gray-300">Profils *</div>
            </div>
          </div>
        </div>
      </div>

      {/* Barre d'outils */}
      <div className="bg-white p-4 border-b shadow-sm">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          {/* Recherche */}
          <div className="flex gap-2">
            <Input
              placeholder="Rechercher par prénom..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-64"
            />
            <Input
              placeholder="Rechercher par ville..."
              value={citySearch}
              onChange={(e) => setCitySearch(e.target.value)}
              className="w-64"
            />
          </div>

          {/* Filtres */}
          <div className="flex gap-2">
            <Select value={photoFilter} onValueChange={setPhotoFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Photos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                <SelectItem value="with">Avec photos</SelectItem>
                <SelectItem value="without">Sans photos</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Trier par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="firstName">Prénom</SelectItem>
                <SelectItem value="age">Âge</SelectItem>
                <SelectItem value="city">Ville</SelectItem>
                <SelectItem value="subscription">Abonnement</SelectItem>
              </SelectContent>
            </Select>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            >
              <SortAsc className="h-4 w-4" />
            </Button>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setSelectMode(!selectMode)}
            >
              {selectMode ? <X className="h-4 w-4" /> : <Check className="h-4 w-4" />}
              {selectMode ? 'Annuler' : 'Sélectionner'}
            </Button>
            
            <Button variant="outline" size="sm" onClick={handleDownloadBackup}>
              <Download className="h-4 w-4 mr-2" />
              Sauvegarder
            </Button>
            
            <Button onClick={() => setShowAddUser(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter
            </Button>
          </div>
        </div>

        {/* Filtres genre et abonnement */}
        <div className="flex gap-4 mt-4">
          <div className="flex gap-2">
            <span className="text-sm font-medium">Genre:</span>
            {Object.entries(genderFilters).map(([gender, checked]) => (
              <label key={gender} className="flex items-center gap-1">
                <Checkbox
                  checked={checked}
                  onCheckedChange={(checked) => 
                    setGenderFilters(prev => ({ ...prev, [gender]: checked as boolean }))
                  }
                />
                <span className="text-sm">{gender}</span>
              </label>
            ))}
          </div>
          
          <div className="flex gap-2">
            <span className="text-sm font-medium">Abonnement:</span>
            {Object.entries(subscriptionFilters).map(([sub, checked]) => (
              <label key={sub} className="flex items-center gap-1">
                <Checkbox
                  checked={checked}
                  onCheckedChange={(checked) => 
                    setSubscriptionFilters(prev => ({ ...prev, [sub]: checked as boolean }))
                  }
                />
                <span className="text-sm">{sub}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Actions en lot */}
        {selectMode && selectedUsers.size > 0 && (
          <div className="flex gap-2 mt-4 p-3 bg-blue-50 rounded-lg">
            <span className="text-sm font-medium">{selectedUsers.size} sélectionnés:</span>
            <Select value={bulkAction} onValueChange={setBulkAction}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Choisir une action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="delete">Supprimer</SelectItem>
                <SelectItem value="upgrade-premium">Passer en Premium</SelectItem>
                <SelectItem value="upgrade-gold">Passer en Gold</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleBulkAction} disabled={!bulkAction}>
              Exécuter
            </Button>
          </div>
        )}
      </div>

      {/* Liste des utilisateurs */}
      <div className="p-6">
        {selectMode && (
          <div className="mb-4">
            <Button variant="outline" onClick={handleSelectAll}>
              {selectedUsers.size === paginatedUsers.length ? 'Désélectionner tout' : 'Sélectionner tout'}
            </Button>
          </div>
        )}

        <div className="grid gap-4">
          {paginatedUsers.map(user => (
            <Card key={user.id} className={`${selectMode && selectedUsers.has(user.id) ? 'ring-2 ring-blue-500' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {selectMode && (
                      <Checkbox
                        checked={selectedUsers.has(user.id)}
                        onCheckedChange={() => handleSelectUser(user.id)}
                      />
                    )}
                    
                    <div className="flex items-center gap-3">
                      {user.photos && user.photos.length > 0 ? (
                        <img 
                          src={user.photos[0]} 
                          alt={user.firstName}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center">
                          <Users className="h-6 w-6 text-gray-500" />
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-semibold">{user.firstName}</h3>
                        <p className="text-sm text-gray-600">{user.age} ans - {user.city}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={user.subscription === 'gold' ? 'default' : user.subscription === 'premium' ? 'secondary' : 'outline'}>
                      {user.subscription}
                    </Badge>
                    
                    <Button variant="ghost" size="sm" onClick={() => setEditingUser(user)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex justify-center gap-2 mt-6">
          <Button 
            variant="outline" 
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <span className="flex items-center px-4">
            Page {currentPage} sur {totalPages}
          </span>
          
          <Button 
            variant="outline" 
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Modal d'édition */}
      {editingUser && (
        <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Modifier le profil de {editingUser.firstName}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Prénom</Label>
                  <Input 
                    value={editingUser.firstName} 
                    onChange={(e) => setEditingUser({...editingUser, firstName: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Âge</Label>
                  <Input 
                    type="number" 
                    value={editingUser.age} 
                    onChange={(e) => setEditingUser({...editingUser, age: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Ville</Label>
                  <Input 
                    value={editingUser.city} 
                    onChange={(e) => setEditingUser({...editingUser, city: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Abonnement</Label>
                  <Select 
                    value={editingUser.subscription} 
                    onValueChange={(value) => setEditingUser({...editingUser, subscription: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gratuit">Gratuit</SelectItem>
                      <SelectItem value="premium">Premium</SelectItem>
                      <SelectItem value="gold">Gold</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditingUser(null)}>
                  Annuler
                </Button>
                <Button onClick={async () => {
                  try {
                    const response = await fetch(`/api/admin/profile/${editingUser.id}`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(editingUser)
                    });
                    
                    if (response.ok) {
                      toast({ title: "Profil modifié", description: "Modifications sauvegardées" });
                      fetchUsers();
                      setEditingUser(null);
                    }
                  } catch (error) {
                    toast({ title: "Erreur", description: "Impossible de modifier", variant: "destructive" });
                  }
                }}>
                  Sauvegarder
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}