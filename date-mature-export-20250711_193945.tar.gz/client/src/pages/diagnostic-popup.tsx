import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useNewsletterPopup } from '@/hooks/use-newsletter-popup';

export default function DiagnosticPopup() {
  const [diagnosticData, setDiagnosticData] = useState<any>({});
  const [showTestPopup, setShowTestPopup] = useState(false);
  const { toast } = useToast();
  const { showPopup, closePopup } = useNewsletterPopup();

  const updateDiagnostic = () => {
    const data = {
      localStorage: {
        lastShown: localStorage.getItem('newsletter_popup_last_shown'),
        dismissed: localStorage.getItem('newsletter_popup_dismissed_v2'),
        subscribed: localStorage.getItem('newsletter_subscribed'),
        oldKey: localStorage.getItem('date_mature_newsletter_done')
      },
      dates: {
        today: new Date().toDateString(),
        now: new Date().toISOString()
      },
      popup: {
        currentlyShowing: showPopup,
        testPopup: showTestPopup
      },
      browser: {
        userAgent: navigator.userAgent,
        localStorage: typeof localStorage !== 'undefined',
        sessionStorage: typeof sessionStorage !== 'undefined'
      }
    };
    
    setDiagnosticData(data);
  };

  useEffect(() => {
    updateDiagnostic();
    const interval = setInterval(updateDiagnostic, 2000);
    return () => clearInterval(interval);
  }, [showPopup, showTestPopup]);

  const forceResetAll = () => {
    localStorage.clear();
    sessionStorage.clear();
    toast({
      title: "🗑️ Stockage vidé",
      description: "Tout le localStorage et sessionStorage ont été vidés",
    });
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  const forceShowPopup = () => {
    // Vider les blocages
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    localStorage.removeItem('date_mature_newsletter_done');
    
    // Déclencher manuellement
    setShowTestPopup(true);
    
    // Déclencher aussi via l'event
    window.dispatchEvent(new Event('forceNewsletterPopup'));
  };

  const testAPI = async () => {
    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: 'test-diagnostic@example.com',
          firstName: 'Test'
        }),
      });

      const result = await response.json();
      toast({
        title: response.ok ? "✅ API OK" : "❌ API Erreur",
        description: result.message || "Test API terminé",
      });
    } catch (error) {
      toast({
        title: "❌ Erreur réseau",
        description: "Impossible de contacter l'API",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-center">
              🔍 Diagnostic Popup Newsletter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* État localStorage */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">📦 État localStorage</h3>
                <div className="bg-gray-100 p-3 rounded text-sm">
                  <pre>{JSON.stringify(diagnosticData.localStorage, null, 2)}</pre>
                </div>
              </div>

              {/* État popup */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">💬 État popup</h3>
                <div className="bg-gray-100 p-3 rounded text-sm">
                  <pre>{JSON.stringify(diagnosticData.popup, null, 2)}</pre>
                </div>
              </div>

              {/* Informations dates */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">📅 Informations dates</h3>
                <div className="bg-gray-100 p-3 rounded text-sm">
                  <pre>{JSON.stringify(diagnosticData.dates, null, 2)}</pre>
                </div>
              </div>

              {/* Navigateur */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">🌐 Navigateur</h3>
                <div className="bg-gray-100 p-3 rounded text-sm">
                  <div>localStorage: {diagnosticData.browser?.localStorage ? '✅' : '❌'}</div>
                  <div>sessionStorage: {diagnosticData.browser?.sessionStorage ? '✅' : '❌'}</div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Button 
                  onClick={forceShowPopup}
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  🚀 Forcer popup
                </Button>
                
                <Button 
                  onClick={testAPI}
                  className="bg-green-500 hover:bg-green-600"
                >
                  🧪 Test API
                </Button>
                
                <Button 
                  onClick={forceResetAll}
                  variant="destructive"
                >
                  🗑️ Reset complet
                </Button>
              </div>
              
              <Button 
                onClick={() => window.location.href = '/'}
                className="w-full"
                variant="outline"
              >
                🏠 Retour accueil
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Popup de test */}
        {showTestPopup && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-xl font-bold mb-4">🎁 Test Popup Ebook</h3>
              <p className="mb-4">Ceci est un popup de test pour vérifier le fonctionnement.</p>
              <div className="flex space-x-3">
                <Button 
                  onClick={() => setShowTestPopup(false)}
                  variant="outline"
                >
                  Fermer
                </Button>
                <Button 
                  onClick={testAPI}
                  className="bg-rose-500 hover:bg-rose-600"
                >
                  Tester inscription
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}