import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useNewsletterPopupDebug } from '@/hooks/use-newsletter-popup-debug';
import { RefreshCw } from 'lucide-react';

export default function DebugPopup() {
  const { showPopup, closePopup, debugInfo } = useNewsletterPopupDebug();

  const resetStates = () => {
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-2xl mx-auto pt-8">
        <Card className="border-2 border-pink-200 shadow-lg mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-xl text-gray-800">
              Debug Popup Newsletter
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Diagnostic complet du système popup
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">États localStorage :</h3>
              <div className="text-sm space-y-1">
                <p>• Montré aujourd'hui : {localStorage.getItem('newsletter_popup_last_shown') || 'Non'}</p>
                <p>• Fermé : {localStorage.getItem('newsletter_popup_dismissed_v2') || 'Non'}</p>
                <p>• Abonné : {localStorage.getItem('newsletter_subscribed') || 'Non'}</p>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Logs en temps réel :</h3>
              <div className="text-xs space-y-1 font-mono">
                {debugInfo.map((log, i) => (
                  <div key={i} className="text-gray-700">{log}</div>
                ))}
              </div>
            </div>

            <Button 
              onClick={resetStates}
              className="w-full bg-pink-600 hover:bg-pink-700 text-white"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset & Recharger
            </Button>

            <div className="text-xs text-gray-500 text-center">
              <p>Testez :</p>
              <p>• Attendez 30 secondes</p>
              <p>• Scrollez à 80%</p>
              <p>• Bougez souris vers le haut</p>
            </div>
          </CardContent>
        </Card>

        {/* Popup de test */}
        {showPopup && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg max-w-md">
              <h3 className="text-lg font-semibold mb-4">🎉 Popup Newsletter Déclenché !</h3>
              <p className="text-gray-600 mb-4">
                Le popup s'est affiché correctement !
              </p>
              <Button onClick={closePopup} className="w-full">
                Fermer
              </Button>
            </div>
          </div>
        )}

        {/* Contenu long pour tester le scroll */}
        <div className="space-y-4">
          {Array.from({ length: 20 }, (_, i) => (
            <Card key={i} className="p-4">
              <p className="text-gray-700">
                Contenu de test #{i + 1} - Scrollez vers le bas pour atteindre 80% de la page.
              </p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}