import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Crown, Star } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import BottomNavigation from "@/components/bottom-navigation";

export default function Messages() {
  // Get current user
  const { data: currentUserData } = useQuery({
    queryKey: ["/api/users/current"],
  });

  const currentUser = currentUserData?.user;

  // Get matches
  const { data: matchesData } = useQuery({
    queryKey: ["/api/matches", currentUser?.id],
    enabled: !!currentUser?.id,
  });

  const matches = matchesData?.matches || [];
  const totalUnreadMessages = matches.reduce((total: number, match: any) => 
    total + match.unreadCount, 0);

  const formatTime = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInDays = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return messageDate.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } else if (diffInDays === 1) {
      return "Hier";
    } else if (diffInDays < 7) {
      return messageDate.toLocaleDateString('fr-FR', { weekday: 'long' });
    } else {
      return messageDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    }
  };

  const getSubscriptionBadge = (subscription: string) => {
    if (subscription === 'gold') {
      return (
        <Badge className="bg-yellow-500 text-white text-xs">
          <Crown className="h-3 w-3" />
        </Badge>
      );
    }
    if (subscription === 'premium') {
      return (
        <Badge className="bg-purple-600 text-white text-xs">
          <Star className="h-3 w-3" />
        </Badge>
      );
    }
    return null;
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="bg-primary text-white p-6 flex items-center">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mr-4 text-white hover:bg-white/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h2 className="text-xl font-semibold">Mes Messages</h2>
      </div>

      {/* Matches List */}
      <div className="flex-1 overflow-y-auto">
        {matches.length === 0 ? (
          <div className="h-full flex items-center justify-center p-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💬</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Aucun message</h3>
              <p className="text-gray-600">
                Commencez à envoyer des flashs pour créer des matches et échanger des messages !
              </p>
              <Link href="/">
                <Button className="mt-4">
                  Découvrir des profils
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          matches.map((match: any) => (
            <Link key={match.id} href={`/chat/${match.partner.id}`}>
              <div className="border-b border-gray-100 p-4 flex items-center space-x-4 hover:bg-gray-50 cursor-pointer">
                <img
                  src={match.partner.photo}
                  alt={`Profil de ${match.partner.firstName}`}
                  className="w-16 h-16 rounded-full object-cover"
                />
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-lg">{match.partner.firstName}</h3>
                    <span className="text-sm text-gray-500">
                      {match.lastMessage && formatTime(match.lastMessage.createdAt)}
                    </span>
                  </div>
                  <p className="text-gray-600 truncate">
                    {match.lastMessage?.content || "Commencez la conversation..."}
                  </p>
                </div>
                
                <div className="flex flex-col items-end space-y-2">
                  {match.unreadCount > 0 && (
                    <div className="bg-primary text-white text-xs w-6 h-6 rounded-full flex items-center justify-center">
                      {match.unreadCount}
                    </div>
                  )}
                  {getSubscriptionBadge(match.partner.subscription)}
                </div>
              </div>
            </Link>
          ))
        )}

        {/* New Match Notification (if there are recent matches) */}
        {matches.length > 0 && matches[0].createdAt && 
         new Date().getTime() - new Date(matches[0].createdAt).getTime() < 24 * 60 * 60 * 1000 && (
          <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-4 m-4 rounded-2xl flex items-center space-x-4">
            <span className="text-2xl">❤️</span>
            <div className="flex-1">
              <h3 className="font-semibold">Nouveau match !</h3>
              <p className="text-sm opacity-90">
                Vous et {matches[0].partner.firstName} vous êtes plu mutuellement
              </p>
            </div>
            <Button variant="secondary" size="sm">
              Voir
            </Button>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation unreadMessages={totalUnreadMessages} />
    </div>
  );
}
