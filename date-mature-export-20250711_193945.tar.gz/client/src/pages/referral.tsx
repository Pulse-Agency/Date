import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Gift, Users, Copy, Check, Share2, Heart, Sparkles } from "lucide-react";

export default function Referral() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  
  // Récupérer les informations de parrainage de l'utilisateur
  const { data: referralData, isLoading } = useQuery({
    queryKey: ["/api/referral/info"],
  });

  // Générer un code de parrainage
  const generateCodeMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/referral/generate");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/referral/info"] });
      toast({
        title: "Code créé !",
        description: "Votre code de parrainage a été créé avec succès.",
      });
    },
  });

  // Copier le code dans le presse-papier
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast({
        title: "Copié !",
        description: "Le code a été copié dans votre presse-papier.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Erreur",
        description: "Impossible de copier le code.",
        variant: "destructive",
      });
    }
  };

  // Partager via les applications natives
  const shareReferral = async (code: string) => {
    const shareData = {
      title: "Rejoignez-moi sur notre app de rencontres seniors !",
      text: `Découvrez une app de rencontres conçue spécialement pour les seniors. Utilisez mon code ${code} pour commencer !`,
      url: window.location.origin,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        // L'utilisateur a annulé le partage
      }
    } else {
      // Fallback pour les navigateurs qui ne supportent pas l'API Share
      copyToClipboard(`${shareData.text} ${shareData.url}`);
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="h-8 bg-gray-200 rounded animate-pulse"></div>
        <div className="h-64 bg-gray-200 rounded animate-pulse"></div>
      </div>
    );
  }

  const referralCode = referralData?.referralCode;
  const referrals = referralData?.referrals || [];
  const totalRewards = referralData?.totalRewards || 0;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      {/* En-tête avec titre et description */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 text-4xl">
          <Heart className="w-10 h-10 text-rose-500" />
          <h1 className="text-3xl font-bold text-gray-900">Parrainage</h1>
          <Sparkles className="w-10 h-10 text-yellow-500" />
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Invitez vos amis et gagnez des récompenses ! Pour chaque personne qui s'inscrit avec votre code, 
          vous recevez <strong>10 flashes bonus</strong> et votre ami(e) reçoit <strong>5 flashes de bienvenue</strong>.
        </p>
      </div>

      {/* Statistiques de parrainage */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center border-2">
          <CardContent className="pt-6">
            <Users className="w-12 h-12 text-blue-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-gray-900">{referrals.length}</div>
            <p className="text-gray-600 text-lg">Amis invités</p>
          </CardContent>
        </Card>
        
        <Card className="text-center border-2">
          <CardContent className="pt-6">
            <Gift className="w-12 h-12 text-green-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-gray-900">{totalRewards}</div>
            <p className="text-gray-600 text-lg">Flashes gagnés</p>
          </CardContent>
        </Card>
        
        <Card className="text-center border-2">
          <CardContent className="pt-6">
            <Sparkles className="w-12 h-12 text-yellow-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-gray-900">
              {referrals.filter(r => r.status === 'completed').length}
            </div>
            <p className="text-gray-600 text-lg">Parrainages réussis</p>
          </CardContent>
        </Card>
      </div>

      {/* Section code de parrainage */}
      <Card className="border-2 border-blue-200">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center gap-2">
            <Share2 className="w-6 h-6" />
            Votre code de parrainage
          </CardTitle>
          <CardDescription className="text-lg">
            Partagez ce code avec vos amis pour qu'ils puissent vous rejoindre facilement
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {referralCode ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Label htmlFor="referral-code" className="text-lg font-medium">
                  Code d'invitation :
                </Label>
                <div className="flex-1 flex items-center gap-2">
                  <Input
                    id="referral-code"
                    value={referralCode}
                    readOnly
                    className="text-xl font-mono text-center border-2 border-blue-300"
                  />
                  <Button
                    onClick={() => copyToClipboard(referralCode)}
                    variant="outline"
                    size="lg"
                    className="shrink-0"
                  >
                    {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    {copied ? "Copié !" : "Copier"}
                  </Button>
                </div>
              </div>
              
              <div className="flex gap-3 justify-center">
                <Button
                  onClick={() => shareReferral(referralCode)}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Share2 className="w-5 h-5 mr-2" />
                  Partager avec mes amis
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4">
              <p className="text-lg text-gray-600">
                Vous n'avez pas encore de code de parrainage.
              </p>
              <Button
                onClick={() => generateCodeMutation.mutate()}
                disabled={generateCodeMutation.isPending}
                size="lg"
                className="bg-green-600 hover:bg-green-700"
              >
                <Gift className="w-5 h-5 mr-2" />
                {generateCodeMutation.isPending ? "Création..." : "Créer mon code"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Comment ça marche */}
      <Card className="border-2 border-green-200">
        <CardHeader>
          <CardTitle className="text-2xl text-center">Comment ça marche ?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="space-y-3">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold">Partagez votre code</h3>
              <p className="text-gray-600">
                Envoyez votre code d'invitation à vos amis par message, email ou réseaux sociaux.
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="text-xl font-semibold">Votre ami s'inscrit</h3>
              <p className="text-gray-600">
                Votre ami utilise votre code lors de son inscription et crée son profil complet.
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-yellow-600">3</span>
              </div>
              <h3 className="text-xl font-semibold">Vous gagnez tous les deux</h3>
              <p className="text-gray-600">
                Vous recevez 10 flashes bonus, votre ami reçoit 5 flashes de bienvenue !
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Liste des parrainages */}
      {referrals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Mes invitations</CardTitle>
            <CardDescription>
              Voici les amis que vous avez invités à rejoindre la communauté
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {referrals.map((referral: any, index: number) => (
                <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-xl">👤</span>
                    </div>
                    <div>
                      <p className="font-medium">Invitation #{index + 1}</p>
                      <p className="text-sm text-gray-600">
                        Envoyée le {new Date(referral.createdAt).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge 
                      variant={referral.status === 'completed' ? 'default' : 'secondary'}
                      className="text-sm"
                    >
                      {referral.status === 'completed' ? 'Réussi' : 'En attente'}
                    </Badge>
                    {referral.status === 'completed' && (
                      <p className="text-sm text-green-600 mt-1">
                        +{referral.rewardAmount} flashes
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}