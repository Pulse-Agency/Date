import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import SiteHeader from "@/components/site-header";

export default function MentionsLegales() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-100">
      <SiteHeader showBackToHome={true} />
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center text-purple-800">
              Mentions Légales
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <h2>1. Éditeur du site</h2>
            <p><strong>Date-Mature.com</strong></p>
            <p>Site de rencontres pour seniors</p>
            <p>Email : contact@date-mature.com</p>

            <h2>2. Hébergement</h2>
            <p><strong>Replit</strong><br />
            Replit, Inc.<br />
            767 Bryant St. #203<br />
            San Francisco, CA 94107<br />
            États-Unis</p>

            <h2>3. Directeur de publication</h2>
            <p>Le directeur de publication est le responsable légal du site Date-Mature.com</p>

            <h2>4. Propriété intellectuelle</h2>
            <p>L'ensemble des contenus présents sur le site Date-Mature.com (textes, images, logos) sont protégés par le droit de la propriété intellectuelle.</p>

            <h2>5. Protection des données personnelles</h2>
            <p>Conformément au RGPD, vous disposez d'un droit d'accès, de rectification et de suppression de vos données personnelles.</p>
            <p>Pour exercer ces droits : support@date-mature.com</p>

            <h2>6. Cookies</h2>
            <p>Ce site utilise des cookies techniques nécessaires au fonctionnement de la plateforme (connexion, préférences utilisateur).</p>

            <h2>7. Responsabilité</h2>
            <p>Date-Mature.com s'efforce d'assurer l'exactitude des informations diffusées mais ne peut garantir l'absence d'erreurs.</p>

            <h2>8. Droit applicable</h2>
            <p>Le présent site est soumis au droit français. Tout litige sera de la compétence des tribunaux français.</p>
            
            <p className="text-sm text-gray-600 mt-8">
              Dernière mise à jour : 1er juillet 2025
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}