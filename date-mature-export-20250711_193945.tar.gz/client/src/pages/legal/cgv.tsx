import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import SiteHeader from "@/components/site-header";

export default function CGV() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-100">
      <SiteHeader showBackToHome={true} />
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center text-purple-800">
              Conditions Générales de Vente
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <h2>1. Objet</h2>
            <p>Date-Mature.com est une plateforme de rencontres destinée aux personnes de 40 ans et plus recherchant des relations sérieuses et durables.</p>

            <h2>2. Services proposés</h2>
            <h3>Abonnement Gratuit</h3>
            <ul>
              <li>3 flashs par jour</li>
              <li>Messagerie de base avec les matches</li>
              <li>Création de profil complet</li>
            </ul>

            <h3>Abonnement Premium (60€ pour 6 mois)</h3>
            <ul>
              <li>20 flashs par jour</li>
              <li>Voir qui vous a flashé</li>
              <li>Support client prioritaire</li>
              <li>Filtres de recherche avancés</li>
            </ul>

            <h3>Abonnement Gold (114€ pour 12 mois)</h3>
            <ul>
              <li>Flashs illimités</li>
              <li>Messages illimités</li>
              <li>Profil mis en avant</li>
              <li>Mode incognito</li>
              <li>Badges exclusifs</li>
            </ul>

            <h2>3. Prix et paiement</h2>
            <p>Les prix sont indiqués en euros TTC. Le paiement s'effectue par carte bancaire via Stripe, plateforme sécurisée.</p>
            <p>L'abonnement se renouvelle automatiquement sauf résiliation 48h avant l'échéance.</p>

            <h2>4. Droit de rétractation</h2>
            <p>Vous disposez de 14 jours pour exercer votre droit de rétractation sans motif.</p>

            <h2>5. Responsabilités</h2>
            <p>Date-Mature.com est un service de mise en relation. Nous ne sommes pas responsables du contenu des échanges entre utilisateurs.</p>

            <h2>6. Données personnelles</h2>
            <p>Vos données sont traitées conformément à notre Politique de Confidentialité et au RGPD.</p>

            <h2>7. Contact</h2>
            <p>Pour toute question : support@date-mature.com</p>
            
            <p className="text-sm text-gray-600 mt-8">
              Dernière mise à jour : 1er juillet 2025
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}