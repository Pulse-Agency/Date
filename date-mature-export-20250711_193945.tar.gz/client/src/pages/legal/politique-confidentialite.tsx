import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import SiteHeader from "@/components/site-header";

export default function PolitiqueConfidentialite() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-100">
      <SiteHeader showBackToHome={true} />
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center text-purple-800">
              Politique de Confidentialité
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <h2>1. Collecte des données</h2>
            <p>Nous collectons uniquement les données nécessaires au fonctionnement de notre service de rencontres :</p>
            <ul>
              <li>Informations de profil (nom, âge, ville, bio, photos)</li>
              <li>Données de connexion (email, mot de passe chiffré)</li>
              <li>Historique d'activité (flashs, matches, messages)</li>
              <li>Informations de paiement (via Stripe, non stockées sur nos serveurs)</li>
            </ul>

            <h2>2. Utilisation des données</h2>
            <p>Vos données sont utilisées pour :</p>
            <ul>
              <li>Créer et gérer votre profil</li>
              <li>Vous proposer des profils compatibles</li>
              <li>Faciliter la communication entre membres</li>
              <li>Traiter vos paiements d'abonnement</li>
              <li>Améliorer nos services</li>
              <li>Vous envoyer des notifications importantes</li>
            </ul>

            <h2>3. Partage des données</h2>
            <p>Nous ne vendons jamais vos données. Elles peuvent être partagées uniquement :</p>
            <ul>
              <li>Avec d'autres membres (informations de profil public)</li>
              <li>Avec nos prestataires techniques (Stripe, MailerLite, hébergement)</li>
              <li>En cas d'obligation légale</li>
            </ul>

            <h2>4. Conservation des données</h2>
            <p>Vos données sont conservées tant que votre compte est actif. Après suppression de compte, elles sont anonymisées ou supprimées sous 30 jours.</p>

            <h2>5. Vos droits (RGPD)</h2>
            <p>Vous disposez des droits suivants :</p>
            <ul>
              <li><strong>Accès</strong> : Consulter vos données</li>
              <li><strong>Rectification</strong> : Corriger vos informations</li>
              <li><strong>Suppression</strong> : Supprimer votre compte</li>
              <li><strong>Portabilité</strong> : Récupérer vos données</li>
              <li><strong>Opposition</strong> : Refuser certains traitements</li>
            </ul>

            <h2>6. Sécurité</h2>
            <p>Nous mettons en place des mesures techniques et organisationnelles pour protéger vos données :</p>
            <ul>
              <li>Chiffrement des mots de passe</li>
              <li>Connexions HTTPS sécurisées</li>
              <li>Serveurs protégés</li>
              <li>Accès restreint aux données</li>
            </ul>

            <h2>7. Cookies</h2>
            <p>Nous utilisons des cookies techniques essentiels :</p>
            <ul>
              <li>Session de connexion</li>
              <li>Préférences utilisateur</li>
              <li>Fonctionnement du chat en temps réel</li>
            </ul>

            <h2>8. Contact</h2>
            <p>Pour exercer vos droits ou toute question sur cette politique :</p>
            <p><strong>Email :</strong> privacy@date-mature.com</p>
            
            <p className="text-sm text-gray-600 mt-8">
              Dernière mise à jour : 1er juillet 2025
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}