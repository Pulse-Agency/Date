// Removed React Query imports - using direct fetch instead
import { Shield, Users, Crown, Mail, MapPin, Calendar, ArrowLeft, Plus, UserX, Edit, Search, Upload, Download } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import MultiPhotoUpload from "@/components/multi-photo-upload";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface User {
  id: number;
  firstName: string;
  lastName?: string;
  email: string;
  gender: "H" | "F";
  age: number;
  city: string;
  region?: string;
  subscription: string;
  bio?: string;
  photos?: string[];
  isTestProfile?: boolean;
  interests?: string[];
}

export default function AdminUsers() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilters, setGenderFilters] = useState({ H: false, F: false });
  const [citySearch, setCitySearch] = useState('');
  const [subscriptionFilters, setSubscriptionFilters] = useState({ gratuit: false, premium: false, gold: false });
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [isImporting, setIsImporting] = useState(false);
  const [isImportingPhotos, setIsImportingPhotos] = useState(false);
  const [isImportingDirect, setIsImportingDirect] = useState(false);

  // Appliquer les filtres automatiquement selon les paramètres d'URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const subscription = urlParams.get('subscription');
    
    // Réinitialiser tous les filtres d'abonnement d'abord
    if (subscription === 'premium') {
      setSubscriptionFilters({ gratuit: false, premium: true, gold: false });
    } else if (subscription === 'gold') {
      setSubscriptionFilters({ gratuit: false, premium: false, gold: true });
    } else if (subscription === null) {
      // Si pas de paramètre subscription, montrer tous les abonnements
      setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
    }
    
    // Réinitialiser la page à 1 quand on change de filtre
    setCurrentPage(1);
  }, [location]);

  const [newUser, setNewUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    age: 50,
    city: '',
    subscription: 'gratuit',
    bio: '',
    photos: [],
    isTestProfile: true
  });

  // Construire les paramètres de requête pour l'API
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    params.append('page', currentPage.toString());
    params.append('limit', usersPerPage.toString());
    
    if (searchTerm) params.append('search', searchTerm);
    if (citySearch) params.append('city', citySearch);
    
    // Filtres de genre
    const selectedGenders = Object.keys(genderFilters).filter(gender => genderFilters[gender as "H" | "F"]);
    if (selectedGenders.length === 1) params.append('gender', selectedGenders[0]);
    
    // Filtres d'abonnement
    const selectedSubscriptions = Object.keys(subscriptionFilters).filter(sub => subscriptionFilters[sub as "gratuit" | "premium" | "gold"]);
    if (selectedSubscriptions.length === 1) params.append('subscription', selectedSubscriptions[0]);
    
    return params.toString();
  };

  const [usersResponse, setUsersResponse] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const params = buildQueryParams();
      const response = await fetch(`/api/admin/users?${params}`);
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsersResponse(data);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [currentPage, searchTerm, citySearch, genderFilters, subscriptionFilters]);

  const users = usersResponse?.users || [];
  const stats = usersResponse?.stats || { total: 0, filtered: 0, premium: 0, gold: 0, withPhotos: 0, starProfiles: 0 };
  const totalPages = usersResponse?.pagination?.pages || 1;

  // Les données sont déjà filtrées et paginées par l'API
  const paginatedUsers = users;

  // Add user function
  const addUser = async (userData: any) => {
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la création");
      }
      
      toast({
        title: "Utilisateur créé",
        description: "Le profil a été ajouté avec succès",
      });
      
      setShowAddUser(false);
      setNewUser({
        firstName: '',
        lastName: '',
        email: '',
        age: 50,
        city: '',
        subscription: 'gratuit',
        bio: '',
        photos: [],
        isTestProfile: true
      });
      
      fetchUsers(); // Recharger les utilisateurs
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de créer l'utilisateur",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.firstName || !newUser.email) {
      toast({
        title: "Erreur",
        description: "Le prénom et l'email sont obligatoires",
        variant: "destructive",
      });
      return;
    }
    addUser(newUser);
  };

  console.log('AdminUsers - Debug:', {
    isLoading,
    users: users.length,
    stats,
    totalPages,
    usersResponse
  });

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        <span className="ml-2">Chargement des utilisateurs...</span>
      </div>
    );
  }

  if (!usersResponse || !users || users.length === 0) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg text-gray-600">Aucun utilisateur trouvé</p>
          <p className="text-sm text-gray-500">Debug: {JSON.stringify({ usersResponse, users })}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-gray-800 text-white p-6 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white hover:bg-gray-700 mr-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
          </Link>
          <Shield className="h-6 w-6 mr-3" />
          <h2 className="text-xl font-semibold">
            Gestion des Utilisateurs (Total: {stats.total} | Affiché: {stats.filtered})
          </h2>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowAddUser(!showAddUser)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Ajouter un profil
          </Button>
          <Button asChild className="bg-green-600 hover:bg-green-700">
            <a href="/api/admin/backup" download>
              <Download className="h-4 w-4 mr-2" />
              Télécharger Backup
            </a>
          </Button>
        </div>
      </div>

      {/* Statistiques */}
      <div className="p-6 bg-white">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-sm text-gray-500">Total</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.filtered}</div>
            <div className="text-sm text-gray-500">Affiché</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.premium}</div>
            <div className="text-sm text-gray-500">Premium</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.gold}</div>
            <div className="text-sm text-gray-500">Gold</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-pink-600">{stats.withPhotos}</div>
            <div className="text-sm text-gray-500">Avec Photos</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{stats.starProfiles}</div>
            <div className="text-sm text-gray-500">Profils *</div>
          </div>
        </div>

        {/* Filtres */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <Label htmlFor="search">Rechercher</Label>
                <Input
                  id="search"
                  placeholder="Prénom, email, ville..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                />
              </div>
              <div>
                <Label htmlFor="gender">Genre</Label>
                <Select
                  value={
                    genderFilters.H && !genderFilters.F ? 'H' :
                    genderFilters.F && !genderFilters.H ? 'F' : 'tous'
                  }
                  onValueChange={(value) => {
                    if (value === 'tous') {
                      setGenderFilters({ H: false, F: false });
                    } else if (value === 'H') {
                      setGenderFilters({ H: true, F: false });
                    } else if (value === 'F') {
                      setGenderFilters({ H: false, F: true });
                    }
                    setCurrentPage(1);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tous" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tous">Tous</SelectItem>
                    <SelectItem value="H">Hommes</SelectItem>
                    <SelectItem value="F">Femmes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="subscription">Abonnement</Label>
                <Select
                  value={
                    subscriptionFilters.gratuit && !subscriptionFilters.premium && !subscriptionFilters.gold ? 'gratuit' :
                    subscriptionFilters.premium && !subscriptionFilters.gratuit && !subscriptionFilters.gold ? 'premium' :
                    subscriptionFilters.gold && !subscriptionFilters.gratuit && !subscriptionFilters.premium ? 'gold' : 'tous'
                  }
                  onValueChange={(value) => {
                    if (value === 'tous') {
                      setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
                    } else if (value === 'gratuit') {
                      setSubscriptionFilters({ gratuit: true, premium: false, gold: false });
                    } else if (value === 'premium') {
                      setSubscriptionFilters({ gratuit: false, premium: true, gold: false });
                    } else if (value === 'gold') {
                      setSubscriptionFilters({ gratuit: false, premium: false, gold: true });
                    }
                    setCurrentPage(1);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tous" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tous">Tous</SelectItem>
                    <SelectItem value="gratuit">Gratuit</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>&nbsp;</Label>
                <Button
                  onClick={() => {
                    setSearchTerm('');
                    setCitySearch('');
                    setGenderFilters({ H: false, F: false });
                    setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
                    setCurrentPage(1);
                  }}
                  variant="outline"
                  className="w-full"
                >
                  Réinitialiser
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <div className="space-y-4">
          {paginatedUsers.map((user: User) => (
            <Card key={user.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">
                        {user.firstName} {user.lastName || ''}
                      </h3>
                      <Badge variant={
                        user.subscription === 'premium' ? 'default' :
                        user.subscription === 'gold' ? 'secondary' :
                        'outline'
                      }>
                        {user.subscription}
                      </Badge>
                      <Badge variant="outline">
                        {user.gender}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        {user.email}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {user.age} ans
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {user.city}
                      </div>
                      {user.photos && user.photos.length > 0 && (
                        <div className="text-green-600 text-sm">
                          {user.photos.length} photo(s)
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setEditingUser(user)}
                      variant="outline"
                      size="sm"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex justify-center items-center gap-2 mt-6">
          <Button
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            variant="outline"
          >
            Précédent
          </Button>
          <span className="px-4 py-2 text-sm">
            Page {currentPage} sur {totalPages}
          </span>
          <Button
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
            variant="outline"
          >
            Suivant
          </Button>
        </div>
      </div>
    </div>
  );
}