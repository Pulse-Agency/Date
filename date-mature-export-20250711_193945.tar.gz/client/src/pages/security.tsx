import { Shield, Lock, Eye, AlertTriangle, UserX, Heart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

export default function Security() {
  return (
    <>
      <SiteHeader />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sécurité et confidentialité</h1>
          <p className="text-lg text-gray-600">
            Votre sécurité est notre priorité absolue
          </p>
        </div>

        {/* Security Measures */}
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center text-xl text-blue-800">
              <Shield className="h-6 w-6 mr-3" />
              Nos mesures de protection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3">
                <Lock className="h-5 w-5 text-blue-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-blue-800">Chiffrement des données</h3>
                  <p className="text-blue-700 text-sm">Toutes vos informations sont protégées par un chiffrement de niveau bancaire</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Eye className="h-5 w-5 text-blue-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-blue-800">Modération active</h3>
                  <p className="text-blue-700 text-sm">Surveillance 24h/24 pour détecter les comportements suspects</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <Lock className="h-6 w-6 text-gray-700 mr-3" />
              Contrôlez votre confidentialité
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium">Visibilité du profil</h3>
                  <p className="text-sm text-gray-600">Qui peut voir votre profil</p>
                </div>
                <Badge variant="secondary">Tous les membres</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium">Statut en ligne</h3>
                  <p className="text-sm text-gray-600">Afficher quand vous êtes connecté</p>
                </div>
                <Badge variant="secondary">Activé</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium">Photos privées</h3>
                  <p className="text-sm text-gray-600">Contrôler l'accès à vos photos</p>
                </div>
                <Badge variant="secondary">Matches uniquement</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Safety Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <Heart className="h-6 w-6 text-rose-500 mr-3" />
              Conseils pour des rencontres sereines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="border-l-4 border-green-400 pl-4">
                <h3 className="font-semibold text-green-800">Premier contact</h3>
                <p className="text-gray-700">Échangez d'abord sur l'application avant de partager vos coordonnées</p>
              </div>
              <div className="border-l-4 border-blue-400 pl-4">
                <h3 className="font-semibold text-blue-800">Premier rendez-vous</h3>
                <p className="text-gray-700">Choisissez un lieu public et prévenez un proche de votre sortie</p>
              </div>
              <div className="border-l-4 border-purple-400 pl-4">
                <h3 className="font-semibold text-purple-800">Informations personnelles</h3>
                <p className="text-gray-700">Ne partagez jamais vos données financières ou mots de passe</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Report Section */}
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center text-xl text-red-800">
              <AlertTriangle className="h-6 w-6 mr-3" />
              Signaler un problème
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-700 mb-4">
              Si vous rencontrez un comportement inapproprié, n'hésitez pas à nous le signaler immédiatement.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button className="flex-1 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                <UserX className="h-4 w-4 inline mr-2" />
                Bloquer un utilisateur
              </button>
              <button className="flex-1 bg-red-100 text-red-800 px-4 py-2 rounded-lg hover:bg-red-200 transition-colors">
                <AlertTriangle className="h-4 w-4 inline mr-2" />
                Signaler un profil
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card className="bg-gray-50">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="font-semibold text-gray-900 mb-2">Une question sur la sécurité ?</h3>
              <p className="text-gray-600 mb-4">Notre équipe sécurité est à votre disposition</p>
              <p className="text-gray-800 font-medium">📧 securite@rencontres-seniors.fr</p>
            </div>
          </CardContent>
        </Card>
      </div>
      </div>
      <SiteFooter />
    </>
  );
}