import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, Download, Edit } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Admin() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [genderFilter, setGenderFilter] = useState("");
  const [ageFilter, setAgeFilter] = useState("");
  const [subscriptionFilter, setSubscriptionFilter] = useState("");
  const USERS_PER_PAGE = 10;
  const { toast } = useToast();

  const { data: users, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const upgradeUser = async (userId: number, subscription: string) => {
    try {
      const response = await apiRequest('POST', `/api/admin/users/${userId}/upgrade`, { subscription });
      if (response.ok) {
        toast({ title: "Abonnement mis à jour", description: `Changé vers ${subscription}` });
        refetch();
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de mettre à jour", variant: "destructive" });
    }
  };

  const [editingUser, setEditingUser] = useState<any>(null);
  const [editForm, setEditForm] = useState({
    firstName: '',
    age: '',
    city: '',
    bio: '',
    photo: '',
    gender: '',
    subscription: ''
  });

  const openEditModal = (user: any) => {
    setEditingUser(user);
    setEditForm({
      firstName: user.firstName || '',
      age: user.age?.toString() || '',
      city: user.city || '',
      bio: user.bio || '',
      photo: user.photo || '',
      gender: user.gender || '',
      subscription: user.subscription || ''
    });
  };

  const saveUserChanges = async () => {
    if (!editingUser) return;
    
    const updates: any = {};
    
    if (editForm.firstName !== editingUser.firstName) {
      updates.firstName = editForm.firstName;
    }
    if (editForm.age && parseInt(editForm.age) !== editingUser.age) {
      updates.age = parseInt(editForm.age);
    }
    if (editForm.city !== editingUser.city) {
      updates.city = editForm.city;
    }
    if (editForm.bio !== editingUser.bio) {
      updates.bio = editForm.bio;
    }
    if (editForm.photo !== editingUser.photo) {
      updates.photo = editForm.photo;
    }
    if (editForm.gender !== editingUser.gender) {
      updates.gender = editForm.gender;
    }
    if (editForm.subscription !== editingUser.subscription) {
      updates.subscription = editForm.subscription;
    }
    
    if (Object.keys(updates).length > 0) {
      try {
        const response = await fetch(`/api/admin/users/${editingUser.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
        if (response.ok) {
          toast({ title: "Profil mis à jour", description: `${Object.keys(updates).length} champ(s) modifié(s)` });
          setEditingUser(null);
          refetch();
        }
      } catch (error) {
        toast({ title: "Erreur", description: "Impossible de sauvegarder", variant: "destructive" });
      }
    } else {
      setEditingUser(null);
    }
  };

  const downloadBackup = async () => {
    try {
      const link = document.createElement('a');
      link.href = '/api/admin/backup';
      link.download = `backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Backup téléchargé" });
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de télécharger", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!users) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Erreur de chargement</h2>
          <p className="text-gray-600">Impossible de charger les données</p>
        </div>
      </div>
    );
  }

  const realUsers = (users as any[]) || [];
  
  // Filtrage par recherche et filtres
  let filteredUsers = realUsers;
  if (searchQuery) {
    filteredUsers = filteredUsers.filter((user: any) =>
      user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.city?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }
  if (genderFilter) {
    filteredUsers = filteredUsers.filter((user: any) => user.gender === genderFilter);
  }
  if (subscriptionFilter) {
    filteredUsers = filteredUsers.filter((user: any) => user.subscription === subscriptionFilter);
  }
  if (ageFilter) {
    const [minAge, maxAge] = ageFilter.split('-').map(Number);
    filteredUsers = filteredUsers.filter((user: any) => user.age >= minAge && user.age <= maxAge);
  }
  
  // Tri alphabétique par prénom
  filteredUsers = filteredUsers.sort((a: any, b: any) => a.firstName.localeCompare(b.firstName, 'fr', { sensitivity: 'base' }));

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE);
  const startIndex = (currentPage - 1) * USERS_PER_PAGE;
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + USERS_PER_PAGE);

  const premiumCount = realUsers.filter(u => u.subscription === 'premium').length;
  const goldCount = realUsers.filter(u => u.subscription === 'gold').length;

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Administration Date Mature</h1>
          <p className="text-gray-600">Gestion des utilisateurs et abonnements</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Utilisateurs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{realUsers.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Premium</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{premiumCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Gold</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{goldCount}</div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mb-6">
          <Button onClick={downloadBackup} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Télécharger Backup
          </Button>
        </div>

        {/* Recherche et filtres */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Recherche et filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Input
                  placeholder="Rechercher par nom, ville, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setGenderFilter("");
                    setAgeFilter("");
                    setSubscriptionFilter("");
                    setCurrentPage(1);
                  }}
                >
                  Réinitialiser
                </Button>
              </div>
              
              <div className="flex gap-4">
                <select
                  value={genderFilter}
                  onChange={(e) => { setGenderFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les genres</option>
                  <option value="H">Hommes</option>
                  <option value="F">Femmes</option>
                </select>
                
                <select
                  value={ageFilter}
                  onChange={(e) => { setAgeFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les âges</option>
                  <option value="40-50">40-50 ans</option>
                  <option value="51-60">51-60 ans</option>
                  <option value="61-75">61-75 ans</option>
                </select>
                
                <select
                  value={subscriptionFilter}
                  onChange={(e) => { setSubscriptionFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les abonnements</option>
                  <option value="gratuit">Gratuit</option>
                  <option value="premium">Premium</option>
                  <option value="gold">Gold</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <Card>
          <CardHeader>
            <CardTitle>Utilisateurs ({filteredUsers.length} résultats)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {paginatedUsers.map((user: any) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                      {user.photo ? (
                        <img src={user.photo} alt={user.firstName} className="w-12 h-12 rounded-full object-cover" />
                      ) : (
                        <Users className="h-6 w-6 text-gray-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{user.firstName}</p>
                      <p className="text-sm text-gray-600">{user.city} • {user.age} ans</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={user.gender === 'H' ? 'default' : 'secondary'}>
                      {user.gender === 'H' ? '♂️' : '♀️'}
                    </Badge>
                    
                    <div className="flex gap-1 ml-2">
                      <Badge variant={
                        user.subscription === 'gold' ? 'default' : 
                        user.subscription === 'premium' ? 'secondary' : 'outline'
                      }>
                        {user.subscription === 'gold' ? '👑 Gold' : 
                         user.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                      </Badge>
                      <Button size="sm" variant="ghost" onClick={() => openEditModal(user)}>
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} sur {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal d'édition */}
      {editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold mb-4">Modifier le profil</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Prénom</label>
                <input
                  type="text"
                  value={editForm.firstName}
                  onChange={(e) => setEditForm({...editForm, firstName: e.target.value})}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Âge</label>
                <input
                  type="number"
                  min="40"
                  max="75"
                  value={editForm.age}
                  onChange={(e) => setEditForm({...editForm, age: e.target.value})}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Ville</label>
                <input
                  type="text"
                  value={editForm.city}
                  onChange={(e) => setEditForm({...editForm, city: e.target.value})}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Bio</label>
                <textarea
                  value={editForm.bio}
                  onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                  className="w-full p-2 border rounded h-20"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Photo URL</label>
                <input
                  type="url"
                  value={editForm.photo}
                  onChange={(e) => setEditForm({...editForm, photo: e.target.value})}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Genre</label>
                <select
                  value={editForm.gender}
                  onChange={(e) => setEditForm({...editForm, gender: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="H">Homme</option>
                  <option value="F">Femme</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Abonnement</label>
                <select
                  value={editForm.subscription}
                  onChange={(e) => setEditForm({...editForm, subscription: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="gratuit">🆓 Gratuit</option>
                  <option value="premium">⭐ Premium</option>
                  <option value="gold">👑 Gold</option>
                </select>
              </div>
            </div>
            
            <div className="flex gap-2 mt-6">
              <Button onClick={saveUserChanges} className="flex-1">
                Sauvegarder
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setEditingUser(null)}
                className="flex-1"
              >
                Annuler
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}