import { Cog, Bell, Shield, Heart, CreditCard, Trash2, LogOut } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

export default function Settings() {
  return (
    <>
      <SiteHeader />
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-slate-50">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Paramètres</h1>
          <p className="text-lg text-gray-600">
            Personnalisez votre expérience
          </p>
        </div>

        {/* Account Status */}
        <Card className="border-rose-200 bg-rose-50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <Heart className="h-6 w-6 text-rose-500 mr-3" />
                Statut du compte
              </div>
              <Badge className="bg-rose-500">Gratuit</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-rose-800 font-medium">3 flashes par jour</p>
                <p className="text-rose-600 text-sm">Passez à Premium pour plus d'avantages</p>
              </div>
              <Button className="bg-rose-500 hover:bg-rose-600">
                Voir les abonnements
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="h-6 w-6 text-gray-700 mr-3" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Nouveaux matches</h3>
                  <p className="text-sm text-gray-600">Être notifié des matches mutuels</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Messages</h3>
                  <p className="text-sm text-gray-600">Notifications de nouveaux messages</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Flashes reçus</h3>
                  <p className="text-sm text-gray-600">Quand quelqu'un vous flashe</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Rappels quotidiens</h3>
                  <p className="text-sm text-gray-600">Rappel pour utiliser vos flashes</p>
                </div>
                <Switch />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Privacy */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-6 w-6 text-gray-700 mr-3" />
              Confidentialité
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Profil public</h3>
                  <p className="text-sm text-gray-600">Votre profil est visible par tous</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Statut en ligne</h3>
                  <p className="text-sm text-gray-600">Afficher quand vous êtes connecté</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Géolocalisation</h3>
                  <p className="text-sm text-gray-600">Utiliser votre position pour les suggestions</p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="h-6 w-6 text-gray-700 mr-3" />
              Gestion d'abonnement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-6">
              <p className="text-gray-600 mb-4">Aucun abonnement actif</p>
              <Button variant="outline" className="w-full">
                Voir les plans d'abonnement
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Account Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Cog className="h-6 w-6 text-gray-700 mr-3" />
              Actions du compte
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Link href="/edit-profile">
                <Button variant="outline" className="w-full justify-start">
                  <Heart className="h-4 w-4 mr-2" />
                  Modifier mon profil
                </Button>
              </Link>
              <Link href="/security">
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="h-4 w-4 mr-2" />
                  Sécurité et confidentialité
                </Button>
              </Link>
              <Link href="/help">
                <Button variant="outline" className="w-full justify-start">
                  <Bell className="h-4 w-4 mr-2" />
                  Centre d'aide
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800">Zone dangereuse</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50">
                <Trash2 className="h-4 w-4 mr-2" />
                Supprimer mon compte
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <LogOut className="h-4 w-4 mr-2" />
                Se déconnecter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* App Info */}
        <Card className="bg-gray-50">
          <CardContent className="pt-6">
            <div className="text-center text-sm text-gray-600">
              <p>Version 1.0.0</p>
              <p className="mt-1">© 2025 Date Mature - Tous droits réservés</p>
            </div>
          </CardContent>
        </Card>
        </div>
      </div>
      <SiteFooter />
    </>
  );
}