import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Users, Heart, Zap, Crown, TrendingUp, BarChart3, Home, Download, Upload, UserPlus, MapPin, Search, ChevronLeft, ChevronRight, Camera, CameraOff, Edit3, Save, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { toast } = useToast();
  
  // États pour les filtres et recherche
  const [searchQuery, setSearchQuery] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");
  const [photoFilter, setPhotoFilter] = useState("all");
  const [regionFilter, setRegionFilter] = useState("all");
  const [subscriptionFilter, setSubscriptionFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const USERS_PER_PAGE = 10;
  
  // États pour la génération de profils
  const [selectedRegion, setSelectedRegion] = useState("");
  const [profileCount, setProfileCount] = useState(20);
  
  // États pour l'édition de profils
  const [editingUser, setEditingUser] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    firstName: "",
    bio: "",
    photo: "",
    city: "",
    age: 0
  });

  const { data: users, isLoading: usersLoading, refetch: refetchUsers } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const jsonData = JSON.parse(text);
      
      toast({
        title: "Upload en cours...",
        description: `Traitement de ${jsonData.length || 0} profils`,
        variant: "default",
      });

      // Envoyer les données au serveur
      const response = await fetch('/api/admin/upload-profiles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ profiles: jsonData }),
      });

      if (response.ok) {
        toast({
          title: "Upload réussi !",
          description: "Profils importés avec succès",
          variant: "default",
        });
        window.location.reload();
      } else {
        toast({
          title: "Erreur d'upload",
          description: "Impossible d'importer les profils",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur de fichier",
        description: "Fichier JSON invalide",
        variant: "destructive",
      });
    }
  };

  // Génération de profils régionaux
  const createRegionalProfilesMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/generate-regional-profiles", {
        region: selectedRegion,
        count: profileCount
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Profils créés !",
        description: `${data.created} profils créés en ${data.region}`,
      });
      refetchUsers();
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Erreur lors de la création des profils",
        variant: "destructive",
      });
    }
  });

  // Restauration backup
  const restoreProfilesMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/restore-profiles");
    },
    onSuccess: (data: any) => {
      toast({
        title: "Restauration réussie",
        description: `${data.usersRestored} profils restaurés depuis le backup`,
      });
      refetchUsers();
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Erreur lors de la restauration",
        variant: "destructive",
      });
    }
  });

  // Download backup
  const downloadBackupMutation = useMutation({
    mutationFn: async () => {
      // Créer un lien de téléchargement direct
      const link = document.createElement('a');
      link.href = '/api/admin/backup';
      link.download = `date-mature-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Backup téléchargé",
        description: "Sauvegarde téléchargée avec succès",
      });
    }
  });

  // Édition de profil
  const updateUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      return await apiRequest("PUT", `/api/admin/users/${userData.id}`, userData);
    },
    onSuccess: () => {
      toast({
        title: "Profil mis à jour",
        description: "Les modifications ont été sauvegardées",
      });
      setIsEditModalOpen(false);
      setEditingUser(null);
      refetchUsers();
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le profil",
        variant: "destructive",
      });
    }
  });

  // Ouvrir le modal d'édition
  const openEditModal = (user: any) => {
    setEditingUser(user);
    setEditForm({
      firstName: user.firstName || "",
      bio: user.bio || "",
      photo: user.photo || "",
      city: user.city || "",
      age: user.age || 40
    });
    setIsEditModalOpen(true);
  };

  // Sauvegarder les modifications
  const saveUserChanges = () => {
    if (!editingUser) return;
    
    updateUserMutation.mutate({
      id: editingUser.id,
      ...editForm
    });
  };

  if (usersLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-rose-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-600">Chargement du tableau de bord...</p>
        </div>
      </div>
    );
  }

  if (!users || !stats) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Erreur de chargement</h2>
          <p className="text-gray-600">Impossible de charger les données du tableau de bord</p>
        </div>
      </div>
    );
  }

  const realUsers = (users as any[]).filter((user: any) => !user.isTestProfile);
  const premiumUsers = realUsers.filter((user: any) => user.subscription === 'premium');
  const goldUsers = realUsers.filter((user: any) => user.subscription === 'gold');
  
  // Statistiques photos
  const usersWithPhoto = realUsers.filter((user: any) => user.photo && (user.photo.includes('http') || user.photo.includes('/uploads/')));
  const usersWithoutPhoto = realUsers.filter((user: any) => !user.photo || (!user.photo.includes('http') && !user.photo.includes('/uploads/')));

  const today = new Date().toISOString().split('T')[0];
  const todayUsers = realUsers.filter((user: any) => {
    const userDate = new Date(user.createdAt);
    return userDate.toISOString().split('T')[0] === today;
  });

  const conversionRate = realUsers.length > 0 ? ((premiumUsers.length + goldUsers.length) / realUsers.length * 100).toFixed(1) : 0;

  // Filtrage des utilisateurs
  let filteredUsers = realUsers;
  
  // Filtres immédiats (recherche, genre, photo, abonnement)
  if (searchQuery) {
    filteredUsers = filteredUsers.filter((user: any) => 
      user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.city?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }
  
  if (genderFilter !== "all") {
    filteredUsers = filteredUsers.filter((user: any) => user.gender === genderFilter);
  }
  
  if (photoFilter !== "all") {
    if (photoFilter === "with_photo") {
      filteredUsers = filteredUsers.filter((user: any) => user.photo && (user.photo.includes('http') || user.photo.includes('/uploads/')));
    } else if (photoFilter === "no_photo") {
      filteredUsers = filteredUsers.filter((user: any) => !user.photo || (!user.photo.includes('http') && !user.photo.includes('/uploads/')));
    }
  }

  if (subscriptionFilter !== "all") {
    filteredUsers = filteredUsers.filter((user: any) => user.subscription === subscriptionFilter);
  }

  // Filtre région uniquement après bouton rechercher
  if (regionFilter !== "all" && searchTriggered) {
    const regionCities = getRegionCities(regionFilter);
    filteredUsers = filteredUsers.filter((user: any) => {
      if (!user?.city || typeof user.city !== 'string') return false;
      const userCityLower = user.city.toLowerCase();
      return regionCities.some(city => 
        userCityLower.includes(city.toLowerCase()) || 
        city.toLowerCase().includes(userCityLower)
      );
    });
  }

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE);
  const startIndex = (currentPage - 1) * USERS_PER_PAGE;
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + USERS_PER_PAGE);

  // Répartition par ville
  const cityStats = realUsers.reduce((acc: any, user: any) => {
    acc[user.city] = (acc[user.city] || 0) + 1;
    return acc;
  }, {});
  const topCities = Object.entries(cityStats).sort(([,a]: any, [,b]: any) => b - a).slice(0, 5);

  // Les 13 régions françaises
  const regions = [
    { value: 'ile-de-france', label: 'Île-de-France' },
    { value: 'provence', label: 'Provence-Alpes-Côte d\'Azur' },
    { value: 'auvergne-rhone-alpes', label: 'Auvergne-Rhône-Alpes' },
    { value: 'nouvelle-aquitaine', label: 'Nouvelle-Aquitaine' },
    { value: 'occitanie', label: 'Occitanie' },
    { value: 'hauts-de-france', label: 'Hauts-de-France' },
    { value: 'normandie', label: 'Normandie' },
    { value: 'centre-val-de-loire', label: 'Centre-Val de Loire' },
    { value: 'grand-est', label: 'Grand Est' },
    { value: 'pays-de-la-loire', label: 'Pays de la Loire' },
    { value: 'bretagne', label: 'Bretagne' },
    { value: 'bourgogne-franche-comte', label: 'Bourgogne-Franche-Comté' },
    { value: 'corse', label: 'Corse' }
  ];

  const getRegionCities = (region: string) => {
    const regionCitiesMap: { [key: string]: string[] } = {
      'ile-de-france': ['Paris', 'Versailles', 'Nanterre', 'Créteil', 'Pontoise', 'Évry', 'Meaux', 'Melun'],
      'provence': ['Marseille', 'Nice', 'Toulon', 'Aix-en-Provence', 'Avignon', 'Antibes', 'Cannes', 'Fréjus'],
      'auvergne-rhone-alpes': ['Lyon', 'Grenoble', 'Saint-Étienne', 'Chambéry', 'Annecy', 'Valence', 'Clermont-Ferrand', 'Bourg-en-Bresse'],
      'nouvelle-aquitaine': ['Bordeaux', 'Limoges', 'Poitiers', 'La Rochelle', 'Pau', 'Bayonne', 'Périgueux', 'Mont-de-Marsan'],
      'occitanie': ['Toulouse', 'Montpellier', 'Nîmes', 'Perpignan', 'Béziers', 'Albi', 'Carcassonne', 'Cahors'],
      'hauts-de-france': ['Lille', 'Amiens', 'Roubaix', 'Tourcoing', 'Calais', 'Dunkerque', 'Valenciennes', 'Beauvais'],
      'normandie': ['Rouen', 'Le Havre', 'Caen', 'Cherbourg', 'Évreux', 'Alençon', 'Lisieux', 'Dieppe'],
      'centre-val-de-loire': ['Orléans', 'Tours', 'Bourges', 'Chartres', 'Blois', 'Châteauroux', 'Dreux', 'Vierzon'],
      'grand-est': ['Strasbourg', 'Metz', 'Nancy', 'Reims', 'Mulhouse', 'Troyes', 'Charleville-Mézières', 'Colmar'],
      'pays-de-la-loire': ['Nantes', 'Angers', 'Le Mans', 'Saint-Nazaire', 'La Roche-sur-Yon', 'Cholet', 'Laval', 'Saumur'],
      'bretagne': ['Rennes', 'Brest', 'Quimper', 'Lorient', 'Vannes', 'Saint-Malo', 'Saint-Brieuc', 'Fougères'],
      'bourgogne-franche-comte': ['Dijon', 'Besançon', 'Belfort', 'Montbéliard', 'Chalon-sur-Saône', 'Auxerre', 'Mâcon', 'Nevers'],
      'corse': ['Ajaccio', 'Bastia', 'Porto-Vecchio', 'Calvi', 'Corte', 'Bonifacio', 'Propriano', 'Ghisonaccia']
    };
    return regionCitiesMap[region] || [];
  };

  // État pour déclencher la recherche manuellement
  const [searchTriggered, setSearchTriggered] = useState(false);

  // Debug: compter les profils par région (simplifié)
  const debugRegionCount = (region: string) => {
    try {
      if (!users || !Array.isArray(users) || region === "all") return 0;
      const regionCities = getRegionCities(region);
      if (!regionCities.length) return 0;
      
      const count = users.filter((user: any) => {
        if (!user?.city || typeof user.city !== 'string') return false;
        const userCityLower = user.city.toLowerCase();
        return regionCities.some(city => 
          userCityLower.includes(city.toLowerCase()) || 
          city.toLowerCase().includes(userCityLower)
        );
      }).length;
      return count;
    } catch (e) {
      console.error('Error counting region:', e);
      return 0;
    }
  };

  const MetricCard = ({ title, value, icon: Icon, color, change }: any) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {change && <p className="text-xs text-muted-foreground mt-1">{change}</p>}
          </div>
          <Icon className={`h-8 w-8 ${color}`} />
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header avec navigation */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Date Mature</h1>
            <p className="text-gray-600 mt-1">Gestion complète de la plateforme</p>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/landing" className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
              <Home className="h-4 w-4" />
              Landing Page
            </Link>
            <Link href="/" className="flex items-center gap-2 px-4 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors">
              <Home className="h-4 w-4" />
              Retour App
            </Link>
          </div>
        </div>

        {/* Métriques principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total utilisateurs réels"
            value={realUsers.length}
            icon={Users}
            change={`+${todayUsers.length} inscrits aujourd'hui`}
            color="text-blue-600"
          />
          <MetricCard
            title="Profils avec photo"
            value={usersWithPhoto.length}
            icon={Camera}
            color="text-green-600"
            change={`${((usersWithPhoto.length / realUsers.length) * 100).toFixed(1)}% du total`}
          />
          <MetricCard
            title="Profils sans photo"
            value={usersWithoutPhoto.length}
            icon={CameraOff}
            color="text-red-600"
            change={`${((usersWithoutPhoto.length / realUsers.length) * 100).toFixed(1)}% du total`}
          />
          <MetricCard
            title="Abonnements payants"
            value={`${conversionRate}%`}
            icon={TrendingUp}
            color="text-purple-600"
            change={`${premiumUsers.length + goldUsers.length} Premium/Gold`}
          />
        </div>

        {/* Section génération de profils */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Génération de profils par région
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="region-select">Région (13 disponibles)</Label>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir une région" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((region) => (
                      <SelectItem key={region.value} value={region.value}>
                        {region.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="profile-count">Nombre de profils (5-50, mixte)</Label>
                <Select value={profileCount.toString()} onValueChange={(value) => setProfileCount(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[5, 10, 15, 20, 25, 30, 35, 40, 45, 50].map((count) => (
                      <SelectItem key={count} value={count.toString()}>
                        {count} profils
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button 
                  onClick={() => createRegionalProfilesMutation.mutate()}
                  disabled={!selectedRegion || createRegionalProfilesMutation.isPending}
                  className="w-full"
                >
                  {createRegionalProfilesMutation.isPending ? "Création..." : "Créer Profils"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section recherche et filtres */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Recherche et filtres
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div>
                <Label htmlFor="search">Recherche (nom, ville, email)</Label>
                <Input
                  id="search"
                  type="text"
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="gender-filter">Genre</Label>
                <Select value={genderFilter} onValueChange={setGenderFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="H">♂️ Hommes</SelectItem>
                    <SelectItem value="F">♀️ Femmes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="photo-filter">Statut photo</Label>
                <Select value={photoFilter} onValueChange={setPhotoFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="with_photo">📸 Avec photo</SelectItem>
                    <SelectItem value="no_photo">❌ Sans photo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="region-filter">Région</Label>
                <Select value={regionFilter} onValueChange={setRegionFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les régions</SelectItem>
                    {regions.map((region) => (
                      <SelectItem key={region.value} value={region.value}>
                        {region.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="subscription-filter">Abonnement</Label>
                <Select value={subscriptionFilter} onValueChange={setSubscriptionFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="gratuit">🆓 Gratuit</SelectItem>
                    <SelectItem value="premium">⭐ Premium</SelectItem>
                    <SelectItem value="gold">👑 Gold</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={() => {
                    setSearchTriggered(true);
                    setCurrentPage(1);
                  }}
                  className="w-full"
                >
                  🔍 Rechercher
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSearchQuery("");
                    setGenderFilter("all");
                    setPhotoFilter("all");
                    setRegionFilter("all");
                    setSubscriptionFilter("all");
                    setSearchTriggered(false);
                    setCurrentPage(1);
                  }}
                  className="w-full"
                >
                  Réinitialiser
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Utilisateurs ({filteredUsers.length} résultats filtrés sur {realUsers.length} total - {USERS_PER_PAGE}/page)
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} sur {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {paginatedUsers.map((user: any) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div 
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => openEditModal(user)}
                      title="Cliquer pour éditer le profil"
                    >
{user.photo ? (
                        <img 
                          src={user.photo}
                          alt={user.firstName}
                          className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
                          style={{ display: 'block' }}
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-full bg-purple-500 border-2 border-gray-200 flex items-center justify-center text-white font-bold text-lg">
                          {user.firstName?.charAt(0)?.toUpperCase() || '?'}
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold">{user.firstName}, {user.age} ans</p>
                        <span className={`px-2 py-1 rounded-full text-xs ${user.gender === 'H' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'}`}>
                          {user.gender === 'H' ? 'Homme' : 'Femme'}
                        </span>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                          📸 Photo
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{user.city} • {user.email}</p>
                      <p className="text-sm text-gray-500 mb-2">{user.subscription}</p>
                      {user.bio && (
                        <p className="text-sm text-gray-600 italic truncate max-w-md">
                          "{user.bio}"
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right mr-4">
                      <p className="text-sm text-gray-500">
                        {new Date(user.createdAt).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditModal(user)}
                      className="flex items-center gap-2"
                    >
                      <Edit3 className="h-4 w-4" />
                      Éditer
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Section utilitaires - TOUT EN UN */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Sauvegarde & Restauration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={() => downloadBackupMutation.mutate()}
                disabled={downloadBackupMutation.isPending}
                className="w-full"
                variant="outline"
              >
                <Download className="h-4 w-4 mr-2" />
                Télécharger backup JSON
              </Button>
              <Button
                onClick={async () => {
                  try {
                    toast({
                      title: "Import backup...",
                      description: "Traitement des 985 profils en cours...",
                    });
                    
                    const response = await fetch('/api/import-backup-now');
                    
                    if (response.ok) {
                      const result = await response.json();
                      toast({
                        title: "Import terminé !",
                        description: `${result.imported} profils importés sur ${result.total}`,
                      });
                      setTimeout(() => window.location.reload(), 2000);
                    } else {
                      const error = await response.text();
                      toast({
                        title: "Erreur d'import",
                        description: error.substring(0, 100),
                        variant: "destructive",
                      });
                    }
                  } catch (error) {
                    toast({
                      title: "Erreur",
                      description: "Impossible d'importer le backup",
                      variant: "destructive",
                    });
                  }
                }}
                disabled={false}
                className="w-full"
                variant="outline"
              >
                <Upload className="h-4 w-4 mr-2" />
                Importer backup permanent (985 profils)
              </Button>
              
              {/* Nouveau bouton pour uploader un fichier JSON */}
              <div className="w-full">
                <input
                  type="file"
                  accept=".json"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    
                    try {
                      const text = await file.text();
                      console.log('Contenu fichier:', text.substring(0, 200));
                      const jsonData = JSON.parse(text);
                      console.log('JSON parsé:', jsonData.length, 'éléments');
                      
                      toast({
                        title: "Upload en cours...",
                        description: `Traitement de ${jsonData.length || 0} profils`,
                      });

                      const response = await fetch('/api/admin/upload-profiles', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ profiles: Array.isArray(jsonData) ? jsonData : [jsonData] }),
                      });

                      if (response.ok) {
                        const result = await response.json();
                        toast({
                          title: "Upload réussi !",
                          description: `${result.imported} profils importés sur ${result.total}`,
                        });
                        setTimeout(() => window.location.reload(), 1000);
                      } else {
                        const error = await response.text();
                        console.error('Erreur serveur complète:', error);
                        console.error('Status:', response.status);
                        toast({
                          title: "Erreur d'upload",
                          description: `Erreur ${response.status}: ${error.substring(0, 100)}`,
                          variant: "destructive",
                        });
                      }
                    } catch (error) {
                      console.error('Erreur complète:', error);
                      toast({
                        title: "Erreur de fichier",
                        description: `Erreur: ${error.message}`,
                        variant: "destructive",
                      });
                    }
                  }}
                  className="hidden"
                  id="json-upload"
                />
                <label htmlFor="json-upload">
                  <Button
                    type="button"
                    className="w-full"
                    variant="default"
                    onClick={() => document.getElementById('json-upload')?.click()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Uploader fichier JSON
                  </Button>
                </label>
              </div>
              <div className="border-t pt-4">
                <label className="block text-sm font-medium mb-2">Importer fichier CSV</label>
                <input
                  type="file"
                  accept=".csv"
                  className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Top 5 des villes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topCities.map(([city, count], index) => (
                  <div key={city} className="flex items-center justify-between">
                    <span className="text-sm font-medium">{index + 1}. {city}</span>
                    <span className="text-sm text-gray-600">{count} profils</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modal d'édition de profil */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit3 className="h-5 w-5" />
              Éditer le profil de {editingUser?.firstName}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-firstName">Prénom</Label>
                <Input
                  id="edit-firstName"
                  value={editForm.firstName}
                  onChange={(e) => setEditForm({...editForm, firstName: e.target.value})}
                  placeholder="Prénom"
                />
              </div>
              <div>
                <Label htmlFor="edit-age">Âge</Label>
                <Input
                  id="edit-age"
                  type="number"
                  min="40"
                  max="75"
                  value={editForm.age}
                  onChange={(e) => setEditForm({...editForm, age: parseInt(e.target.value)})}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="edit-city">Ville</Label>
              <Input
                id="edit-city"
                value={editForm.city}
                onChange={(e) => setEditForm({...editForm, city: e.target.value})}
                placeholder="Ville"
              />
            </div>
            
            <div>
              <Label htmlFor="edit-photo">Photo</Label>
              <div className="space-y-2">
                <Input
                  id="edit-photo"
                  value={editForm.photo}
                  onChange={(e) => setEditForm({...editForm, photo: e.target.value})}
                  placeholder="URL de la photo (https://...)"
                />
                <div className="text-sm text-gray-500">ou</div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const formData = new FormData();
                      formData.append('photo', file);
                      try {
                        const response = await fetch('/api/upload/photo', {
                          method: 'POST',
                          body: formData
                        });
                        const data = await response.json();
                        if (data.url) {
                          setEditForm({...editForm, photo: data.url});
                        }
                      } catch (error) {
                        console.error('Erreur upload:', error);
                      }
                    }
                  }}
                  className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
              {editForm.photo && (
                <div className="mt-2 flex items-center gap-2">
                  <img 
                    src={editForm.photo} 
                    alt="Aperçu" 
                    className="w-16 h-16 rounded-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                  <span className="text-sm text-gray-600">Aperçu de la photo</span>
                </div>
              )}
            </div>
            
            <div>
              <Label htmlFor="edit-bio">Description</Label>
              <Textarea
                id="edit-bio"
                value={editForm.bio}
                onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                placeholder="Description du profil..."
                rows={3}
                maxLength={300}
              />
              <p className="text-sm text-gray-500 mt-1">
                {editForm.bio.length}/300 caractères
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button
              onClick={saveUserChanges}
              disabled={updateUserMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {updateUserMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}