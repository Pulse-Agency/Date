import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Star, Crown, Sparkles, PartyPopper } from 'lucide-react';

export default function DemoAnimations() {
  const [activeDemo, setActiveDemo] = useState<string | null>(null);

  const triggerDemo = (demoType: string) => {
    setActiveDemo(demoType);
    setTimeout(() => setActiveDemo(null), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Démonstration des Animations Date Mature
          </h1>
          <p className="text-gray-600">
            Découvrez les effets visuels qui enrichissent l'expérience utilisateur
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Animation Heart Pulse */}
          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-red-500" />
                Nouveau Match
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Heart 
                  className={`h-16 w-16 text-red-500 mx-auto mb-4 ${
                    activeDemo === 'match' ? 'heart-pulse' : ''
                  }`}
                />
                <p className="text-gray-600 mb-4">
                  Cœur qui pulse lors d'un match mutuel
                </p>
                <Button 
                  onClick={() => triggerDemo('match')}
                  className="bg-red-500 hover:bg-red-600"
                >
                  Déclencher Match
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Animation Confetti */}
          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PartyPopper className="h-5 w-5 text-yellow-500" />
                Célébration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 relative">
                <PartyPopper className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  Confetti qui flotte lors d'une célébration
                </p>
                <Button 
                  onClick={() => triggerDemo('celebration')}
                  className="bg-yellow-500 hover:bg-yellow-600"
                >
                  Lancer Célébration
                </Button>
                
                {/* Confetti Elements */}
                {activeDemo === 'celebration' && (
                  <div className="absolute inset-0 pointer-events-none">
                    {[...Array(12)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute confetti-float"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: '100%',
                          animationDelay: `${Math.random() * 0.5}s`,
                        }}
                      >
                        <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                      </div>
                    ))}
                    {[...Array(8)].map((_, i) => (
                      <div
                        key={i + 12}
                        className="absolute confetti-float"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: '100%',
                          animationDelay: `${Math.random() * 0.5}s`,
                        }}
                      >
                        <div className="w-2 h-2 bg-pink-400 rounded-full" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Animation Sparkle Premium */}
          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-purple-500" />
                Upgrade Premium
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 relative">
                <Crown className="h-16 w-16 text-purple-500 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  Étoiles scintillantes pour upgrade Premium
                </p>
                <Button 
                  onClick={() => triggerDemo('premium')}
                  className="bg-purple-500 hover:bg-purple-600"
                >
                  Upgrade Premium
                </Button>
                
                {/* Sparkles Premium */}
                {activeDemo === 'premium' && (
                  <div className="absolute inset-0 pointer-events-none">
                    {[...Array(8)].map((_, i) => (
                      <Star
                        key={i}
                        className="absolute sparkle-glow text-purple-400"
                        style={{
                          left: `${20 + Math.random() * 60}%`,
                          top: `${20 + Math.random() * 60}%`,
                          animationDelay: `${Math.random() * 0.5}s`,
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Animation Sparkle Gold */}
          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-600" />
                Upgrade Gold
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 relative">
                <Sparkles className="h-16 w-16 text-yellow-600 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  Étoiles dorées pour upgrade Gold
                </p>
                <Button 
                  onClick={() => triggerDemo('gold')}
                  className="bg-yellow-600 hover:bg-yellow-700"
                >
                  Upgrade Gold
                </Button>
                
                {/* Sparkles Gold */}
                {activeDemo === 'gold' && (
                  <div className="absolute inset-0 pointer-events-none">
                    {[...Array(12)].map((_, i) => (
                      <Sparkles
                        key={i}
                        className="absolute sparkle-glow text-yellow-500"
                        style={{
                          left: `${15 + Math.random() * 70}%`,
                          top: `${15 + Math.random() * 70}%`,
                          animationDelay: `${Math.random() * 0.8}s`,
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Animation Slide Up */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Notifications en Douceur
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-4">
              <p className="text-gray-600 mb-4">
                Apparition en douceur pour les notifications
              </p>
              <Button 
                onClick={() => triggerDemo('notification')}
                className="bg-blue-500 hover:bg-blue-600"
              >
                Afficher Notification
              </Button>
              
              {activeDemo === 'notification' && (
                <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg slide-up-fade">
                  <p className="text-blue-800">
                    🎉 Nouvelle notification ! Vous avez un nouveau match !
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Légende technique */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Détails Techniques</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-semibold mb-2">Classes CSS ajoutées :</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• <code>heart-pulse</code> - Pulsation des cœurs</li>
                  <li>• <code>confetti-float</code> - Confetti qui flotte</li>
                  <li>• <code>sparkle-glow</code> - Étoiles scintillantes</li>
                  <li>• <code>slide-up-fade</code> - Apparition en douceur</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Utilisation :</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Match mutuel → heart-pulse</li>
                  <li>• Célébrations → confetti-float</li>
                  <li>• Upgrades → sparkle-glow</li>
                  <li>• Notifications → slide-up-fade</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}