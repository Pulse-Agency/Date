import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RefreshCw, Trash2 } from 'lucide-react';

export default function ResetPopupEbook() {
  const [status, setStatus] = useState<string>('');

  const clearLocalStorage = () => {
    try {
      localStorage.removeItem('newsletter_popup_last_shown');
      localStorage.removeItem('newsletter_popup_dismissed_v2');
      localStorage.removeItem('newsletter_subscribed');
      setStatus('✅ LocalStorage nettoyé ! Le popup pourra maintenant s\'afficher.');
    } catch (e) {
      setStatus('❌ Erreur lors du nettoyage du localStorage');
    }
  };

  const checkLocalStorage = () => {
    try {
      const lastShown = localStorage.getItem('newsletter_popup_last_shown');
      const dismissed = localStorage.getItem('newsletter_popup_dismissed_v2');
      const subscribed = localStorage.getItem('newsletter_subscribed');
      
      setStatus(`
        📊 État actuel :
        • Dernière vue : ${lastShown || 'Jamais'}
        • Fermé : ${dismissed || 'Non'}
        • Inscrit : ${subscribed || 'Non'}
      `);
    } catch (e) {
      setStatus('❌ Erreur lors de la lecture du localStorage');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">
              🔧 Reset Popup Newsletter
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center space-y-4">
              <Button
                onClick={checkLocalStorage}
                className="w-full bg-blue-500 hover:bg-blue-600"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Vérifier l'état du popup
              </Button>
              
              <Button
                onClick={clearLocalStorage}
                className="w-full bg-red-500 hover:bg-red-600"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Nettoyer et réinitialiser
              </Button>
            </div>
            
            {status && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <pre className="text-sm whitespace-pre-wrap">{status}</pre>
              </div>
            )}
            
            <div className="text-sm text-gray-600 space-y-2">
              <p><strong>Comment tester :</strong></p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Cliquez sur "Nettoyer et réinitialiser"</li>
                <li>Allez sur la page d'accueil /</li>
                <li>Le popup devrait apparaître après 15 secondes</li>
                <li>Ou scrollez à 80% de la page</li>
                <li>Ou bougez la souris vers le haut (exit intent)</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}