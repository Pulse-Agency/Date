import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Send, Smile } from "lucide-react";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useWebSocket } from "@/hooks/use-websocket";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Message } from "@shared/schema";

export default function Chat() {
  const { partnerId } = useParams();
  const [messageInput, setMessageInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();
  const { toast } = useToast();

  // Get current user
  const { data: currentUserData } = useQuery({
    queryKey: ["/api/users/current"],
  });

  const currentUser = currentUserData?.user;

  // Get partner info
  const { data: partnerData } = useQuery({
    queryKey: ["/api/users", partnerId],
    enabled: !!partnerId,
  });

  // Get conversation messages
  const { data: messagesData, refetch: refetchMessages } = useQuery({
    queryKey: ["/api/messages", currentUser?.id, partnerId],
    enabled: !!currentUser?.id && !!partnerId,
  });

  const messages = messagesData?.messages || [];

  // WebSocket for real-time messaging
  const { joinConversation, sendMessage, sendTyping } = useWebSocket({
    onMessage: (message: Message) => {
      queryClient.setQueryData(
        ["/api/messages", currentUser?.id, partnerId],
        (old: any) => ({
          ...old,
          messages: [...(old?.messages || []), message]
        })
      );
      scrollToBottom();
    },
    onTyping: (data) => {
      if (data.userId !== currentUser?.id) {
        setPartnerTyping(data.isTyping);
        if (data.isTyping) {
          setTimeout(() => setPartnerTyping(false), 3000);
        }
      }
    }
  });

  // Mark messages as read
  const markAsReadMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/messages/read", {
        senderId: parseInt(partnerId!),
        receiverId: currentUser!.id
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
    }
  });

  useEffect(() => {
    if (currentUser?.id && partnerId) {
      joinConversation(currentUser.id, parseInt(partnerId));
      markAsReadMutation.mutate();
    }
  }, [currentUser?.id, partnerId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !currentUser?.id || !partnerId) return;

    sendMessage(currentUser.id, parseInt(partnerId), messageInput.trim());
    setMessageInput("");
    setIsTyping(false);
    sendTyping(currentUser.id, parseInt(partnerId), false);
  };

  const handleInputChange = (value: string) => {
    setMessageInput(value);
    
    if (value.trim() && !isTyping) {
      setIsTyping(true);
      sendTyping(currentUser!.id, parseInt(partnerId!), true);
    }

    // Clear previous timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set new timeout
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      sendTyping(currentUser!.id, parseInt(partnerId!), false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('fr-FR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getSubscriptionBadge = (subscription: string) => {
    if (subscription === 'gold') {
      return (
        <Badge className="bg-yellow-500 text-white text-xs">
          <span>👑</span>
        </Badge>
      );
    }
    if (subscription === 'premium') {
      return (
        <Badge className="bg-purple-600 text-white text-xs">
          <span>⭐</span>
        </Badge>
      );
    }
    return null;
  };

  if (!currentUser || !partnerId) {
    return (
      <div className="h-screen flex items-center justify-center">
        <p>Chargement...</p>
      </div>
    );
  }

  // For demo purposes, get partner from user suggestions
  // In a real app, you'd have a separate API endpoint
  const partner = {
    id: parseInt(partnerId),
    firstName: "Marie",
    photo: "https://randomuser.me/api/portraits/women/45.jpg",
    subscription: "gold"
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-4 flex items-center space-x-4">
        <Link href="/messages">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        
        <img
          src={partner.photo}
          alt={`Profil de ${partner.firstName}`}
          className="w-12 h-12 rounded-full object-cover"
        />
        
        <div className="flex-1">
          <h3 className="font-semibold text-lg">{partner.firstName}</h3>
          <p className="text-sm text-gray-500 flex items-center">
            <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2"></span>
            En ligne
          </p>
        </div>
        
        {getSubscriptionBadge(partner.subscription)}
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500 text-lg">
              C'est le début de votre conversation avec {partner.firstName} !
            </p>
            <p className="text-gray-400 mt-2">
              Envoyez le premier message pour briser la glace.
            </p>
          </div>
        ) : (
          messages.map((message: Message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.senderId === currentUser.id ? 'justify-end' : ''
              }`}
            >
              {message.senderId !== currentUser.id && (
                <img
                  src={partner.photo}
                  alt={partner.firstName}
                  className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                />
              )}
              
              <div className="max-w-xs">
                <div
                  className={`p-4 rounded-2xl ${
                    message.senderId === currentUser.id
                      ? 'bg-primary text-white rounded-tr-lg'
                      : 'bg-gray-100 text-gray-800 rounded-tl-lg'
                  }`}
                >
                  <p>{message.content}</p>
                </div>
                <p
                  className={`text-xs text-gray-500 mt-1 ${
                    message.senderId === currentUser.id ? 'text-right' : ''
                  }`}
                >
                  {formatTime(message.createdAt)}
                </p>
              </div>
            </div>
          ))
        )}

        {/* Typing Indicator */}
        {partnerTyping && (
          <div className="flex items-start space-x-3">
            <img
              src={partner.photo}
              alt={partner.firstName}
              className="w-8 h-8 rounded-full object-cover flex-shrink-0"
            />
            <div className="bg-gray-100 p-4 rounded-2xl rounded-tl-lg">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <Input
              value={messageInput}
              onChange={(e) => handleInputChange(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Tapez votre message..."
              className="text-lg p-4 pr-12 rounded-2xl"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-primary"
            >
              <Smile className="h-5 w-5" />
            </Button>
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!messageInput.trim()}
            className="w-12 h-12 rounded-full p-0"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
