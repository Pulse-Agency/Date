import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useNewsletterPopup } from '@/hooks/use-newsletter-popup';
import { RefreshCw } from 'lucide-react';

export default function TestPopupFinal() {
  const { showPopup, closePopup, triggersActive } = useNewsletterPopup();
  const [timeLeft, setTimeLeft] = useState(15);
  const [scrollPercent, setScrollPercent] = useState(0);

  // Compteur pour suivre le timer
  useEffect(() => {
    if (!triggersActive) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);

    return () => clearInterval(timer);
  }, [triggersActive]);

  // Suivi du scroll
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight;
      const clientHeight = document.documentElement.clientHeight;
      const scrollPercent = (scrollTop / (scrollHeight - clientHeight)) * 100;
      setScrollPercent(scrollPercent);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const resetStates = () => {
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-md mx-auto pt-8">
        <Card className="border-2 border-pink-200 shadow-lg mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-xl text-gray-800">
              Test Popup Newsletter - Final
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Nouveau système : 3s init + déclencheurs
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">États actuels :</h3>
              <div className="text-sm space-y-1">
                <p>• Déclencheurs actifs : {triggersActive ? "✅ OUI" : "❌ Attente..."}</p>
                <p>• Popup visible : {showPopup ? "✅ OUI" : "❌ Non"}</p>
                <p>• Temps restant : {timeLeft}s</p>
                <p>• Scroll : {scrollPercent.toFixed(1)}%</p>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Storage :</h3>
              <div className="text-xs space-y-1">
                <p>• Montré : {localStorage.getItem('newsletter_popup_last_shown') || 'Non'}</p>
                <p>• Fermé : {localStorage.getItem('newsletter_popup_dismissed_v2') || 'Non'}</p>
                <p>• Abonné : {localStorage.getItem('newsletter_subscribed') || 'Non'}</p>
              </div>
            </div>

            <Button 
              onClick={resetStates}
              className="w-full bg-pink-600 hover:bg-pink-700 text-white"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset & Recharger
            </Button>

            <div className="text-xs text-gray-500 text-center">
              <p>Test :</p>
              <p>• Attendez 30s pour timer</p>
              <p>• Scrollez à 80% pour scroll</p>
              <p>• Bougez souris vers le haut pour exit intent</p>
            </div>
          </CardContent>
        </Card>

        {/* Popup de test */}
        {showPopup && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg max-w-md mx-4">
              <h3 className="text-lg font-semibold mb-4">🎉 Popup Déclenché !</h3>
              <p className="text-gray-600 mb-4">
                Excellent ! Le nouveau système fonctionne.
              </p>
              <Button onClick={closePopup} className="w-full">
                Fermer
              </Button>
            </div>
          </div>
        )}

        {/* Contenu long pour tester le scroll */}
        <div className="space-y-4">
          {Array.from({ length: 30 }, (_, i) => (
            <Card key={i} className="p-4">
              <p className="text-gray-700">
                Contenu #{i + 1} - Le système attend 3 secondes avant d'activer les déclencheurs. 
                Scrollez vers le bas pour déclencher le popup à 80%.
              </p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}