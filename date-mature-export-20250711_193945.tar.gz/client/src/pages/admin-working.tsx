import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Users, Download, Settings, UserPlus, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function AdminWorking() {
  const [stats, setStats] = useState<any>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/users?limit=1');
      const data = await response.json();
      setStats(data.stats || {});
    } catch (error) {
      console.error('Erreur fetch stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadBackup = () => {
    window.open('/api/admin/backup', '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">
                Administration Date Mature
              </h1>
            </div>
            <Button onClick={downloadBackup} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Backup JSON
            </Button>
          </div>
        </div>
      </div>

      {/* Dashboard */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistiques principales */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.total || 0}</div>
              <div className="text-sm opacity-90">Total Utilisateurs</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.filtered || 0}</div>
              <div className="text-sm opacity-90">Actifs</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.premium || 0}</div>
              <div className="text-sm opacity-90">Premium</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.gold || 0}</div>
              <div className="text-sm opacity-90">Gold</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-pink-500 to-pink-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.withPhotos || 0}</div>
              <div className="text-sm opacity-90">Avec Photos</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold">{stats.starProfiles || 0}</div>
              <div className="text-sm opacity-90">Profils *</div>
            </CardContent>
          </Card>
        </div>

        {/* Boutons d'actions principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link href="/admin/users">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Gestion des Utilisateurs
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Voir, modifier et gérer tous les profils utilisateurs
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link href="/admin/debug">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Debug & Tests
                </CardTitle>
                <Settings className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Outils de diagnostic et tests API
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Sauvegarde & Restauration
              </CardTitle>
              <Download className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Exporter les données en JSON
              </p>
              <Button 
                size="sm" 
                className="mt-2 w-full"
                onClick={downloadBackup}
              >
                Télécharger Backup
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Informations système */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              État du Système
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Base de données :</span>
                <span className="text-sm font-medium text-green-600">✅ Opérationnelle</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">API Admin :</span>
                <span className="text-sm font-medium text-green-600">✅ Fonctionnelle</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Profils restaurés :</span>
                <span className="text-sm font-medium text-green-600">✅ {stats.total || 0} profils</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Profils personnalisés (*) :</span>
                <span className="text-sm font-medium text-green-600">✅ {stats.starProfiles || 0} profils</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}