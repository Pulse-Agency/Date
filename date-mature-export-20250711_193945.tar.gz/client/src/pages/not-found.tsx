export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        {/* Logo Date Mature */}
        <div className="mb-8">
          <div className="text-6xl mb-4">💕</div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Date Mature</h1>
          <p className="text-gray-600 text-sm">Vous êtes bien sur Date Mature</p>
        </div>
        
        {/* Message d'erreur */}
        <div className="mb-8">
          <div className="text-5xl mb-4">😅</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Oups !</h2>
          <h3 className="text-lg text-gray-600 mb-4">Cette page n'existe pas</h3>
          <p className="text-gray-500 mb-6">
            Il semble que cette page ait disparu ou que le lien soit incorrect.
            Pas de panique, nous allons vous ramener en sécurité !
          </p>
        </div>
        
        {/* Bouton retour accueil */}
        <div className="space-y-4">
          <button 
            onClick={() => window.location.href = '/'}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:shadow-lg transition-all duration-300 text-lg"
          >
            🏠 Retourner à l'accueil
          </button>
          
          <p className="text-gray-400 text-sm">
            Cliquez sur le bouton ci-dessus pour revenir à votre page d'accueil
          </p>
        </div>
        
        {/* Liens utiles */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <p className="text-gray-500 text-sm mb-4">Ou explorez ces pages :</p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <button 
              onClick={() => window.location.href = '/profiles'}
              className="text-pink-600 hover:text-pink-800 py-2"
            >
              Découvrir des profils
            </button>
            <button 
              onClick={() => window.location.href = '/messages'}
              className="text-pink-600 hover:text-pink-800 py-2"
            >
              Mes messages
            </button>
            <button 
              onClick={() => window.location.href = '/help'}
              className="text-pink-600 hover:text-pink-800 py-2"
            >
              Aide
            </button>
            <button 
              onClick={() => window.location.href = '/settings'}
              className="text-pink-600 hover:text-pink-800 py-2"
            >
              Paramètres
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
