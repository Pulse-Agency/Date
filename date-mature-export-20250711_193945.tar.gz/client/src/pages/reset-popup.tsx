import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export default function ResetPopup() {
  const { toast } = useToast();

  const resetPopupSettings = () => {
    // Supprimer toutes les clés liées au popup newsletter
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    
    toast({
      title: "Paramètres réinitialisés",
      description: "Le popup newsletter peut maintenant s'afficher à nouveau. Rechargez la page pour tester.",
    });

    // Log pour debugging
    console.log('Popup settings reset! Current values:', {
      lastShown: localStorage.getItem('newsletter_popup_last_shown'),
      dismissed: localStorage.getItem('newsletter_popup_dismissed_v2'),
      subscribed: localStorage.getItem('newsletter_subscribed')
    });
  };

  const getCurrentSettings = () => {
    return {
      lastShown: localStorage.getItem('newsletter_popup_last_shown'),
      dismissed: localStorage.getItem('newsletter_popup_dismissed_v2'),
      subscribed: localStorage.getItem('newsletter_subscribed')
    };
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Réinitialisation Popup Newsletter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-800 mb-2">État actuel :</h3>
                <pre className="text-sm text-yellow-700">
                  {JSON.stringify(getCurrentSettings(), null, 2)}
                </pre>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800 mb-2">Déclencheurs du popup :</h3>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Après 30 secondes sur la page</li>
                  <li>• Scroll à 80% de la page</li>
                  <li>• Mouvement souris vers le haut (exit intent)</li>
                  <li>• Tentative de quitter la page</li>
                </ul>
              </div>

              <Button 
                onClick={resetPopupSettings}
                className="w-full mb-4"
              >
                Réinitialiser les paramètres du popup
              </Button>

              <Button 
                onClick={() => {
                  // Force l'affichage du popup immédiatement
                  window.dispatchEvent(new CustomEvent('forceNewsletterPopup'));
                }}
                variant="outline"
                className="w-full"
              >
                Test direct du popup (force l'affichage)
              </Button>

              <div className="text-sm text-gray-600 mt-4">
                <p>
                  <strong>Instructions :</strong>
                </p>
                <ol className="list-decimal list-inside space-y-1 mt-2">
                  <li>Cliquez sur le bouton de réinitialisation</li>
                  <li>Rechargez la page ou allez sur la page d'accueil</li>
                  <li>Attendez 30 secondes ou faites défiler vers le bas</li>
                  <li>Le popup devrait apparaître</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}