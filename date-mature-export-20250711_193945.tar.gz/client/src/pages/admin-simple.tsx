import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, Search, Edit } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function AdminSimple() {
  const [searchQuery, setSearchQuery] = useState("");
  const [regionFilter, setRegionFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const USERS_PER_PAGE = 20;
  const { toast } = useToast();

  const { data: users, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const upgradeUser = async (userId: number, subscription: string) => {
    try {
      const response = await apiRequest('POST', `/api/admin/users/${userId}/upgrade`, { subscription });
      if (response.ok) {
        toast({ title: "Utilisateur mis à jour", description: `Abonnement changé vers ${subscription}` });
        refetch();
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de mettre à jour", variant: "destructive" });
    }
  };

  const regions = [
    { value: 'occitanie', label: 'Occitanie' },
    { value: 'grand-est', label: 'Grand Est' },
    { value: 'provence', label: 'Provence-Alpes-Côte d\'Azur' },
    { value: 'auvergne-rhone-alpes', label: 'Auvergne-Rhône-Alpes' },
    { value: 'nouvelle-aquitaine', label: 'Nouvelle-Aquitaine' },
    { value: 'ile-de-france', label: 'Île-de-France' },
  ];

  const getRegionCities = (region: string) => {
    const regionMap: { [key: string]: string[] } = {
      'occitanie': ['Toulouse', 'Montpellier', 'Nîmes', 'Perpignan', 'Béziers'],
      'grand-est': ['Strasbourg', 'Metz', 'Nancy', 'Reims', 'Mulhouse'],
      'provence': ['Marseille', 'Nice', 'Toulon', 'Aix-en-Provence', 'Avignon'],
      'auvergne-rhone-alpes': ['Lyon', 'Grenoble', 'Saint-Étienne', 'Chambéry'],
      'nouvelle-aquitaine': ['Bordeaux', 'Limoges', 'Poitiers', 'La Rochelle'],
      'ile-de-france': ['Paris', 'Versailles', 'Nanterre', 'Créteil'],
    };
    return regionMap[region] || [];
  };

  const filteredUsers = users?.filter((user: any) => {
    if (!user.isTestProfile === false) return true; // Garder les vrais profils
    
    // Filtre recherche
    if (searchQuery && !user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !user.city?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filtre région
    if (regionFilter !== "all") {
      const regionCities = getRegionCities(regionFilter);
      const userCity = user.city?.toLowerCase() || "";
      const matchesRegion = regionCities.some(city => 
        userCity.includes(city.toLowerCase()) || city.toLowerCase().includes(userCity)
      );
      if (!matchesRegion) return false;
    }
    
    return true;
  }) || [];

  const totalPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE);
  const startIndex = (currentPage - 1) * USERS_PER_PAGE;
  const displayedUsers = filteredUsers.slice(startIndex, startIndex + USERS_PER_PAGE);

  if (isLoading) return <div className="p-8">Chargement...</div>;

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Admin - Recherche Profils</h1>
        <Link href="/admin">
          <Button variant="outline">Interface Complète</Button>
        </Link>
      </div>

      {/* Filtres */}
      <Card>
        <CardHeader>
          <CardTitle>Filtres de Recherche</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Input
                placeholder="Rechercher par nom ou ville..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div>
              <Select value={regionFilter} onValueChange={setRegionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les régions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes les régions</SelectItem>
                  {regions.map((region) => (
                    <SelectItem key={region.value} value={region.value}>
                      {region.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("");
                  setRegionFilter("all");
                  setCurrentPage(1);
                }}
                className="w-full"
              >
                Réinitialiser
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Résultats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Profils Trouvés ({filteredUsers.length} résultats)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {displayedUsers.map((user: any) => (
              <div key={user.id} className="border rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                    {user.photo ? (
                      <img src={user.photo} alt="" className="w-12 h-12 rounded-full object-cover" />
                    ) : (
                      <Users className="h-6 w-6" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{user.firstName}</h3>
                    <p className="text-sm text-gray-600">{user.city} • {user.age} ans</p>
                    <p className="text-xs text-gray-500">{user.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={user.gender === 'H' ? 'default' : 'secondary'}>
                    {user.gender === 'H' ? '♂️ Homme' : '♀️ Femme'}
                  </Badge>
                  <Badge variant={
                    user.subscription === 'gold' ? 'default' : 
                    user.subscription === 'premium' ? 'secondary' : 'outline'
                  }>
                    {user.subscription === 'gold' ? '👑 Gold' : 
                     user.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                  </Badge>
                  
                  <div className="flex gap-1 ml-2">
                    {user.subscription === 'gratuit' && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => upgradeUser(user.id, 'premium')}
                        className="text-xs"
                      >
                        ⭐ Premium
                      </Button>
                    )}
                    {user.subscription !== 'gold' && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => upgradeUser(user.id, 'gold')}
                        className="text-xs"
                      >
                        👑 Gold
                      </Button>
                    )}
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => {
                        const newFirstName = prompt(`Modifier le prénom de ${user.firstName}:`, user.firstName);
                        if (newFirstName && newFirstName !== user.firstName) {
                          fetch(`/api/admin/users/${user.id}`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ firstName: newFirstName })
                          }).then(() => refetch());
                        }
                      }}
                      className="text-xs px-2 py-1"
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                Précédent
              </Button>
              <span className="text-sm text-gray-600">
                Page {currentPage} sur {totalPages}
              </span>
              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                Suivant
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}