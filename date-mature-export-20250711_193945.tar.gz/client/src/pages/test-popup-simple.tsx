import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RefreshCw, Timer, MousePointer, ArrowUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function TestPopupSimple() {
  const { toast } = useToast();
  const [timeLeft, setTimeLeft] = useState(30);
  const [scrollPercent, setScrollPercent] = useState(0);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialisation différée pour simuler la logique du popup
  useEffect(() => {
    const initTimer = setTimeout(() => {
      setIsInitialized(true);
      toast({
        title: "Système initialisé",
        description: "Le popup peut maintenant être déclenché.",
      });
    }, 2000);

    return () => clearTimeout(initTimer);
  }, [toast]);

  // Timer de 30 secondes
  useEffect(() => {
    if (!isInitialized) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          toast({
            title: "Déclencheur Timer",
            description: "30 secondes écoulées ! Le popup devrait s'afficher.",
            variant: "default",
          });
          return 30; // Reset
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isInitialized, toast]);

  // Calcul du scroll
  useEffect(() => {
    const handleScroll = () => {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      setScrollPercent(scrollPercent);
      
      if (scrollPercent > 80) {
        toast({
          title: "Déclencheur Scroll",
          description: "80% de scroll atteint ! Le popup devrait s'afficher.",
          variant: "default",
        });
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [toast]);

  // Exit intent
  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0) {
        toast({
          title: "Déclencheur Exit Intent",
          description: "Mouvement vers le haut détecté ! Le popup devrait s'afficher.",
          variant: "default",
        });
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [toast]);

  const resetStates = () => {
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    
    toast({
      title: "États réinitialisés",
      description: "Tous les états ont été supprimés.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-md mx-auto pt-8">
        <Card className="border-2 border-pink-200 shadow-lg mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-xl text-gray-800">
              Test Popup - Version Simple
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Status: {isInitialized ? "✅ Initialisé" : "⏳ En cours d'initialisation..."}
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-pink-50 rounded-lg">
                <Timer className="h-5 w-5 text-pink-600" />
                <div>
                  <p className="text-sm font-medium">Timer 30s</p>
                  <p className="text-xs text-gray-600">Temps restant: {timeLeft}s</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                <MousePointer className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium">Scroll 80%</p>
                  <p className="text-xs text-gray-600">Actuel: {scrollPercent.toFixed(1)}%</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                <ArrowUp className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium">Exit Intent</p>
                  <p className="text-xs text-gray-600">Bougez la souris vers le haut</p>
                </div>
              </div>
            </div>

            <Button 
              onClick={resetStates}
              className="w-full bg-pink-600 hover:bg-pink-700 text-white"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset États
            </Button>
          </CardContent>
        </Card>

        {/* Contenu long pour tester le scroll */}
        <div className="space-y-4">
          {Array.from({ length: 20 }, (_, i) => (
            <Card key={i} className="p-4">
              <p className="text-gray-700">
                Contenu de test #{i + 1} - Scrollez vers le bas pour atteindre 80% et déclencher le popup.
              </p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}