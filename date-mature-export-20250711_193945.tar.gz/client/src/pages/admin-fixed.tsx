import { useState, useEffect } from "react";
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, Download, Edit, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import PhotoUpload from "@/components/photo-upload";

export default function AdminFixed() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [genderFilter, setGenderFilter] = useState("");
  const [ageFilter, setAgeFilter] = useState("");
  const [subscriptionFilter, setSubscriptionFilter] = useState("");
  const [regionFilter, setRegionFilter] = useState("");
  const [editingUser, setEditingUser] = useState<any>(null);
  const [previewUser, setPreviewUser] = useState<any>(null);
  const [editForm, setEditForm] = useState({
    firstName: '',
    age: '',
    city: '',
    region: '',
    bio: '',
    photo: '',
    gender: '',
    subscription: ''
  });
  const [selectedUsers, setSelectedUsers] = useState<Set<number>>(new Set());
  const [bulkEditMode, setBulkEditMode] = useState(false);
  const [bulkRegion, setBulkRegion] = useState("");
  const USERS_PER_PAGE = 10;
  const { toast } = useToast();

  // Gestion sélection multiple
  const toggleUserSelection = (userId: number) => {
    const newSelected = new Set(selectedUsers);
    if (newSelected.has(userId)) {
      newSelected.delete(userId);
    } else {
      newSelected.add(userId);
    }
    setSelectedUsers(newSelected);
  };

  const selectAllVisible = () => {
    const visibleIds = new Set(displayedUsers1.map(user => user.id));
    setSelectedUsers(visibleIds);
  };

  const clearSelection = () => {
    setSelectedUsers(new Set());
  };

  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);
  
  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/admin/users');
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsers(data.users || []);
      setStats(data.stats || {});
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({ title: "Erreur", description: "Impossible de charger les utilisateurs", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  // Charger les utilisateurs au démarrage
  useEffect(() => {
    fetchUsers();
  }, []);

  // Recharger automatiquement quand les filtres changent
  useEffect(() => {
    fetchUsers();
  }, [searchQuery, genderFilter, ageFilter, subscriptionFilter, regionFilter]);

  const refetch = fetchUsers;

  // Filtrage et tri des utilisateurs
  const realUsers = users || [];
  
  const filteredUsers = realUsers.filter(user => {
    const matchesSearch = !searchQuery || 
      user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.city?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesGender = !genderFilter || user.gender === genderFilter;
    const matchesAge = !ageFilter || user.age?.toString() === ageFilter;
    const matchesSubscription = !subscriptionFilter || user.subscription === subscriptionFilter;
    const matchesRegion = !regionFilter || user.region === regionFilter;
    
    return matchesSearch && matchesGender && matchesAge && matchesSubscription && matchesRegion;
  });

  // Tri alphabétique français
  const sortedUsers = [...filteredUsers].sort((a, b) => {
    const nameA = a.firstName || '';
    const nameB = b.firstName || '';
    return nameA.localeCompare(nameB, 'fr', { sensitivity: 'base' });
  });

  // Pagination (first instance)
  const totalPages1 = Math.ceil(sortedUsers.length / USERS_PER_PAGE);
  const startIndex1 = (currentPage - 1) * USERS_PER_PAGE;
  const displayedUsers1 = sortedUsers.slice(startIndex1, startIndex1 + USERS_PER_PAGE);

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Erreur", description: "La photo doit faire moins de 5MB", variant: "destructive" });
      return;
    }

    const formData = new FormData();
    formData.append('photo', file);

    try {
      toast({ title: "Téléchargement en cours..." });
      
      const response = await fetch('/api/upload/photo', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();
      
      if (response.ok && result.photoUrl) {
        setEditForm({...editForm, photo: result.photoUrl});
        toast({ title: "Photo téléchargée avec succès" });
      } else {
        console.error('Upload error:', result);
        toast({ title: "Erreur", description: result.message || "Impossible de télécharger la photo", variant: "destructive" });
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({ title: "Erreur", description: "Erreur réseau lors du téléchargement", variant: "destructive" });
    }
    
    // Reset le champ file pour permettre de reuploader la même photo
    event.target.value = '';
  };

  const downloadBackup = async () => {
    try {
      const response = await fetch("/api/admin/backup");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast({ title: "Backup téléchargé avec succès" });
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de télécharger le backup", variant: "destructive" });
    }
  };

  const openEditModal = (user: any) => {
    console.log('Opening edit modal for user:', user.id, user.firstName);
    setEditingUser(user);
    setEditForm({
      firstName: user.firstName || '',
      age: user.age?.toString() || '',
      city: user.city || '',
      region: user.region || '',
      bio: user.bio || '',
      photo: user.photo || '',
      gender: user.gender || '',
      subscription: user.subscription || ''
    });
  };

  const saveUserChanges = async () => {
    if (!editingUser) return;
    
    const updates: any = {};
    
    if (editForm.firstName !== editingUser.firstName) {
      updates.firstName = editForm.firstName;
    }
    if (editForm.age && parseInt(editForm.age) !== editingUser.age) {
      updates.age = parseInt(editForm.age);
    }
    if (editForm.city !== editingUser.city) {
      updates.city = editForm.city;
    }
    if (editForm.region && editForm.region !== editingUser.region) {
      updates.region = editForm.region;
    }
    if (editForm.bio !== editingUser.bio) {
      updates.bio = editForm.bio;
    }
    if (editForm.photo !== editingUser.photo) {
      updates.photo = editForm.photo;
    }
    if (editForm.gender !== editingUser.gender) {
      updates.gender = editForm.gender;
    }
    if (editForm.subscription !== editingUser.subscription) {
      updates.subscription = editForm.subscription;
    }
    
    if (Object.keys(updates).length > 0) {
      try {
        console.log('Updating user ID:', editingUser.id, 'with updates:', updates);
        const response = await fetch(`/api/admin/users/${editingUser.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
        if (response.ok) {
          toast({ title: "Profil mis à jour", description: `${Object.keys(updates).length} champ(s) modifié(s)` });
          setEditingUser(null);
          refetch();
        } else {
          const errorData = await response.json();
          console.error('Error updating user:', errorData);
          toast({ title: "Erreur", description: errorData.message || "Impossible de sauvegarder", variant: "destructive" });
        }
      } catch (error) {
        toast({ title: "Erreur", description: "Impossible de sauvegarder", variant: "destructive" });
      }
    } else {
      setEditingUser(null);
    }
  };

  // Gestionnaire global pour touche S
  React.useEffect(() => {
    const handleGlobalKeyPress = (e: KeyboardEvent) => {
      // Touche 's' uniquement si on édite un utilisateur et pas dans un input
      if (e.key === 's' && editingUser && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement)) {
        e.preventDefault();
        saveUserChanges();
      }
    };

    document.addEventListener('keydown', handleGlobalKeyPress);
    return () => document.removeEventListener('keydown', handleGlobalKeyPress);
  }, [editingUser, editForm]);

  // Sauvegarde en lot
  const saveBulkChanges = async (field: string, value: string) => {
    if (selectedUsers.size === 0) {
      toast({
        title: "Aucune sélection",
        description: "Veuillez d'abord sélectionner des profils à modifier",
        variant: "destructive",
      });
      return;
    }
    
    const selectedCount = selectedUsers.size;
    const fieldLabel = field === 'gender' ? 'Genre' : field === 'region' ? 'Région' : 'Abonnement';
    
    // Afficher un message de progression
    toast({
      title: `Modification en cours...`,
      description: `Mise à jour de ${selectedCount} profil(s) - ${fieldLabel}: ${value}`,
    });
    
    try {
      let successCount = 0;
      let errorCount = 0;
      
      // Traiter chaque utilisateur
      for (const userId of Array.from(selectedUsers)) {
        const user = allUsers.find(u => u.id === userId);
        if (!user) {
          errorCount++;
          continue;
        }
        
        const updateData = { [field]: value };
        
        try {
          const response = await fetch(`/api/admin/users/${userId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
          });
          
          if (response.ok) {
            successCount++;
          } else {
            errorCount++;
          }
        } catch (error) {
          errorCount++;
        }
      }
      
      // Afficher le résultat
      if (successCount > 0) {
        toast({
          title: `✅ Modifications terminées`,
          description: `${successCount} profil(s) mis à jour avec succès ${errorCount > 0 ? `(${errorCount} erreurs)` : ''}`,
        });
      } else {
        toast({
          title: "Erreur",
          description: "Aucune modification n'a pu être effectuée",
          variant: "destructive",
        });
      }
      
      clearSelection();
      setBulkEditMode(false);
      
      // Recharger la page pour voir les changements
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Erreur lors de la modification en lot",
        variant: "destructive",
      });
    }
  };

  // Suppression en lot
  const deleteBulkUsers = async () => {
    if (selectedUsers.size === 0) {
      toast({
        title: "Aucune sélection",
        description: "Veuillez d'abord sélectionner des profils à supprimer",
        variant: "destructive",
      });
      return;
    }

    const selectedCount = selectedUsers.size;
    const selectedUserNames = Array.from(selectedUsers)
      .map(id => realUsers.find(u => u.id === id)?.firstName)
      .filter(Boolean)
      .slice(0, 10); // Montrer les 10 premiers noms

    // Demander confirmation
    const confirmMessage = `Êtes-vous sûr de vouloir supprimer ${selectedCount} profil(s) ?\n\nPremiers profils sélectionnés :\n${selectedUserNames.join(', ')}${selectedCount > 10 ? '\n...' : ''}`;
    
    if (!confirm(confirmMessage)) {
      return;
    }

    // Afficher un message de progression
    toast({
      title: `Suppression en cours...`,
      description: `Suppression de ${selectedCount} profil(s)...`,
    });

    try {
      let successCount = 0;
      let errorCount = 0;

      // Traiter chaque utilisateur
      for (const userId of Array.from(selectedUsers)) {
        try {
          const response = await fetch(`/api/admin/users/${userId}`, {
            method: 'DELETE'
          });

          if (response.ok) {
            successCount++;
          } else {
            errorCount++;
          }
        } catch (error) {
          errorCount++;
        }
      }

      // Afficher le résultat
      if (successCount > 0) {
        toast({
          title: `✅ Suppression terminée`,
          description: `${successCount} profil(s) supprimé(s) avec succès ${errorCount > 0 ? `(${errorCount} erreurs)` : ''}`,
        });
      } else {
        toast({
          title: "Erreur",
          description: "Aucune suppression n'a pu être effectuée",
          variant: "destructive",
        });
      }

      clearSelection();
      setBulkEditMode(false);

      // Recharger la page pour voir les changements
      setTimeout(() => {
        window.location.reload();
      }, 1000);

    } catch (error) {
      toast({
        title: "Erreur",
        description: "Erreur lors de la suppression en lot",
        variant: "destructive",
      });
    }
  };

  const handleInputKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      saveUserChanges();
    }
  };

  const deleteUser = async (userId: number, firstName: string) => {
    if (!confirm(`Êtes-vous sûr de vouloir supprimer le profil de ${firstName} ?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
      });
      
      const result = await response.json();
      
      if (response.ok) {
        toast({ title: "Profil supprimé", description: `${firstName} a été supprimé avec succès` });
        refetch();
      } else {
        toast({ title: "Erreur", description: result.message || "Impossible de supprimer le profil", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Erreur lors de la suppression", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!users) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Erreur de chargement</h2>
          <p className="text-gray-600">Impossible de charger les données</p>
        </div>
      </div>
    );
  }

  const allUsers = (users as any[]) || [];
  
  // Filtrage par recherche et filtres  
  let secondaryFilteredUsers = allUsers;
  if (searchQuery.trim()) {
    const query = searchQuery.toLowerCase().trim();
    secondaryFilteredUsers = secondaryFilteredUsers.filter((user: any) =>
      user.firstName?.toLowerCase().includes(query) ||
      user.email?.toLowerCase().includes(query) ||
      user.city?.toLowerCase().includes(query) ||
      user.region?.toLowerCase().includes(query) ||
      user.bio?.toLowerCase().includes(query)
    );
  }
  if (genderFilter) {
    secondaryFilteredUsers = secondaryFilteredUsers.filter((user: any) => user.gender === genderFilter);
  }
  if (subscriptionFilter) {
    secondaryFilteredUsers = secondaryFilteredUsers.filter((user: any) => user.subscription === subscriptionFilter);
  }
  if (ageFilter) {
    const [minAge, maxAge] = ageFilter.split('-').map(Number);
    secondaryFilteredUsers = secondaryFilteredUsers.filter((user: any) => user.age >= minAge && user.age <= maxAge);
  }
  if (regionFilter) {
    secondaryFilteredUsers = secondaryFilteredUsers.filter((user: any) => {
      const userRegion = user.region || user.city;
      return userRegion?.toLowerCase().includes(regionFilter.toLowerCase());
    });
  }
  
  // Tri alphabétique par prénom
  secondaryFilteredUsers = secondaryFilteredUsers.sort((a: any, b: any) => a.firstName.localeCompare(b.firstName, 'fr', { sensitivity: 'base' }));

  // Pagination
  const totalPages = Math.ceil(secondaryFilteredUsers.length / USERS_PER_PAGE);
  const startIndex = (currentPage - 1) * USERS_PER_PAGE;
  const displayedUsers = secondaryFilteredUsers.slice(startIndex, startIndex + USERS_PER_PAGE);

  const premiumCount = allUsers.filter(u => u.subscription === 'premium').length;
  const goldCount = allUsers.filter(u => u.subscription === 'gold').length;

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Administration Date Mature</h1>
          <p className="text-gray-600">Gestion des utilisateurs et abonnements</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Utilisateurs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{realUsers.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Premium</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{premiumCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Gold</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{goldCount}</div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mb-6 flex gap-2">
          <Button
            onClick={() => setBulkEditMode(!bulkEditMode)}
            variant={bulkEditMode ? "default" : "outline"}
          >
            <Edit className="h-4 w-4 mr-2" />
            {bulkEditMode ? "Annuler sélection" : "Sélection multiple"}
          </Button>
          <Button onClick={downloadBackup} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Télécharger Backup
          </Button>
        </div>

        {/* Recherche et filtres */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Recherche et filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Input
                  placeholder="Rechercher par nom, ville, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setGenderFilter("");
                    setAgeFilter("");
                    setSubscriptionFilter("");
                    setRegionFilter("");
                    setCurrentPage(1);
                  }}
                >
                  Réinitialiser
                </Button>
              </div>
              
              <div className="flex gap-4">
                <select
                  value={genderFilter}
                  onChange={(e) => { setGenderFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les genres</option>
                  <option value="H">Hommes</option>
                  <option value="F">Femmes</option>
                </select>
                
                <select
                  value={ageFilter}
                  onChange={(e) => { setAgeFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les âges</option>
                  <option value="40-50">40-50 ans</option>
                  <option value="51-60">51-60 ans</option>
                  <option value="61-75">61-75 ans</option>
                </select>
                
                <select
                  value={subscriptionFilter}
                  onChange={(e) => { setSubscriptionFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Tous les abonnements</option>
                  <option value="gratuit">Gratuit</option>
                  <option value="premium">Premium</option>
                  <option value="gold">Gold</option>
                </select>
                
                <select
                  value={regionFilter}
                  onChange={(e) => { setRegionFilter(e.target.value); setCurrentPage(1); }}
                  className="px-3 py-2 border rounded"
                >
                  <option value="">Toutes les régions</option>
                  <option value="Île-de-France">Île-de-France</option>
                  <option value="Provence-Alpes-Côte d'Azur">PACA</option>
                  <option value="Auvergne-Rhône-Alpes">Auvergne-Rhône-Alpes</option>
                  <option value="Occitanie">Occitanie</option>
                  <option value="Nouvelle-Aquitaine">Nouvelle-Aquitaine</option>
                  <option value="Hauts-de-France">Hauts-de-France</option>
                  <option value="Grand Est">Grand Est</option>
                  <option value="Pays de la Loire">Pays de la Loire</option>
                  <option value="Bretagne">Bretagne</option>
                  <option value="Normandie">Normandie</option>
                  <option value="Bourgogne-Franche-Comté">Bourgogne-Franche-Comté</option>
                  <option value="Centre-Val de Loire">Centre-Val de Loire</option>
                  <option value="Corse">Corse</option>
                </select>
                

              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Utilisateurs ({sortedUsers.length} résultats)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {bulkEditMode && selectedUsers.size > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <h3 className="font-medium text-blue-900 mb-3">
                    Modification en lot - {selectedUsers.size} profil(s) sélectionné(s)
                  </h3>
                  <div className="w-full">
                    <div className="flex justify-between items-center w-full text-sm">
                      <div className="flex gap-2 items-center">
                        <span className="font-semibold text-base">Genre:</span>
                        <Button 
                          size="sm" 
                          className="h-8 px-3 text-sm bg-blue-600 hover:bg-blue-700"
                          onClick={() => {
                            if (selectedUsers.size > 0) {
                              saveBulkChanges('gender', 'H');
                            }
                          }}
                        >
                          👨 H
                        </Button>
                        <Button 
                          size="sm" 
                          className="h-8 px-3 text-sm bg-pink-600 hover:bg-pink-700"
                          onClick={() => {
                            if (selectedUsers.size > 0) {
                              saveBulkChanges('gender', 'F');
                            }
                          }}
                        >
                          👩 F
                        </Button>
                      </div>
                      
                      <div className="flex gap-2 items-center">
                        <span className="font-semibold text-base">Région:</span>
                        <select
                          value={bulkRegion}
                          onChange={(e) => setBulkRegion(e.target.value)}
                          className="h-8 px-3 border rounded text-sm w-40"
                        >
                          <option value="">Choisir...</option>
                          <option value="Île-de-France">Île-de-France</option>
                          <option value="Provence-Alpes-Côte d'Azur">PACA</option>
                          <option value="Auvergne-Rhône-Alpes">Auvergne-Rhône-Alpes</option>
                          <option value="Occitanie">Occitanie</option>
                          <option value="Nouvelle-Aquitaine">Nouvelle-Aquitaine</option>
                          <option value="Hauts-de-France">Hauts-de-France</option>
                          <option value="Grand Est">Grand Est</option>
                          <option value="Pays de la Loire">Pays de la Loire</option>
                          <option value="Bretagne">Bretagne</option>
                          <option value="Normandie">Normandie</option>
                          <option value="Bourgogne-Franche-Comté">Bourgogne-Franche-Comté</option>
                          <option value="Centre-Val de Loire">Centre-Val de Loire</option>
                          <option value="Corse">Corse</option>
                        </select>
                        <Button 
                          size="sm" 
                          disabled={!bulkRegion || selectedUsers.size === 0}
                          onClick={() => {
                            if (bulkRegion && selectedUsers.size > 0) {
                              saveBulkChanges('region', bulkRegion);
                            }
                          }}
                          className="h-8 px-3 text-sm bg-green-600 hover:bg-green-700"
                        >
                          📍 OK
                        </Button>
                      </div>
                      
                      <div className="flex gap-2 items-center">
                        <span className="font-semibold text-base">Abonnement:</span>
                        <Button size="sm" className="h-8 px-3 text-sm bg-orange-600 hover:bg-orange-700" onClick={() => saveBulkChanges('subscription', 'premium')}>⭐ Premium</Button>
                        <Button size="sm" className="h-8 px-3 text-sm bg-yellow-600 hover:bg-yellow-700" onClick={() => saveBulkChanges('subscription', 'gold')}>👑 Gold</Button>
                        <Button size="sm" className="h-8 px-3 text-sm" variant="outline" onClick={() => saveBulkChanges('subscription', 'gratuit')}>🆓 Gratuit</Button>
                      </div>
                      
                      <Button 
                        size="sm" 
                        className="h-8 px-3 text-sm bg-red-600 hover:bg-red-700 text-white" 
                        onClick={deleteBulkUsers}
                        disabled={selectedUsers.size === 0}
                      >
                        🗑️ Supprimer ({selectedUsers.size})
                      </Button>
                      
                      <Button size="sm" className="h-8 px-3 text-sm" variant="outline" onClick={clearSelection}>
                        ❌ Annuler
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              {bulkEditMode && (
                <div className="flex gap-2 mb-4">
                  <Button size="sm" variant="outline" onClick={selectAllVisible}>
                    Sélectionner page ({displayedUsers1.length})
                  </Button>
                  <Button size="sm" variant="outline" onClick={clearSelection}>
                    Tout désélectionner
                  </Button>
                </div>
              )}
              
              {displayedUsers1.map((user: any) => (
                <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {bulkEditMode && (
                      <input
                        type="checkbox"
                        checked={selectedUsers.has(user.id)}
                        onChange={() => toggleUserSelection(user.id)}
                        className="w-4 h-4"
                      />
                    )}
                    <div 
                      className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 cursor-pointer hover:ring-2 hover:ring-pink-300 transition-all"
                      onClick={() => setPreviewUser(user)}
                      title="Cliquer pour voir le profil complet"
                    >
                      <img 
                        src={user.photo || '/placeholder.jpg'} 
                        alt={user.firstName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{user.firstName}</p>
                      <p className="text-sm text-gray-600">{user.city} • {user.age} ans</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={user.gender === 'H' ? 'default' : 'secondary'}>
                      {user.gender === 'H' ? '♂️' : '♀️'}
                    </Badge>
                    
                    <Badge variant={
                      user.subscription === 'gold' ? 'default' : 
                      user.subscription === 'premium' ? 'secondary' : 'outline'
                    }>
                      {user.subscription === 'gold' ? '👑 Gold' : 
                       user.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                    </Badge>
                    
                    <Button size="sm" variant="ghost" onClick={() => openEditModal(user)}>
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => deleteUser(user.id, user.firstName)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} sur {totalPages1}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages1, currentPage + 1))}
                  disabled={currentPage === totalPages1}
                >
                  Suivant
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal d'édition */}
      {editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Modifier le profil de {editingUser.firstName}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Prénom</label>
                <input
                  type="text"
                  value={editForm.firstName}
                  onChange={(e) => setEditForm({...editForm, firstName: e.target.value})}
                  onKeyDown={handleInputKeyDown}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Âge</label>
                <input
                  type="number"
                  min="40"
                  max="75"
                  value={editForm.age}
                  onChange={(e) => setEditForm({...editForm, age: e.target.value})}
                  onKeyDown={handleInputKeyDown}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Ville</label>
                <input
                  type="text"
                  value={editForm.city}
                  onChange={(e) => setEditForm({...editForm, city: e.target.value})}
                  onKeyDown={handleInputKeyDown}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Région</label>
                <select
                  value={editForm.region}
                  onChange={(e) => setEditForm({...editForm, region: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="">Choisir une région</option>
                  <option value="Île-de-France">Île-de-France</option>
                  <option value="Provence-Alpes-Côte d'Azur">PACA</option>
                  <option value="Auvergne-Rhône-Alpes">Auvergne-Rhône-Alpes</option>
                  <option value="Occitanie">Occitanie</option>
                  <option value="Nouvelle-Aquitaine">Nouvelle-Aquitaine</option>
                  <option value="Hauts-de-France">Hauts-de-France</option>
                  <option value="Grand Est">Grand Est</option>
                  <option value="Pays de la Loire">Pays de la Loire</option>
                  <option value="Bretagne">Bretagne</option>
                  <option value="Normandie">Normandie</option>
                  <option value="Bourgogne-Franche-Comté">Bourgogne-Franche-Comté</option>
                  <option value="Centre-Val de Loire">Centre-Val de Loire</option>
                  <option value="Corse">Corse</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Genre</label>
                <select
                  value={editForm.gender}
                  onChange={(e) => setEditForm({...editForm, gender: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="H">Homme</option>
                  <option value="F">Femme</option>
                </select>
              </div>
              
              <div className="md:col-span-3">
                <label className="block text-sm font-medium mb-1">Bio</label>
                <textarea
                  value={editForm.bio}
                  onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                  onKeyDown={handleInputKeyDown}
                  className="w-full p-2 border rounded h-20"
                  placeholder="Shift+Entrée pour nouvelle ligne, Entrée pour sauvegarder"
                />
              </div>
              
              <div className="md:col-span-3">
                <label className="block text-sm font-medium mb-1">Photo</label>
                <div className="space-y-3">
                  <input
                    type="url"
                    value={editForm.photo}
                    onChange={(e) => setEditForm({...editForm, photo: e.target.value})}
                    onKeyDown={handleInputKeyDown}
                    className="w-full p-2 border rounded"
                    placeholder="URL de la photo (https://...)"
                  />
                  <div className="text-sm text-gray-500 text-center">ou</div>
                  <PhotoUpload
                    currentPhoto={editForm.photo}
                    onPhotoSelected={(photoUrl) => setEditForm({...editForm, photo: photoUrl})}
                    className="max-w-sm"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Abonnement</label>
                <select
                  value={editForm.subscription}
                  onChange={(e) => setEditForm({...editForm, subscription: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="gratuit">🆓 Gratuit</option>
                  <option value="premium">⭐ Premium</option>
                  <option value="gold">👑 Gold</option>
                </select>
              </div>
            </div>
            
            <div className="flex gap-2 mt-6">
              <Button onClick={saveUserChanges} className="flex-1">
                Sauvegarder
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setEditingUser(null)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button 
                variant="destructive" 
                onClick={() => {
                  deleteUser(editingUser.id, editingUser.firstName);
                  setEditingUser(null);
                }}
                className="px-4"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de prévisualisation du profil */}
      {previewUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="text-center">
              <div className="w-32 h-32 mx-auto rounded-full overflow-hidden bg-gray-200 mb-4">
                <img 
                  src={previewUser.photo || '/placeholder.jpg'} 
                  alt={previewUser.firstName}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <h2 className="text-2xl font-bold mb-2">{previewUser.firstName}</h2>
              
              <div className="flex justify-center gap-2 mb-4">
                <Badge variant={previewUser.gender === 'H' ? 'default' : 'secondary'}>
                  {previewUser.gender === 'H' ? '♂️ Homme' : '♀️ Femme'}
                </Badge>
                <Badge variant={
                  previewUser.subscription === 'gold' ? 'default' : 
                  previewUser.subscription === 'premium' ? 'secondary' : 'outline'
                }>
                  {previewUser.subscription === 'gold' ? '👑 Gold' : 
                   previewUser.subscription === 'premium' ? '⭐ Premium' : '🆓 Gratuit'}
                </Badge>
              </div>
              
              <div className="text-left space-y-3 mb-6">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Âge:</span>
                  <span>{previewUser.age} ans</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="font-medium">Ville:</span>
                  <span>{previewUser.city}</span>
                </div>
                
                {previewUser.region && (
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Région:</span>
                    <span>{previewUser.region}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-2">
                  <span className="font-medium">Email:</span>
                  <span className="text-sm">{previewUser.email}</span>
                </div>
                
                {previewUser.bio && (
                  <div>
                    <span className="font-medium block mb-1">Bio:</span>
                    <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">
                      {previewUser.bio}
                    </p>
                  </div>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setPreviewUser(null)}
                  className="flex-1"
                >
                  Fermer
                </Button>
                <Button 
                  onClick={() => {
                    setPreviewUser(null);
                    openEditModal(previewUser);
                  }}
                  className="flex-1"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Modifier
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}