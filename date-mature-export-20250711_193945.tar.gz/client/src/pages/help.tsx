import { ChevronDown, ChevronRight, Heart, Shield, Users, MessageCircle, CreditCard, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

export default function Help() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const helpContent = {
    "premiers-pas": {
      title: "Premiers pas",
      icon: Heart,
      sections: [
        {
          question: "Comment créer un profil attractif",
          answer: "Un profil attractif commence par une photo de qualité où vous souriez naturellement. Complétez toutes les sections : bio personnelle, centres d'intérêt et informations de base. Soyez authentique et positif dans votre présentation."
        },
        {
          question: "Choisir ses meilleures photos",
          answer: "Utilisez des photos récentes (moins de 2 ans) où vous apparaissez clairement. Privilégiez les photos en extérieur avec un bon éclairage naturel. Évitez les selfies trop proches et incluez une photo en pied pour donner une image complète."
        },
        {
          question: "Rédiger une bio qui vous ressemble",
          answer: "Votre bio doit refléter votre personnalité en 2-3 phrases. Mentionnez vos passions, ce que vous recherchez et ce qui vous rend unique. Restez positif et évitez les listes négatives de ce que vous ne voulez pas."
        },
        {
          question: "Sélectionner ses centres d'intérêt",
          answer: "Choisissez 5-8 centres d'intérêt qui vous représentent vraiment. Variez entre loisirs, activités culturelles et sportives. Cela aide à trouver des points communs avec d'autres membres et facilite les conversations."
        }
      ]
    },
    "systeme-flash": {
      title: "Système de Flash",
      icon: Users,
      sections: [
        {
          question: "Qu'est-ce qu'un Flash ?",
          answer: "Un Flash est l'équivalent d'un 'J'aime' sur notre plateforme. C'est une façon de montrer votre intérêt pour le profil d'une personne. Si cette personne vous flashe en retour, vous créez un 'match' et pouvez commencer à discuter."
        },
        {
          question: "Comment flasher un profil",
          answer: "Sur la page de profils, appuyez sur le cœur rose ou balayez vers la droite. Le flash est envoyé instantanément. Vous recevrez une notification si la personne vous flashe en retour pour créer un match."
        },
        {
          question: "Limites quotidiennes par abonnement",
          answer: "Compte Gratuit : 3 flashs par jour • Compte Premium : 20 flashs par jour • Compte Gold : Flashs illimités. Les limites se renouvellent chaque jour à minuit."
        },
        {
          question: "Que faire après un match mutuel",
          answer: "Félicitations ! Après un match, rendez-vous dans votre section 'Messages' pour commencer une conversation. Envoyez un message personnalisé en vous basant sur le profil de la personne pour briser la glace."
        }
      ]
    },
    "messagerie": {
      title: "Messagerie",
      icon: MessageCircle,
      sections: [
        {
          question: "Envoyer votre premier message",
          answer: "Personnalisez votre premier message en vous référant à quelque chose du profil de la personne. Posez une question ouverte pour encourager la conversation. Évitez les 'Salut' génériques - soyez créatif et authentique."
        },
        {
          question: "Conseils pour bien communiquer",
          answer: "Soyez respectueux et patient. Posez des questions sur les centres d'intérêt communs. Partagez des expériences personnelles. Évitez les sujets controversés au début. Proposez un appel ou une rencontre quand vous vous sentez à l'aise."
        },
        {
          question: "Signaler un comportement inapproprié",
          answer: "Si quelqu'un vous envoie des messages déplacés, utilisez le bouton 'Signaler' dans la conversation. Notre équipe examine tous les signalements dans les 24h. Vous pouvez aussi bloquer immédiatement la personne."
        },
        {
          question: "Bloquer un utilisateur",
          answer: "Dans une conversation, appuyez sur les trois points en haut à droite, puis 'Bloquer'. La personne ne pourra plus vous contacter ni voir votre profil. Cette action est définitive et confidentielle."
        }
      ]
    },
    "abonnements": {
      title: "Abonnements",
      icon: CreditCard,
      sections: [
        {
          question: "Avantages Premium vs Gold",
          answer: "Premium (60€/6 mois) : 20 flashs/jour, voir qui vous a flashé, support prioritaire. Gold (114€/12 mois) : Flashs illimités, profil mis en avant, mode incognito, badges exclusifs, support VIP."
        },
        {
          question: "Comment souscrire un abonnement",
          answer: "Allez dans 'Paramètres' puis 'Abonnement'. Choisissez votre formule et suivez les étapes de paiement sécurisé via Stripe. Votre abonnement est activé immédiatement après validation du paiement."
        },
        {
          question: "Gérer votre abonnement",
          answer: "Votre abonnement se renouvelle automatiquement. Pour le modifier ou l'annuler, allez dans 'Paramètres' > 'Abonnement'. Vous gardez vos avantages jusqu'à la fin de la période payée."
        },
        {
          question: "Questions de facturation",
          answer: "Les paiements sont sécurisés par Stripe. Vous recevez un reçu par email. Pour toute question sur votre facture, contactez notre support client qui vous répondra sous 24h."
        }
      ]
    },
    "securite": {
      title: "Sécurité",
      icon: Shield,
      sections: [
        {
          question: "Protéger ses informations personnelles",
          answer: "Ne partagez jamais votre adresse, numéro de téléphone ou informations bancaires dans les messages. Utilisez la messagerie interne jusqu'à ce que vous connaissiez bien la personne. Méfiez-vous des demandes d'argent."
        },
        {
          question: "Reconnaître les profils suspects",
          answer: "Méfiez-vous des profils avec très peu de photos, des histoires incohérentes, ou qui évitent les appels vidéo. Les vrais profils ont des photos variées et des descriptions détaillées. Signalez tout comportement suspect."
        },
        {
          question: "Conseils pour un premier rendez-vous",
          answer: "Rencontrez-vous dans un lieu public et fréquenté. Prévenez un proche de votre sortie. Venez avec votre propre moyen de transport. Restez sobre et faites confiance à votre instinct. N'hésitez pas à partir si vous ne vous sentez pas à l'aise."
        },
        {
          question: "Signaler un problème",
          answer: "Utilisez le bouton 'Signaler' sur tout profil ou message problématique. Pour les urgences, contactez directement les autorités. Notre équipe de modération examine tous les signalements et prend les mesures appropriées."
        }
      ]
    }
  };

  const toggleSection = (sectionId: string) => {
    setExpandedSection(expandedSection === sectionId ? null : sectionId);
  };

  return (
    <>
      <SiteHeader />
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Centre d'aide</h1>
          <p className="text-lg text-gray-600">
            Nous sommes là pour vous accompagner dans votre recherche de l'amour
          </p>
        </div>

        {/* Help Sections */}
        <div className="grid gap-6">
          {Object.entries(helpContent).map(([sectionId, section]) => {
            const Icon = section.icon;
            const isExpanded = expandedSection === sectionId;
            
            return (
              <Card key={sectionId} className="hover:shadow-lg transition-shadow">
                <CardHeader 
                  className="pb-4 cursor-pointer"
                  onClick={() => toggleSection(sectionId)}
                >
                  <CardTitle className="flex items-center justify-between text-xl">
                    <div className="flex items-center">
                      <Icon className="h-6 w-6 text-rose-500 mr-3" />
                      {section.title}
                    </div>
                    {isExpanded ? (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    )}
                  </CardTitle>
                </CardHeader>
                
                {isExpanded && (
                  <CardContent>
                    <div className="space-y-4">
                      {section.sections.map((item, itemIndex) => (
                        <div key={itemIndex} className="border-l-4 border-rose-200 pl-4">
                          <h4 className="font-semibold text-gray-900 mb-2">{item.question}</h4>
                          <p className="text-gray-700 leading-relaxed">{item.answer}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        {/* Contact Section */}
        <Card className="bg-rose-50 border-rose-200">
          <CardHeader>
            <CardTitle className="flex items-center text-xl text-rose-800">
              <Phone className="h-6 w-6 mr-3" />
              Besoin d'aide personnalisée ?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-rose-700 mb-4">
              Notre équipe support est disponible pour vous aider du lundi au vendredi de 9h à 18h.
            </p>
            <div className="space-y-2">
              <p className="text-rose-800 font-medium">📧 Email : contact@date-mature.com</p>
            </div>
          </CardContent>
        </Card>
        </div>
      </div>
      <SiteFooter />
    </>
  );
}