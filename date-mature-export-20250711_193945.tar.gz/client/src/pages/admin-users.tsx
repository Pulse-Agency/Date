import { useQuery, useMutation } from "@tanstack/react-query";
import { Shield, Users, Crown, Mail, MapPin, Calendar, ArrowLeft, Plus, UserX, Edit, Search, Upload, Download } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import PhotoUpload from "@/components/photo-upload";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  gender: "H" | "F";
  age: number;
  city: string;
  subscription: string;
  bio?: string;
  photo?: string;
  isTestProfile?: boolean;
}

export default function AdminUsers() {
  const { toast } = useToast();
  const [location] = useLocation();
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilters, setGenderFilters] = useState({ H: false, F: false });
  const [citySearch, setCitySearch] = useState('');
  const [subscriptionFilters, setSubscriptionFilters] = useState({ gratuit: false, premium: false, gold: false });
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [isImporting, setIsImporting] = useState(false);
  const [isImportingPhotos, setIsImportingPhotos] = useState(false);
  const [isImportingDirect, setIsImportingDirect] = useState(false);

  // Appliquer les filtres automatiquement selon les paramètres d'URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const subscription = urlParams.get('subscription');
    
    // Réinitialiser tous les filtres d'abonnement d'abord
    if (subscription === 'premium') {
      setSubscriptionFilters({ gratuit: false, premium: true, gold: false });
    } else if (subscription === 'gold') {
      setSubscriptionFilters({ gratuit: false, premium: false, gold: true });
    } else if (subscription === null) {
      // Si pas de paramètre subscription, montrer tous les abonnements
      setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
    }
    
    // Réinitialiser la page à 1 quand on change de filtre
    setCurrentPage(1);
  }, [location]);
  const [newUser, setNewUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    age: 50,
    city: '',
    subscription: 'gratuit',
    bio: '',
    photo: '',
    isTestProfile: true
  });

  const { data: usersData, isLoading } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const users = (usersData as User[]) || [];

  // Filter users based on search terms and filters
  const filteredUsers = users.filter(user => {
    // Filter by search term in firstName only
    const matchesSearch = user.firstName.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by city search
    const matchesCity = user.city.toLowerCase().includes(citySearch.toLowerCase());
    
    // Filter by gender - if no gender is selected, show all
    const selectedGenders = Object.keys(genderFilters).filter(gender => genderFilters[gender as "H" | "F"]);
    const matchesGender = selectedGenders.length === 0 || selectedGenders.includes(user.gender);
    
    // Filter by subscription - if no subscription is selected, show all
    const selectedSubscriptions = Object.keys(subscriptionFilters).filter(sub => subscriptionFilters[sub as "gratuit" | "premium" | "gold"]);
    const matchesSubscription = selectedSubscriptions.length === 0 || selectedSubscriptions.includes(user.subscription);
    
    // Debug log pour comprendre le problème
    if (selectedSubscriptions.length > 0) {
      console.log('Filtres actifs:', selectedSubscriptions, 'Subscription utilisateur:', user.subscription);
    }
    
    return matchesSearch && matchesCity && matchesGender && matchesSubscription;
  });

  // Calculate pagination
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
  const startIndex = (currentPage - 1) * usersPerPage;
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + usersPerPage);

  // Add user mutation
  const addUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const response = await apiRequest("POST", "/api/auth/register", userData);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la création");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Utilisateur créé",
        description: "Le profil a été ajouté avec succès",
      });
      setShowAddUser(false);
      setNewUser({
        firstName: '',
        lastName: '',
        email: '',
        age: 50,
        city: '',
        subscription: 'gratuit',
        bio: '',
        photo: '',
        isTestProfile: true
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de créer l'utilisateur",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.firstName || !newUser.email) {
      toast({
        title: "Erreur",
        description: "Nom et email requis",
        variant: "destructive",
      });
      return;
    }
    addUserMutation.mutate(newUser);
  };

  const handleExcelImport = async (e: any) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsImporting(true);
    
    try {
      const formData = new FormData();
      formData.append('excel', file);
      
      const response = await fetch('/api/import/excel', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (response.ok) {
        toast({
          title: "Import réussi !",
          description: `${result.imported} profils importés (${result.errors} erreurs)`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      } else {
        toast({
          title: "Erreur d'import",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible d'importer le fichier Excel",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  const handlePhotosZipImport = async (e: any) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsImportingPhotos(true);
    
    try {
      const formData = new FormData();
      formData.append('photos', file);
      
      const response = await fetch('/api/import/photos-zip', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (response.ok) {
        toast({
          title: "Photos importées !",
          description: `${result.extractedPhotos} photos extraites avec succès`,
        });
      } else {
        toast({
          title: "Erreur d'import photos",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible d'importer le fichier ZIP de photos",
        variant: "destructive",
      });
    } finally {
      setIsImportingPhotos(false);
    }
  };

  const handleDirectImport = async () => {
    setIsImportingDirect(true);
    
    try {
      const response = await fetch('/api/import/direct-excel', {
        method: 'POST'
      });
      
      const result = await response.json();
      
      if (response.ok) {
        toast({
          title: "Import des profils réussi !",
          description: `${result.imported} profils importés (${result.errors} erreurs)`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      } else {
        toast({
          title: "Erreur d'import",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible d'importer les profils",
        variant: "destructive",
      });
    } finally {
      setIsImportingDirect(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-gray-800 text-white p-6 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white hover:bg-gray-700 mr-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
          </Link>
          <Shield className="h-6 w-6 mr-3" />
          <h2 className="text-xl font-semibold">Gestion des Utilisateurs ({users.length})</h2>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={async () => {
              try {
                const response = await fetch('/api/admin/identify-genders', { method: 'POST' });
                const data = await response.json();
                if (response.ok) {
                  queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
                  toast({ 
                    title: "Identification terminée", 
                    description: `${data.updatedCount} profils mis à jour`
                  });
                } else {
                  toast({ title: "Erreur", description: data.message, variant: "destructive" });
                }
              } catch (error) {
                toast({ title: "Erreur", description: "Impossible d'identifier les genres", variant: "destructive" });
              }
            }}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Users className="h-4 w-4 mr-2" />
            Identifier H/F
          </Button>
          <Button 
            onClick={async () => {
              try {
                const response = await fetch('/api/upgrade-to-premium', { method: 'POST' });
                const data = await response.json();
                if (data.success) {
                  queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
                  toast({ title: "Upgrade réussi", description: "Utilisateur passé en Premium" });
                }
              } catch (error) {
                toast({ title: "Erreur", description: "Impossible d'upgrader", variant: "destructive" });
              }
            }}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            <Crown className="h-4 w-4 mr-2" />
            Upgrade Premium
          </Button>
          <Button 
            onClick={() => setShowAddUser(!showAddUser)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Ajouter un profil
          </Button>
          <Button 
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.xlsx,.xls';
              input.onchange = (e) => handleExcelImport(e);
              input.click();
            }}
            disabled={isImporting}
            className="bg-green-600 hover:bg-green-700"
          >
            <Upload className="h-4 w-4 mr-2" />
            {isImporting ? 'Import...' : 'Import Excel'}
          </Button>
          <Button 
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.zip';
              input.onchange = (e) => handlePhotosZipImport(e);
              input.click();
            }}
            disabled={isImportingPhotos}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Upload className="h-4 w-4 mr-2" />
            {isImportingPhotos ? 'Import Photos...' : 'Import ZIP Photos'}
          </Button>
          <Button 
            onClick={handleDirectImport}
            disabled={isImportingDirect}
            className="bg-red-600 hover:bg-red-700"
          >
            <Download className="h-4 w-4 mr-2" />
            {isImportingDirect ? 'Génération...' : 'Générer Profils Test'}
          </Button>
        </div>
      </div>

      <div className="p-6">
        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* First row: Name and City search */}
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher par prénom..."
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        setCurrentPage(1);
                      }
                    }}
                  />
                </div>
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher par ville..."
                    value={citySearch}
                    onChange={(e) => {
                      setCitySearch(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        setCurrentPage(1);
                      }
                    }}
                  />
                </div>
                <Button 
                  onClick={() => {
                    setCurrentPage(1);
                    // Force refresh des résultats
                  }}
                  variant="outline"
                  className="px-6"
                >
                  <Search className="h-4 w-4 mr-2" />
                  Rechercher
                </Button>
                <Button 
                  onClick={() => {
                    setSearchTerm("");
                    setCitySearch("");
                    setGenderFilters({ H: false, F: false });
                    setSubscriptionFilters({ gratuit: false, premium: false, gold: false });
                    setCurrentPage(1);
                    // Enlever les paramètres URL pour revenir à la vue complète
                    window.history.pushState({}, '', '/admin/users');
                  }}
                  variant="ghost"
                  className="px-4"
                >
                  <UserX className="h-4 w-4 mr-2" />
                  Effacer
                </Button>
                <div className="text-sm text-gray-600 min-w-fit">
                  {filteredUsers.length} résultat{filteredUsers.length > 1 ? 's' : ''} sur {users.length}
                </div>
              </div>
              
              {/* Second row: Filters */}
              <div className="flex gap-6 items-center">
                <div className="flex gap-2 items-center">
                  <Label className="text-sm font-medium">Genre :</Label>
                  <div className="flex gap-3">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="gender-h"
                        checked={genderFilters.H}
                        onChange={(e) => {
                          setGenderFilters(prev => ({ ...prev, H: e.target.checked }));
                          setCurrentPage(1);
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="gender-h" className="text-sm">H</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="gender-f"
                        checked={genderFilters.F}
                        onChange={(e) => {
                          setGenderFilters(prev => ({ ...prev, F: e.target.checked }));
                          setCurrentPage(1);
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="gender-f" className="text-sm">F</Label>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 items-center">
                  <Label className="text-sm font-medium">Abonnement :</Label>
                  <div className="flex gap-3">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="sub-gratuit"
                        checked={subscriptionFilters.gratuit}
                        onChange={(e) => {
                          setSubscriptionFilters(prev => ({ ...prev, gratuit: e.target.checked }));
                          setCurrentPage(1);
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="sub-gratuit" className="text-sm">Gratuit</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="sub-premium"
                        checked={subscriptionFilters.premium}
                        onChange={(e) => {
                          setSubscriptionFilters(prev => ({ ...prev, premium: e.target.checked }));
                          setCurrentPage(1);
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="sub-premium" className="text-sm">Premium</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="sub-gold"
                        checked={subscriptionFilters.gold}
                        onChange={(e) => {
                          setSubscriptionFilters(prev => ({ ...prev, gold: e.target.checked }));
                          setCurrentPage(1);
                        }}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="sub-gold" className="text-sm">Gold</Label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add User Form */}
        {showAddUser && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Créer un nouveau profil</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">Prénom</Label>
                    <Input
                      id="firstName"
                      value={newUser.firstName}
                      onChange={(e) => setNewUser({...newUser, firstName: e.target.value})}
                      placeholder="Marie"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Nom</Label>
                    <Input
                      id="lastName"
                      value={newUser.lastName}
                      onChange={(e) => setNewUser({...newUser, lastName: e.target.value})}
                      placeholder="Dubois"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="text"
                      value={newUser.email}
                      onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                      placeholder="admin+marie@date-mature.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="age">Âge</Label>
                    <Input
                      id="age"
                      type="text"
                      placeholder="40-75 ans"
                      value={newUser.age || ''}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value === '' || /^\d+$/.test(value)) {
                          setNewUser({...newUser, age: value === '' ? 0 : parseInt(value)});
                        }
                      }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city">Ville</Label>
                    <Input
                      id="city"
                      value={newUser.city}
                      onChange={(e) => setNewUser({...newUser, city: e.target.value})}
                      placeholder="Paris"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subscription">Abonnement</Label>
                    <Select value={newUser.subscription} onValueChange={(value) => setNewUser({...newUser, subscription: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gratuit">Gratuit</SelectItem>
                        <SelectItem value="premium">Premium</SelectItem>
                        <SelectItem value="gold">Gold</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Input
                    id="bio"
                    value={newUser.bio}
                    onChange={(e) => setNewUser({...newUser, bio: e.target.value})}
                    placeholder="Passionnée de lecture et de jardinage..."
                  />
                </div>

                <div>
                  <Label>Photo de profil</Label>
                  <PhotoUpload
                    currentPhoto={newUser.photo}
                    onPhotoSelected={(url) => setNewUser({...newUser, photo: url})}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Ou saisissez une URL : <Input
                      className="mt-1"
                      value={newUser.photo}
                      onChange={(e) => setNewUser({...newUser, photo: e.target.value})}
                      placeholder="https://randomuser.me/api/portraits/women/45.jpg"
                    />
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button type="submit" disabled={addUserMutation.isPending}>
                    {addUserMutation.isPending ? "Création..." : "Créer le profil"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowAddUser(false)}>
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Edit User Form */}
        {editingUser && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-800">
                <Edit className="w-5 h-5 mr-2" />
                Modifier le profil de {editingUser.firstName}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target as HTMLFormElement);
                const updatedUser = {
                  ...editingUser,
                  firstName: formData.get('firstName') as string,
                  lastName: formData.get('lastName') as string,
                  email: formData.get('email') as string,
                  age: parseInt(formData.get('age') as string),
                  city: formData.get('city') as string,
                  subscription: formData.get('subscription') as string,
                  bio: formData.get('bio') as string,
                  photo: formData.get('photo') as string,
                };
                
                fetch(`/api/admin/profile/${editingUser.id}`, {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(updatedUser)
                }).then(() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
                  setEditingUser(null);
                  toast({ title: "Profil modifié", description: "Les modifications ont été sauvegardées" });
                });
              }}>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label htmlFor="edit-firstName">Prénom</Label>
                    <Input name="firstName" defaultValue={editingUser.firstName} required />
                  </div>
                  <div>
                    <Label htmlFor="edit-lastName">Nom</Label>
                    <Input name="lastName" defaultValue={editingUser.lastName} />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label htmlFor="edit-email">Email</Label>
                    <Input name="email" type="text" defaultValue={editingUser.email} />
                  </div>
                  <div>
                    <Label htmlFor="edit-age">Âge</Label>
                    <Input name="age" type="number" min="40" max="75" defaultValue={editingUser.age} required />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label htmlFor="edit-city">Ville</Label>
                    <Input name="city" defaultValue={editingUser.city} required />
                  </div>
                  <div>
                    <Label htmlFor="edit-subscription">Abonnement</Label>
                    <Select name="subscription" defaultValue={editingUser.subscription}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gratuit">Gratuit</SelectItem>
                        <SelectItem value="premium">Premium</SelectItem>
                        <SelectItem value="gold">Gold</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="mb-4">
                  <Label htmlFor="edit-bio">Bio</Label>
                  <Input name="bio" defaultValue={editingUser.bio} placeholder="Passionnée de lecture..." />
                </div>

                <div className="mb-4">
                  <Label>Photo de profil</Label>
                  <PhotoUpload
                    currentPhoto={editingUser.photo}
                    onPhotoSelected={(url) => {
                      const photoInput = document.querySelector('input[name="photo"]') as HTMLInputElement;
                      if (photoInput) photoInput.value = url;
                    }}
                  />
                  <input type="hidden" name="photo" defaultValue={editingUser.photo} />
                </div>

                <div className="flex gap-2">
                  <Button type="submit">Sauvegarder</Button>
                  <Button type="button" variant="outline" onClick={() => setEditingUser(null)}>
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Users List */}
        <div className="grid gap-4">
          {paginatedUsers.map((user) => (
            <Card key={user.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <span className="text-lg font-medium text-purple-600">
                        {user.firstName?.charAt(0) || '?'}
                      </span>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">
                          {user.firstName} {user.lastName}
                        </h3>
                        {user.subscription === 'premium' && (
                          <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                            <Crown className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                        {user.subscription === 'gold' && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                            <Crown className="w-3 h-3 mr-1" />
                            Gold
                          </Badge>
                        )}
                        {user.email?.includes('example.com') && (
                          <Badge variant="outline" className="text-blue-600 border-blue-200">
                            Test
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <span className="font-medium mr-1">{user.gender}</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {user.age} ans
                        </div>
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {user.city}
                        </div>
                        <div className="flex items-center">
                          <Mail className="w-4 h-4 mr-1" />
                          {user.email}
                        </div>
                      </div>
                      
                      {user.bio && (
                        <p className="text-sm text-gray-600 mt-2 italic">
                          "{user.bio}"
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right space-y-2">
                    <div className="text-sm text-gray-500">
                      ID: {user.id}
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingUser(user)}
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Modifier
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {filteredUsers.length === 0 && searchTerm && (
            <Card>
              <CardContent className="text-center py-8">
                <UserX className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">Aucun résultat</h3>
                <p className="text-gray-500">Aucun utilisateur ne correspond à votre recherche "{searchTerm}"</p>
              </CardContent>
            </Card>
          )}

          {users.length === 0 && !searchTerm && (
            <Card>
              <CardContent className="text-center py-8">
                <UserX className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">Aucun utilisateur</h3>
                <p className="text-gray-500">Créez des profils pour alimenter votre plateforme</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center gap-2 mt-6">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Précédent
            </Button>
            
            <div className="flex gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className="w-10"
                >
                  {page}
                </Button>
              ))}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Suivant
            </Button>
          </div>
        )}

        {/* Pagination Info */}
        {filteredUsers.length > 0 && (
          <div className="text-center text-sm text-gray-600 mt-4">
            Affichage de {startIndex + 1} à {Math.min(startIndex + usersPerPage, filteredUsers.length)} sur {filteredUsers.length} résultats
          </div>
        )}
      </div>
    </div>
  );
}