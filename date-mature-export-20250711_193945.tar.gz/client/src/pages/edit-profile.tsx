import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, Save, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import MultiPhotoUpload from "@/components/multi-photo-upload";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type User } from "@shared/schema";

const editProfileSchema = z.object({
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères"),
  gender: z.enum(["H", "F"], { required_error: "Sélectionnez votre genre" }),
  age: z.number().min(40, "L'âge doit être entre 40 et 75 ans").max(75, "L'âge doit être entre 40 et 75 ans"),
  city: z.string().min(2, "La ville doit contenir au moins 2 caractères"),
  bio: z.string().optional(),
  interests: z.array(z.string()).min(1, "Sélectionnez au moins un centre d'intérêt"),
  photos: z.array(z.string()).default([])
});

type EditProfileData = z.infer<typeof editProfileSchema>;

const availableInterests = [
  "Voyage", "Lecture", "Jardinage", "Cuisine", "Musique", "Danse",
  "Cinéma", "Théâtre", "Sport", "Marche", "Nature", "Photographie",
  "Art", "Histoire", "Bénévolat", "Famille", "Animaux", "Bridge"
];

export default function EditProfile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [photos, setPhotos] = useState<string[]>([]);

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/users/current"],
  });

  const form = useForm<EditProfileData>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      firstName: "",
      gender: "H" as "H" | "F",
      age: 40,
      city: "",
      bio: "",
      interests: [],
      photos: []
    }
  });

  // Mettre à jour les valeurs du formulaire quand les données utilisateur sont chargées
  useEffect(() => {
    if (currentUser) {
      form.reset({
        firstName: currentUser.firstName || "",
        gender: (currentUser as any).gender || "H",
        age: currentUser.age || 40,
        city: currentUser.city || "",
        bio: currentUser.bio || "",
        interests: currentUser.interests || [],
        photos: currentUser.photos || []
      });
      if (currentUser.photos) {
        setPhotos(currentUser.photos);
      }
    }
  }, [currentUser, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: EditProfileData) => {
      const dataWithPhotos = { ...data, photos: photos };
      const response = await apiRequest("PUT", "/api/users/profile", dataWithPhotos);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/current"] });
      toast({
        title: "Profil mis à jour",
        description: "Vos modifications ont été enregistrées avec succès.",
      });
      setLocation("/profile");
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de la mise à jour du profil.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: EditProfileData) => {
    updateProfileMutation.mutate(data);
  };

  return (
    <>
      <SiteHeader />
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50">
        <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between py-4">
          <Button
            variant="outline"
            onClick={() => setLocation("/profile")}
            className="flex items-center"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Modifier mon profil</h1>
          <div className="w-20" /> {/* Spacer */}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Photo Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Camera className="h-5 w-5 mr-2" />
                  Photos de profil
                </CardTitle>
              </CardHeader>
              <CardContent>
                <MultiPhotoUpload
                  currentPhotos={photos}
                  onPhotosChange={(newPhotos) => setPhotos(newPhotos)}
                  maxPhotos={6}
                />
              </CardContent>
            </Card>

            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle>Informations de base</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prénom</FormLabel>
                      <FormControl>
                        <Input placeholder="Votre prénom" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Genre</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez votre genre" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="H">Homme</SelectItem>
                          <SelectItem value="F">Femme</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Âge</FormLabel>
                      <FormControl>
                        <Input
                          type="text"
                          placeholder="Âge (entre 40 et 75 ans)"
                          {...field}
                          value={field.value || ''}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (value === '' ? '' : /^\d+$/.test(value)) {
                              field.onChange(value === '' ? '' : parseInt(value));
                            }
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ville</FormLabel>
                      <FormControl>
                        <Input placeholder="Votre ville" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Bio */}
            <Card>
              <CardHeader>
                <CardTitle>À propos de vous</CardTitle>
              </CardHeader>
              <CardContent>
                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Biographie</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Parlez-nous de vous, vos passions, ce que vous recherchez..."
                          className="min-h-32"
                          maxLength={500}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Interests */}
            <Card>
              <CardHeader>
                <CardTitle>Centres d'intérêt</CardTitle>
              </CardHeader>
              <CardContent>
                <FormField
                  control={form.control}
                  name="interests"
                  render={() => (
                    <FormItem>
                      <div className="grid grid-cols-2 gap-3">
                        {availableInterests.map((interest) => (
                          <FormField
                            key={interest}
                            control={form.control}
                            name="interests"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={interest}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(interest)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, interest])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== interest
                                              )
                                            )
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {interest}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-rose-500 hover:bg-rose-600"
              disabled={updateProfileMutation.isPending}
            >
              {updateProfileMutation.isPending ? (
                "Enregistrement..."
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Enregistrer les modifications
                </>
              )}
            </Button>
          </form>
        </Form>
        </div>
      </div>
      <SiteFooter />
    </>
  );
}