import { useState } from "react";
import { ArrowLeft, Crown, Star, Check, AlertCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function MonthlyOffer() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState<string | null>(null);

  const handleMonthlySubscription = (plan: string) => {
    setLoading(plan);
    if (plan === "Premium") {
      setLocation("/checkout?plan=premium&billing=monthly");
    } else if (plan === "Gold") {
      setLocation("/checkout?plan=gold&billing=monthly");
    }
  };

  const handleAnnualSubscription = (plan: string) => {
    setLoading(plan);
    if (plan === "Premium") {
      setLocation("/checkout?plan=premium&billing=annual");
    } else if (plan === "Gold") {
      setLocation("/checkout?plan=gold&billing=annual");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-purple-600 text-white p-6 flex items-center">
        <Link href="/subscription">
          <Button variant="ghost" size="sm" className="mr-4 text-white hover:bg-white/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h2 className="text-xl font-semibold">Offre spéciale : Paiement mensuel</h2>
      </div>

      {/* Special Offer Banner */}
      <div className="bg-orange-100 border-l-4 border-orange-500 p-4 m-4">
        <div className="flex items-center">
          <AlertCircle className="h-5 w-5 text-orange-600 mr-2" />
          <div>
            <h3 className="text-orange-800 font-semibold">Offre exclusive !</h3>
            <p className="text-orange-700 text-sm">
              Vous préférez payer mensuellement ? Nous avons une solution pour vous.
            </p>
          </div>
        </div>
      </div>

      {/* Monthly Plans */}
      <div className="flex-1 px-6 space-y-4 overflow-y-auto">
        
        {/* Premium Monthly */}
        <Card className="border-2 border-primary/20 bg-white shadow-lg">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Crown className="h-6 w-6 text-primary" />
                <CardTitle className="text-xl">Premium Mensuel</CardTitle>
                <Badge variant="secondary">Flexible</Badge>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-800">13€</span>
                <p className="text-sm text-gray-500">/mois</p>
                <p className="text-xs text-gray-400 line-through">10€/mois en annuel</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mb-4">
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">20 flashs par jour</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Voir qui vous a flashé</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Support amélioré</span>
              </li>
            </ul>
            <div className="space-y-2">
              <Button 
                onClick={() => handleMonthlySubscription("Premium")}
                disabled={loading === "Premium"}
                className="w-full bg-primary hover:bg-primary/90"
              >
                {loading === "Premium" ? "Redirection..." : "Choisir mensuel - 13€"}
              </Button>
              <Button 
                onClick={() => handleAnnualSubscription("Premium")}
                disabled={loading === "Premium-annual"}
                variant="outline"
                className="w-full"
              >
                Ou 6 mois - 60€ (économie 33%)
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              ✓ Sans engagement, résiliation à tout moment
            </p>
          </CardContent>
        </Card>

        {/* Gold Monthly */}
        <Card className="border-2 border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50 shadow-lg">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Star className="h-6 w-6 text-yellow-500" />
                <CardTitle className="text-xl">Gold Mensuel</CardTitle>
                <Badge className="bg-yellow-500 text-yellow-900">VIP</Badge>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-800">25€</span>
                <p className="text-sm text-gray-500">/mois</p>
                <p className="text-xs text-gray-400 line-through">19€/mois en annuel</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mb-4">
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Flashs illimités</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Messages illimités</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Profil prioritaire</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Mode incognito</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="h-4 w-4 text-green-600" />
                <span className="text-sm">Badges exclusifs</span>
              </li>
            </ul>
            <div className="space-y-2">
              <Button 
                onClick={() => handleMonthlySubscription("Gold")}
                disabled={loading === "Gold"}
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-yellow-900"
              >
                {loading === "Gold" ? "Redirection..." : "Choisir mensuel - 25€"}
              </Button>
              <Button 
                onClick={() => handleAnnualSubscription("Gold")}
                disabled={loading === "Gold-annual"}
                variant="outline"
                className="w-full"
              >
                Ou 12 mois - 228€ (économie 53%)
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              ✓ Sans engagement, résiliation à tout moment
            </p>
          </CardContent>
        </Card>

        {/* Why Monthly */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-blue-800 mb-2">Pourquoi choisir le mensuel ?</h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Plus de flexibilité dans votre budget</li>
              <li>• Résiliation possible à tout moment</li>
              <li>• Idéal pour tester nos services premium</li>
              <li>• Parfait si vous n'êtes pas sûr de la durée souhaitée</li>
            </ul>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}