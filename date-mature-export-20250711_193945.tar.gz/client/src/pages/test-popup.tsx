import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import NewsletterPopup from '@/components/newsletter-popup';

export default function TestPopup() {
  const [showPopup, setShowPopup] = useState(false);

  const testDirectPopup = () => {
    console.log('Testing direct popup display...');
    setShowPopup(true);
  };

  const resetAll = () => {
    localStorage.removeItem('newsletter_popup_last_shown');
    localStorage.removeItem('newsletter_popup_dismissed_v2');
    localStorage.removeItem('newsletter_subscribed');
    console.log('All localStorage cleared');
  };

  const closePopup = () => {
    setShowPopup(false);
    console.log('Popup closed');
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Test Direct du Popup Newsletter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800 mb-2">Statut localStorage :</h3>
                <pre className="text-sm text-blue-700">
                  {JSON.stringify({
                    lastShown: localStorage.getItem('newsletter_popup_last_shown'),
                    dismissed: localStorage.getItem('newsletter_popup_dismissed_v2'),
                    subscribed: localStorage.getItem('newsletter_subscribed')
                  }, null, 2)}
                </pre>
              </div>

              <div className="flex gap-4">
                <Button 
                  onClick={testDirectPopup}
                  className="flex-1"
                >
                  Afficher le popup maintenant
                </Button>

                <Button 
                  onClick={resetAll}
                  variant="outline"
                  className="flex-1"
                >
                  Reset localStorage
                </Button>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-800 mb-2">Instructions :</h3>
                <ol className="text-sm text-yellow-700 space-y-1">
                  <li>1. Cliquez sur "Reset localStorage" pour nettoyer</li>
                  <li>2. Cliquez sur "Afficher le popup maintenant"</li>
                  <li>3. Si le popup s'affiche, le composant fonctionne</li>
                  <li>4. Sinon, il y a un problème avec le composant</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        <NewsletterPopup 
          onClose={closePopup}
          isVisible={showPopup}
        />
      </div>
    </div>
  );
}