import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Heart, LogIn, UserPlus } from "lucide-react";
import { FaGoogle, FaFacebook } from "react-icons/fa";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function AccueilV2() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });
  const { toast } = useToast();

  // Mutation pour la connexion
  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password?: string }) => {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: credentials.email }),
      });
      if (!response.ok) throw new Error('Login failed');
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/current"] });
      toast({ title: "Connexion réussie !" });
      setLocation("/home");
    },
    onError: () => {
      toast({ 
        title: "Erreur de connexion", 
        description: "Email non trouvé. Créez un compte d'abord.",
        variant: "destructive" 
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email.trim()) {
      toast({ 
        title: "Email requis", 
        description: "Veuillez saisir votre email",
        variant: "destructive" 
      });
      return;
    }
    loginMutation.mutate({ email: formData.email });
  };

  const goToSignup = () => {
    setLocation("/onboarding");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-rose-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-primary p-3 rounded-full">
              <Heart className="h-8 w-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-primary">
            Connexion
          </CardTitle>
          <p className="text-gray-600">
            Retrouvez l'amour après 40 ans
          </p>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="demo@seniors.fr"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="text-base"
                required
              />
              <p className="text-sm text-blue-600">
                Saisissez votre adresse email personnelle
              </p>
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={loginMutation.isPending}
            >
              <LogIn className="h-4 w-4 mr-2" />
              {loginMutation.isPending ? "Connexion..." : "Se connecter"}
            </Button>
          </form>

          {/* Connexion sociale */}
          <div className="mt-6 space-y-3">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">ou connectez-vous avec</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => window.location.href = '/api/auth/google'}
                className="w-full"
              >
                <FaGoogle className="h-4 w-4 mr-2 text-red-500" />
                Google
              </Button>
              <Button
                variant="outline"
                onClick={() => window.location.href = '/api/auth/facebook'}
                className="w-full"
              >
                <FaFacebook className="h-4 w-4 mr-2 text-blue-600" />
                Facebook
              </Button>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 mb-4">
              Vous n'avez pas encore de compte ?
            </p>
            <Button
              variant="outline"
              onClick={goToSignup}
              className="w-full"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Créer un compte
            </Button>
          </div>


        </CardContent>
      </Card>
    </div>
  );
}