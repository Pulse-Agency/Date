import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Heart, ArrowRight } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { trackDateMatureEvents } from "@/lib/analytics";

const preferencesSchema = z.object({
  lookingForGender: z.enum(["H", "F", "both"]),
  lookingForAgeMin: z.number().min(40).max(75),
  lookingForAgeMax: z.number().min(40).max(75),
  lookingForDistance: z.enum(["same_city", "same_region", "anywhere"]),
  lookingForRelationType: z.enum(["serious", "friendship", "both"])
}).refine((data) => data.lookingForAgeMin <= data.lookingForAgeMax, {
  message: "L'âge minimum doit être inférieur ou égal à l'âge maximum",
  path: ["lookingForAgeMax"]
});

type PreferencesData = z.infer<typeof preferencesSchema>;

export default function Preferences() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<PreferencesData>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: {
      lookingForGender: "both",
      lookingForAgeMin: 40,
      lookingForAgeMax: 75,
      lookingForDistance: "same_region",
      lookingForRelationType: "both"
    }
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: PreferencesData) => {
      const response = await apiRequest("PATCH", "/api/users/preferences", data);
      if (!response.ok) {
        throw new Error("Erreur lors de la mise à jour des préférences");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Préférences sauvegardées !",
        description: "Nous allons maintenant vous proposer des profils qui vous correspondent"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users/current"] });
      setLocation("/profiles");
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder vos préférences",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: PreferencesData) => {
    // Tracking Google Analytics - Préférences complétées
    trackDateMatureEvents.completePreferences(data);
    
    updatePreferencesMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
          <CardTitle className="text-2xl font-bold text-gray-800">
            Vos préférences de rencontre
          </CardTitle>
          <p className="text-gray-600 mt-2">
            Aidez-nous à vous proposer des profils qui vous correspondent
          </p>
        </CardHeader>

        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              {/* Genre recherché */}
              <FormField
                control={form.control}
                name="lookingForGender"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-medium">Vous recherchez</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex gap-6"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="H" id="looking-h" />
                          <Label htmlFor="looking-h">Des hommes</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="F" id="looking-f" />
                          <Label htmlFor="looking-f">Des femmes</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="both" id="looking-both" />
                          <Label htmlFor="looking-both">Peu importe</Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Tranche d'âge */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="lookingForAgeMin"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Âge minimum</FormLabel>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="40 ans" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.from({ length: 36 }, (_, i) => i + 40).map(age => (
                            <SelectItem key={age} value={age.toString()}>
                              {age} ans
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lookingForAgeMax"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Âge maximum</FormLabel>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="75 ans" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.from({ length: 36 }, (_, i) => i + 40).map(age => (
                            <SelectItem key={age} value={age.toString()}>
                              {age} ans
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Distance */}
              <FormField
                control={form.control}
                name="lookingForDistance"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-medium">Distance de recherche</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="space-y-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="same_city" id="distance-city" />
                          <Label htmlFor="distance-city">Dans ma ville uniquement</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="same_region" id="distance-region" />
                          <Label htmlFor="distance-region">Dans ma région</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="anywhere" id="distance-anywhere" />
                          <Label htmlFor="distance-anywhere">Partout en France</Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Type de relation */}
              <FormField
                control={form.control}
                name="lookingForRelationType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-medium">Type de relation recherchée</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="space-y-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="serious" id="relation-serious" />
                          <Label htmlFor="relation-serious">Relation sérieuse</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="friendship" id="relation-friendship" />
                          <Label htmlFor="relation-friendship">Amitié</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="both" id="relation-both" />
                          <Label htmlFor="relation-both">Les deux</Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 text-white font-semibold py-3"
                disabled={updatePreferencesMutation.isPending}
              >
                {updatePreferencesMutation.isPending ? "Sauvegarde..." : "Continuer"}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}