import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Shield, Users, Star, CheckCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { useNewsletterPopup } from "@/hooks/use-newsletter-popup";
import NewsletterPopup from "@/components/newsletter-popup";
import EbookForm from "@/components/ebook-form";
import coupleKissImg from "@assets/pexels-ohshineon-18397_1752067571952.jpg";
import coupleMountainImg from "@assets/pexels-andre-furtado-43594-1417255_1752067571953.jpg";
import coupleBeachImg from "@assets/pexels-summerstock-285938_1752067571954.jpg";
import coupleBenchImg from "@assets/pexels-olly-3764148_1752067571951.jpg";

// Hook personnalisé pour synchroniser les carrousels
function useSynchronizedCarousel(itemCount: number, interval: number = 7000) {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % itemCount);
    }, interval);
    return () => clearInterval(timer);
  }, [itemCount, interval]);
  
  return currentIndex;
}



// Composant carrousel de photos avec témoignages synchronisés
function PhotoCarousel() {
  const currentIndex = useSynchronizedCarousel(4, 7000);
  
  // Photos et témoignages synchronisés - avec fallback URLs
  const slidesData = [
    {
      photo: coupleMountainImg || "https://images.unsplash.com/photo-1596003906949-67221c37965c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1974&q=80",
      names: "Isabelle & Laurent",
      duration: "En couple depuis 1 an",
      text: "Nous partageons les mêmes passions.\nC'est notre nouvelle aventure !"
    },
    {
      photo: coupleBenchImg || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1976&q=80", 
      names: "Nathalie & David",
      duration: "En couple depuis 8 mois",
      text: "L'élégance et la douceur réunies.\nNotre histoire commence maintenant."
    },
    {
      photo: coupleKissImg || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1974&q=80",
      names: "Marie & Pierre", 
      duration: "En couple depuis 2 ans",
      text: "Un moment magique !\nNous nous sommes trouvés grâce à Date Mature."
    },
    {
      photo: coupleBeachImg || "https://images.unsplash.com/photo-1516999420207-4e172d96dff0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1974&q=80",
      names: "Sophie & Michel",
      duration: "En couple depuis 6 mois", 
      text: "Une belle complicité dès notre première rencontre.\nMerci Date Mature !"
    }
  ];
  
  return (
    <div className="relative w-full">
      {/* Slider photos OPTIMISÉ iPhone 7 SE - hauteur responsive */}
      <div className="relative w-full h-48 sm:h-56 md:h-64 lg:h-72 mobile-carousel-container overflow-hidden rounded-xl bg-gradient-to-br from-rose-200 to-pink-300 mb-3 sm:mb-4">
        <div 
          className="flex transition-transform duration-1000 ease-in-out h-full"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {slidesData.map((slide, index) => (
            <div key={index} className="min-w-full h-full flex-shrink-0 relative carousel-slide">
              <div className="w-full h-full rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={slide.photo} 
                  alt={`${slide.names} - bonheur`}
                  className="w-full h-full object-cover object-center mobile-carousel-image"
                  style={{
                    imageRendering: 'optimizeQuality',
                    WebkitImageRendering: 'optimizeQuality',
                    objectPosition: 'center 30%',
                    minHeight: '192px'
                  }}
                  loading="eager"
                  onError={(e) => {
                    console.log('Image failed to load:', slide.photo);
                    // Force reload with different src
                    const target = e.target as HTMLImageElement;
                    if (!target.src.includes('unsplash')) {
                      target.src = `https://images.unsplash.com/photo-1596003906949-67221c37965c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`;
                    }
                  }}
                />
              </div>
              <div className="absolute top-1 left-1 sm:top-2 sm:left-2">
                <Heart className="h-3 w-3 sm:h-4 sm:w-4 text-white drop-shadow-md" />
              </div>
            </div>
          ))}
        </div>
        
        {/* Indicateurs en bas */}
        <div className="absolute bottom-2 sm:bottom-3 md:bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-1 sm:space-x-2">
          {slidesData.map((_, index) => (
            <div
              key={index}
              className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition-all duration-300 ${
                index === currentIndex ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
      
      {/* Témoignage optimisé mobile SANS chevauchement */}
      <div className="mt-4 flex justify-center">
        <div className="bg-white rounded-lg p-3 sm:p-4 shadow-lg border border-gray-200 max-w-full mx-4 sm:mx-0 sm:max-w-md">
          <div className="flex items-center mb-2 sm:mb-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-rose-500 rounded-full flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
              <Heart className="h-3 w-3 sm:h-5 sm:w-5 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-gray-900 text-xs sm:text-sm truncate">{slidesData[currentIndex].names}</p>
              <p className="text-xs text-gray-600 truncate">{slidesData[currentIndex].duration}</p>
            </div>
          </div>
          <p className="text-gray-700 italic text-sm sm:text-base leading-tight whitespace-pre-line">"{slidesData[currentIndex].text}"</p>
        </div>
      </div>
    </div>
  );
}

export default function Landing() {
  const [, setLocation] = useLocation();
  const { showPopup, closePopup } = useNewsletterPopup();
  const [showEbookForm, setShowEbookForm] = useState(false);
  
  // Fonction pour ouvrir le formulaire ebook spécifique
  const openEbookForm = () => {
    setShowEbookForm(true);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFEFF2' }}>
      {/* Newsletter Popup */}
      {showPopup && (
        <NewsletterPopup onClose={closePopup} />
      )}
      {/* Hero Section - Mobile First */}
      <section className="py-6 sm:py-8 md:py-12 lg:py-16 px-3 sm:px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 md:gap-12 items-center">
            {/* Contenu texte à gauche */}
            <div className="space-y-4 sm:space-y-6 md:space-y-8">
              <div>
                <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 mb-3 sm:mb-4 md:mb-6 leading-tight">
                  Retrouvez<br />
                  <span className="text-rose-500">l'amour</span><br />
                  après 40 ans
                </h1>
                <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-600 mb-2 sm:mb-3 md:mb-4">
                  Découvrez la personne qui vous fera retrouver le sourire.
                </p>
                <p className="text-xs sm:text-sm md:text-base lg:text-lg font-medium mb-4 sm:mb-6 md:mb-8 text-gray-600">
                  La plateforme <span className="text-teal-600 font-semibold">la plus accessible du marché</span> pour des rencontres sérieuses et authentiques.
                </p>
              </div>

              <Button 
                size="lg"
                onClick={() => setLocation("/onboarding")}
                className="w-full sm:w-auto bg-rose-500 hover:bg-rose-600 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all"
              >
                <Heart className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                Commencer mon histoire
              </Button>

              <div className="space-y-2 sm:space-y-3">
                <div className="flex flex-col space-y-1 sm:space-y-2 text-xs sm:text-sm text-gray-600">
                  <div className="flex items-center">
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 mr-1 sm:mr-2 flex-shrink-0" />
                    <span>Inscription gratuite</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 mr-1 sm:mr-2 flex-shrink-0" />
                    <span>Plus de 10 000 célibataires</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 mr-1 sm:mr-2 flex-shrink-0" />
                    <span>Sécurisé et confidentiel</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-1 sm:space-y-0 sm:space-x-3 md:space-x-6 text-xs sm:text-sm">
                  <div className="flex items-center">
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 mr-1 sm:mr-2 flex-shrink-0" />
                    <span className="font-semibold">100% sécurisé</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-green-500 mr-1 sm:mr-2 flex-shrink-0" />
                    <span className="font-semibold">Profils vérifiés</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-400 mr-1 sm:mr-2 flex-shrink-0" />
                    <span className="font-semibold">4,8/5 avis</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Carrousel à droite */}
            <div className="mt-4 sm:mt-6 lg:mt-0">
              <PhotoCarousel />
            </div>
          </div>
        </div>
      </section>

      {/* Section avantages - Mobile First */}
      <section className="py-8 sm:py-12 md:py-16 px-3 sm:px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-center text-gray-900 mb-3 sm:mb-4">
            Pourquoi choisir Date Mature ?
          </h2>
          <p className="text-center text-gray-600 mb-6 sm:mb-8 md:mb-12 text-sm sm:text-base px-2">
Rencontres sérieuses pour les 40 ans et plus
          </p>
          
          <div className="grid md:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
            <div className="text-center p-4 sm:p-6 rounded-lg border border-gray-100">
              <div className="bg-rose-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6">
                <Users className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2 sm:mb-3 md:mb-4">Communauté mature</h3>
              <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                Rejoignez une communauté de célibataires de 40 à 75 ans qui cherchent des relations sérieuses et durables.
              </p>
            </div>
            
            <div className="text-center p-4 sm:p-6 rounded-lg border border-gray-100">
              <div className="bg-rose-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6">
                <Shield className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2 sm:mb-3 md:mb-4">Sécurité garantie</h3>
              <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                Profils vérifiés manuellement, données sécurisées et environnement de confiance pour des rencontres en toute sérénité.
              </p>
            </div>
            
            <div className="text-center p-4 sm:p-6 rounded-lg border border-gray-100">
              <div className="bg-rose-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6">
                <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2 sm:mb-3 md:mb-4">Rencontres authentiques</h3>
              <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                Système de matching intelligent basé sur la compatibilité et les centres d'intérêt pour des rencontres de qualité.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final - Mobile First */}
      <section className="py-8 sm:py-12 md:py-16 px-3 sm:px-4 bg-rose-500">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6">
            Prêt(e) à retrouver l'amour ?
          </h2>
          <p className="text-sm sm:text-base md:text-lg lg:text-xl text-rose-100 mb-3 sm:mb-4 md:mb-6 px-2">
            Rejoignez des milliers de célibataires qui ont déjà trouvé l'amour sur Date Mature
          </p>
          <p className="text-sm sm:text-base md:text-lg text-rose-200 mb-6 sm:mb-8">
            Tarifs imbattables - dès 10€/mois
          </p>
          <Button 
            size="lg" 
            onClick={() => setLocation("/onboarding")}
            className="w-full sm:w-auto bg-white text-rose-500 hover:bg-gray-50 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all"
          >
            <Heart className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
            Créer mon profil gratuitement
          </Button>
          <p className="text-xs sm:text-sm text-rose-200 mt-3 sm:mt-4">
            Déjà membre ? <button onClick={() => setLocation("/onboarding")} className="underline font-semibold">Se connecter</button>
          </p>
        </div>
      </section>

      {/* Footer - Mobile First */}
      <footer className="bg-gray-900 text-white py-6 sm:py-8 md:py-12 px-3 sm:px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            <div className="col-span-2 md:col-span-1 mb-4 md:mb-0">
              <div className="flex items-center space-x-2 mb-3 sm:mb-4">
                <Heart className="h-5 w-5 sm:h-6 sm:w-6 text-rose-500" />
                <span className="text-lg sm:text-xl font-bold">Date Mature</span>
              </div>
              <p className="text-gray-400 text-xs sm:text-sm">
                Rencontres sérieuses pour les 40 ans et plus
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2 sm:mb-3 md:mb-4 text-sm sm:text-base">Aide</h3>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-gray-400">
                <li><a href="/help" className="hover:text-white transition-colors">Centre d'aide</a></li>
                <li><a href="/security" className="hover:text-white transition-colors">Sécurité</a></li>
                <li><a href="/legal/cgv" className="hover:text-white transition-colors">Conditions</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2 sm:mb-3 md:mb-4 text-sm sm:text-base">Communauté</h3>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Témoignages</a></li>
                <li>
                  <button 
                    onClick={openEbookForm}
                    className="hover:text-white transition-colors text-left"
                  >
                    Conseils
                  </button>
                </li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2 sm:mb-3 md:mb-4 text-sm sm:text-base">Contact</h3>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-gray-400">
                <li className="break-all">contact@date-mature.com</li>
                <li><a href="/help" className="hover:text-white transition-colors">Support</a></li>
                <li><a href="/legal/mentions-legales" className="hover:text-white transition-colors">Mentions légales</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Popup Newsletter */}
      <NewsletterPopup
        isVisible={showPopup}
        onClose={closePopup}
      />
      
      {/* Formulaire Ebook spécifique */}
      <EbookForm
        isVisible={showEbookForm}
        onClose={() => setShowEbookForm(false)}
      />
    </div>
  );
}