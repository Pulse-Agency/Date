import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

export default function AdminDebug() {
  const [testData, setTestData] = useState<any>(null);
  
  // Test direct fetch
  const testFetch = async () => {
    try {
      const response = await fetch('/api/admin/users');
      const data = await response.json();
      setTestData(data);
      console.log('Test fetch réussi:', data);
    } catch (error) {
      console.error('Erreur fetch:', error);
      setTestData({ error: error.message });
    }
  };

  // Test avec React Query
  const { data: queryData, isLoading, error } = useQuery({
    queryKey: ["/api/admin/users"],
    queryFn: async () => {
      const response = await fetch('/api/admin/users');
      return response.json();
    }
  });

  console.log('AdminDebug - State:', {
    isLoading,
    error,
    queryData: queryData ? 'DATA_PRESENT' : 'NO_DATA',
    testData: testData ? 'TEST_DATA_PRESENT' : 'NO_TEST_DATA'
  });

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Admin Debug</h1>
      
      <div className="space-y-4">
        <div className="bg-white p-4 rounded-lg border">
          <h2 className="font-semibold mb-2">Test Direct Fetch</h2>
          <button 
            onClick={testFetch}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Test Fetch
          </button>
          {testData && (
            <div className="mt-2 p-2 bg-gray-100 rounded">
              <pre className="text-xs overflow-auto max-h-40">
                {JSON.stringify(testData, null, 2)}
              </pre>
            </div>
          )}
        </div>

        <div className="bg-white p-4 rounded-lg border">
          <h2 className="font-semibold mb-2">Test React Query</h2>
          <div className="space-y-2">
            <div>Loading: {isLoading ? 'YES' : 'NO'}</div>
            <div>Error: {error ? 'YES' : 'NO'}</div>
            <div>Data: {queryData ? 'YES' : 'NO'}</div>
            {queryData && (
              <div>
                <div>Users: {queryData.users?.length || 0}</div>
                <div>Stats: {JSON.stringify(queryData.stats)}</div>
                <div className="mt-2 p-2 bg-gray-100 rounded">
                  <pre className="text-xs overflow-auto max-h-40">
                    {JSON.stringify(queryData, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}