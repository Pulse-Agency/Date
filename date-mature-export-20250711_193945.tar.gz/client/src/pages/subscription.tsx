import { ArrowLeft, Crown, Star, Check, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function Subscription() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubscription = (plan: string) => {
    if (plan === "Premium") {
      setLocation("/checkout?plan=premium");
    } else if (plan === "Gold") {
      setLocation("/checkout?plan=gold");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-purple-600 text-white p-6 flex items-center">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mr-4 text-white hover:bg-white/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h2 className="text-xl font-semibold">Choisir mon abonnement</h2>
      </div>

      {/* Benefits Section */}
      <div className="p-6 text-center">
        <Crown className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Trouvez l'amour plus vite</h3>
        <p className="text-gray-600 text-lg">Accédez à toutes les fonctionnalités premium</p>
      </div>

      {/* Subscription Plans */}
      <div className="flex-1 px-6 space-y-4 overflow-y-auto">
        
        {/* Free Plan */}
        <Card className="border-2 border-gray-200">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Gratuit</CardTitle>
              <span className="text-2xl font-bold text-gray-800">0€</span>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                3 flashs par jour
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Répondre aux messages
              </li>
              <li className="flex items-center">
                <X className="h-5 w-5 text-red-400 mr-3" />
                Initier des conversations
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Premium Plan */}
        <Card className="border-2 border-purple-300 relative premium-glow">
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
            <Badge className="bg-purple-600 text-white px-4 py-1">
              <Star className="h-3 w-3 mr-1" />
              Populaire
            </Badge>
          </div>
          <CardHeader className="pb-4 pt-8">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Premium</CardTitle>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-800">10€</span>
                <p className="text-sm text-gray-500">/mois</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                5 flashs par jour
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Initier des conversations
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Voir qui a visité votre profil
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Support prioritaire
              </li>
            </ul>
            <Button 
              className="w-full bg-purple-600 hover:bg-purple-700 text-white py-4 text-lg font-semibold"
              onClick={() => handleSubscription("Premium")}
            >
              Choisir Premium
            </Button>
          </CardContent>
        </Card>

        {/* Gold Plan */}
        <Card className="border-2 border-yellow-400 relative gold-glow bg-gradient-to-br from-yellow-50 to-orange-50">
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
            <Badge className="bg-yellow-500 text-white px-4 py-1">
              <Crown className="h-3 w-3 mr-1" />
              VIP
            </Badge>
          </div>
          <CardHeader className="pb-4 pt-8">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Gold</CardTitle>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-800">19€</span>
                <p className="text-sm text-gray-500">/mois</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Flashs illimités
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Navigation invisible
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Mise en avant du profil
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Filtres avancés
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-3" />
                Événements VIP exclusifs
              </li>
            </ul>
            <Button 
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-4 text-lg font-semibold"
              onClick={() => handleSubscription("Gold")}
            >
              Devenir Gold
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="p-6 space-y-4">
        {/* Engagement Notice */}
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="text-center text-sm text-orange-700">
            <p className="font-medium mb-1">Conditions d'engagement</p>
            <p>Premium : Engagement 6 mois (60€ total) • Gold : Engagement 12 mois (228€ total)</p>
            <p>Annulation possible uniquement à la fin de la période d'engagement</p>
          </div>
        </div>
        
        <div className="text-center">
          <Link href="/">
            <Button variant="link" className="text-primary font-medium underline">
              Continuer avec la version gratuite
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
