import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Heart, CheckCircle, Sparkles, BookOpen } from 'lucide-react';
import mockupImage from '@assets/Mockup guide_1752214996941.png';

export default function EbookPage() {
  const [firstName, setFirstName] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !firstName.trim()) return;

    setIsSubmitting(true);
    
    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: email.trim(),
          firstName: firstName.trim(),
          source: 'ebook_social_link',
          tags: ['ebook_social', 'prospects_reseaux_sociaux']
        })
      });

      if (response.ok) {
        setIsSuccess(true);
        setEmail('');
        setFirstName('');
      }
    } catch (error) {
      console.error('Erreur inscription:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50 p-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center mb-3">
            <Heart className="w-6 h-6 text-rose-500 mr-2" />
            <h1 className="text-2xl font-bold text-gray-900">Date Mature</h1>
          </div>
          
          <h2 className="text-3xl font-bold text-gray-900 mb-3">
            Retrouvez l'amour après 40 ans
          </h2>
          
          <p className="text-lg text-gray-600 mb-6">
            Découvrez nos conseils exclusifs pour créer des connexions authentiques et durables
          </p>
        </div>

        {/* Formulaire principal */}
        <Card className="max-w-4xl mx-auto bg-white rounded-xl shadow-2xl overflow-hidden">
          {!isSuccess ? (
            <div className="grid grid-cols-1 md:grid-cols-2 min-h-[450px]">
              {/* Section gauche - Header rose avec mockup */}
              <div className="bg-gradient-to-br from-rose-500 to-pink-600 text-white p-6 flex flex-col justify-center">
                <div className="flex items-center mb-4">
                  <BookOpen className="w-6 h-6 mr-2" />
                  <Heart className="w-5 h-5" />
                </div>
                
                <h2 className="text-2xl font-bold mb-3">
                  Redécouvrir le bonheur d'être aimé(e) après 40 ans
                </h2>
                
                <p className="text-pink-100 text-base mb-6">
                  Le guide complet pour retrouver l'amour authentique
                </p>
                
                {/* Mockup réel */}
                <div className="flex justify-center mb-6">
                  <img 
                    src={mockupImage} 
                    alt="Mockup du guide - Tablette, téléphone et livre"
                    className="w-full max-w-[280px] h-auto object-contain"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-yellow-300 rounded-full mr-3"></div>
                    <span className="text-xs">Ce qui empêche d'aimer <span className="text-pink-200">(sans le savoir)</span></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-300 rounded-full mr-3"></div>
                    <span className="text-xs">Dépasser ses blocages <span className="text-pink-200">et oser une vraie rencontre</span></span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-pink-300 rounded-full mr-3"></div>
                    <span className="text-xs">Créer un lien serein, <span className="text-pink-200">sans refaire les mêmes erreurs</span></span>
                  </div>
                </div>
              </div>
              
              {/* Section droite - Formulaire */}
              <div className="p-6 flex flex-col justify-center">
                <div className="mb-4">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Recevez votre guide gratuit
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Entrez vos informations ci-dessous pour télécharger immédiatement votre guide
                  </p>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                        Votre prénom
                      </label>
                      <Input
                        id="firstName"
                        type="text"
                        placeholder="Jean"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Votre email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="jean@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent"
                        required
                      />
                    </div>
                  </div>
                  
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                        Envoi en cours...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <BookOpen className="w-5 h-5 mr-2" />
                        Recevoir le guide gratuit
                      </div>
                    )}
                  </Button>
                </form>
                
                <p className="text-xs text-gray-500 mt-3 text-center">
                  Vos données sont protégées. Vous pouvez vous désinscrire à tout moment.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center">
              <div className="mb-4">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Merci {firstName} !
                </h3>
                <p className="text-gray-600 text-sm">
                  Votre guide "Les 7 secrets pour séduire après 40 ans" vous sera envoyé par email dans quelques minutes.
                </p>
              </div>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="flex items-center justify-center text-green-700">
                  <Sparkles className="w-4 h-4 mr-2" />
                  <span className="font-semibold text-sm">N'oubliez pas de vérifier vos emails !</span>
                </div>
              </div>
              
              <Button
                onClick={() => window.location.href = '/'}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white py-2 rounded-lg font-semibold"
              >
                Découvrir Date Mature
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}