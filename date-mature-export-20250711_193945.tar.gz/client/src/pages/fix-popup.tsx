import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

export default function FixPopup() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Forcer la fermeture définitive de la popup newsletter
    localStorage.setItem('date_mature_newsletter_done', 'true');
    
    // Rediriger vers la page d'accueil après 2 secondes
    const timer = setTimeout(() => {
      setLocation('/');
    }, 2000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-xl text-gray-800">
            Popup Newsletter Désactivée
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-600 mb-4">
            La popup de newsletter ne s'affichera plus.
          </p>
          <p className="text-sm text-gray-500">
            Redirection automatique vers l'accueil...
          </p>
        </CardContent>
      </Card>
    </div>
  );
}