import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Zap, Crown, Star, Users, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';
import FlashBonusModal from '@/components/flash-bonus-modal';

export default function TestFlashBonus() {
  const [showModal, setShowModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'gratuit' | 'premium' | 'gold'>('premium');
  const [remainingFlashes, setRemainingFlashes] = useState(2);

  const plans = [
    {
      id: 'gratuit' as const,
      name: 'Gratuit',
      flashsPerDay: 3,
      color: 'from-gray-500 to-gray-600'
    },
    {
      id: 'premium' as const,
      name: 'Premium',
      flashsPerDay: 20,
      color: 'from-blue-500 to-indigo-600'
    },
    {
      id: 'gold' as const,
      name: 'Gold',
      flashsPerDay: 'Illimité',
      color: 'from-yellow-500 to-orange-600'
    }
  ];

  const simulateFlashUsage = () => {
    if (remainingFlashes > 0) {
      setRemainingFlashes(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">
            Test - Système Flashs Bonus
          </h1>
        </div>

        {/* Plan selector */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>Sélectionnez votre plan pour tester</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {plans.map((plan) => (
                <button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedPlan === plan.id 
                      ? 'border-rose-500 bg-rose-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${plan.color} flex items-center justify-center text-white mx-auto mb-3`}>
                    {plan.id === 'gold' ? <Crown className="h-6 w-6" /> : <Heart className="h-6 w-6" />}
                  </div>
                  <h3 className="font-semibold text-gray-900">{plan.name}</h3>
                  <p className="text-sm text-gray-600">
                    {plan.flashsPerDay} flashs/jour
                  </p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Current status */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5" />
              <span>Statut actuel</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Plan actuel:</span>
                  <span className="font-semibold capitalize">{selectedPlan}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Flashs restants:</span>
                  <span className="font-semibold text-rose-600">{remainingFlashes}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Flashs quotidiens:</span>
                  <span className="font-semibold">
                    {plans.find(p => p.id === selectedPlan)?.flashsPerDay}
                  </span>
                </div>
              </div>
              
              <div className="space-y-4">
                <Button 
                  onClick={simulateFlashUsage}
                  disabled={remainingFlashes === 0}
                  className="w-full bg-rose-500 hover:bg-rose-600 text-white"
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Utiliser un Flash
                </Button>
                
                <Button 
                  onClick={() => setShowModal(true)}
                  variant="outline"
                  className="w-full border-rose-500 text-rose-600 hover:bg-rose-50"
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Acheter Flashs Bonus
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Scenarios */}
        <Card>
          <CardHeader>
            <CardTitle>Scénarios de test</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Plan Gratuit</h4>
                <p className="text-sm text-blue-800">
                  Seule la "Mise en avant" est disponible. Suggestion d'upgrade vers Premium.
                </p>
              </div>
              
              <div className="p-4 bg-indigo-50 rounded-lg">
                <h4 className="font-semibold text-indigo-900 mb-2">Plan Premium</h4>
                <p className="text-sm text-indigo-800">
                  Accès au "Pack 50 Flashs" à 5€ + "Mise en avant" à 10€.
                </p>
              </div>
              
              <div className="p-4 bg-yellow-50 rounded-lg">
                <h4 className="font-semibold text-yellow-900 mb-2">Plan Gold</h4>
                <p className="text-sm text-yellow-800">
                  Accès aux "Super Flashs" à 2€ + "Mise en avant" à 10€. Pas de pack nécessaire.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Reset button */}
        <div className="mt-8 text-center">
          <Button 
            onClick={() => setRemainingFlashes(2)}
            variant="outline"
            className="text-gray-600"
          >
            Réinitialiser les flashs
          </Button>
        </div>
      </div>

      {/* Modal */}
      <FlashBonusModal
        isVisible={showModal}
        onClose={() => setShowModal(false)}
        userPlan={selectedPlan}
        remainingFlashes={remainingFlashes}
      />
    </div>
  );
}