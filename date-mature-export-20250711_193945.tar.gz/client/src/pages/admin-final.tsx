import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, Download, Search, Activity, Edit, Crown, Star, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function AdminFinal() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [regionFilter, setRegionFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const USERS_PER_PAGE = 10;

  const { data: users, isLoading: usersLoading, refetch } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const regions = [
    "Île-de-France", "Provence-Alpes-Côte d'Azur", "Auvergne-Rhône-Alpes",
    "Occitanie", "Nouvelle-Aquitaine", "Grand Est", "Hauts-de-France", 
    "Normandie", "Bretagne", "Pays de la Loire", "Centre-Val de Loire",
    "Bourgogne-Franche-Comté", "Corse"
  ];

  const getCitiesByRegion = (region: string) => {
    const regionMap: Record<string, string[]> = {
      "Île-de-France": ["Paris", "Versailles", "Meaux", "Melun", "Évry", "Nanterre", "Créteil", "Bobigny"],
      "Provence-Alpes-Côte d'Azur": ["Marseille", "Nice", "Toulon", "Aix-en-Provence", "Cannes", "Avignon", "Antibes"],
      "Centre-Val de Loire": ["Tours", "Orléans", "Blois", "Bourges", "Chartres", "Châteauroux", "Montargis"],
      "Nouvelle-Aquitaine": ["Bordeaux", "Limoges", "Poitiers", "La Rochelle", "Pau", "Bayonne", "Périgueux"],
      "Occitanie": ["Toulouse", "Montpellier", "Nîmes", "Perpignan", "Béziers", "Albi", "Carcassonne"],
      "Auvergne-Rhône-Alpes": ["Lyon", "Grenoble", "Saint-Étienne", "Annecy", "Chambéry", "Valence", "Clermont-Ferrand"],
      "Grand Est": ["Strasbourg", "Metz", "Nancy", "Reims", "Mulhouse", "Troyes", "Colmar"],
      "Hauts-de-France": ["Lille", "Amiens", "Roubaix", "Tourcoing", "Calais", "Dunkerque", "Valenciennes"],
      "Normandie": ["Rouen", "Le Havre", "Caen", "Cherbourg", "Évreux", "Alençon", "Bayeux"],
      "Bretagne": ["Rennes", "Brest", "Quimper", "Lorient", "Vannes", "Saint-Malo", "Lannion"],
      "Pays de la Loire": ["Nantes", "Angers", "Le Mans", "La Roche-sur-Yon", "Cholet", "Laval", "Saumur"],
      "Bourgogne-Franche-Comté": ["Dijon", "Besançon", "Belfort", "Chalon-sur-Saône", "Auxerre", "Mâcon", "Nevers"],
      "Corse": ["Ajaccio", "Bastia", "Porto-Vecchio", "Calvi", "Corte", "Bonifacio", "Propriano"]
    };
    return regionMap[region] || [];
  };

  const resetAllToGratuit = async () => {
    try {
      const response = await apiRequest('POST', '/api/admin/reset-subscriptions');
      if (response.ok) {
        toast({ title: "Abonnements réinitialisés", description: "Tous les utilisateurs sont maintenant gratuits" });
        refetch();
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de réinitialiser", variant: "destructive" });
    }
  };

  const upgradeUser = async (userId: number, subscription: string) => {
    try {
      const response = await apiRequest('POST', `/api/admin/users/${userId}/upgrade`, { subscription });
      if (response.ok) {
        toast({ title: "Utilisateur mis à jour", description: `Abonnement changé vers ${subscription}` });
        refetch();
      }
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de mettre à jour", variant: "destructive" });
    }
  };

  const editUser = async (user: any) => {
    const newFirstName = prompt(`Modifier le prénom:`, user.firstName);
    const newAge = prompt(`Modifier l'âge:`, user.age?.toString());
    const newCity = prompt(`Modifier la ville:`, user.city);
    const newBio = prompt(`Modifier la bio:`, user.bio || "");
    
    if (newFirstName || newAge || newCity || newBio) {
      try {
        const updates: any = {};
        if (newFirstName && newFirstName !== user.firstName) updates.firstName = newFirstName;
        if (newAge && parseInt(newAge) !== user.age) updates.age = parseInt(newAge);
        if (newCity && newCity !== user.city) updates.city = newCity;
        if (newBio && newBio !== user.bio) updates.bio = newBio;
        
        const response = await apiRequest('PUT', `/api/admin/users/${user.id}`, updates);
        if (response.ok) {
          toast({ title: "Profil mis à jour", description: "Modifications sauvegardées" });
          refetch();
        }
      } catch (error) {
        toast({ title: "Erreur", description: "Impossible de sauvegarder", variant: "destructive" });
      }
    }
  };

  const downloadBackup = async () => {
    try {
      const link = document.createElement('a');
      link.href = '/api/admin/backup';
      link.download = `backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Backup téléchargé", description: "Sauvegarde créée avec succès" });
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de télécharger le backup", variant: "destructive" });
    }
  };

  if (usersLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!users || !stats) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Erreur de chargement</h2>
          <p className="text-gray-600">Impossible de charger les données</p>
        </div>
      </div>
    );
  }

  const realUsers = (users as any[]).filter((u: any) => !u.isTestProfile);
  const premiumUsers = realUsers.filter((u: any) => u.subscription === 'premium');
  const goldUsers = realUsers.filter((u: any) => u.subscription === 'gold');

  // Filtrage
  let filteredUsers = realUsers;
  
  if (searchQuery) {
    filteredUsers = filteredUsers.filter((user: any) =>
      user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.city?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  if (regionFilter && regionFilter !== "all") {
    const regionCities = getCitiesByRegion(regionFilter);
    filteredUsers = filteredUsers.filter((user: any) => 
      regionCities.includes(user.city)
    );
  }

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE);
  const startIndex = (currentPage - 1) * USERS_PER_PAGE;
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + USERS_PER_PAGE);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Administration</h1>
          <p className="text-gray-600">Gestion des utilisateurs Date Mature</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Utilisateurs</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{realUsers.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Premium</CardTitle>
              <Star className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{premiumUsers.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Gold</CardTitle>
              <Crown className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{goldUsers.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taux Conversion</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {realUsers.length > 0 ? ((premiumUsers.length + goldUsers.length) / realUsers.length * 100).toFixed(1) : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mb-6 flex gap-2 flex-wrap">
          <Button onClick={downloadBackup} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Télécharger Backup
          </Button>
          <Button onClick={resetAllToGratuit} variant="destructive">
            Remettre tous en Gratuit
          </Button>
        </div>

        {/* Filtres */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 flex-wrap">
              <div className="flex-1 min-w-64">
                <Input
                  placeholder="Rechercher par nom, ville, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={regionFilter} onValueChange={setRegionFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Toutes les régions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes les régions</SelectItem>
                  {regions.map(region => (
                    <SelectItem key={region} value={region}>{region}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("");
                  setRegionFilter("all");
                  setCurrentPage(1);
                }}
              >
                Réinitialiser
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Liste des utilisateurs */}
        <Card>
          <CardHeader>
            <CardTitle>Utilisateurs ({filteredUsers.length} résultats)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {paginatedUsers.map((user: any) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                      {user.photo ? (
                        <img src={user.photo} alt={user.firstName} className="w-12 h-12 rounded-full object-cover" />
                      ) : (
                        <User className="h-6 w-6 text-gray-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{user.firstName}</p>
                      <p className="text-sm text-gray-600">{user.city} • {user.age} ans</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={user.gender === 'H' ? 'default' : 'secondary'}>
                      {user.gender === 'H' ? '♂️' : '♀️'}
                    </Badge>
                    <Badge variant={
                      user.subscription === 'gold' ? 'default' : 
                      user.subscription === 'premium' ? 'secondary' : 'outline'
                    }>
                      {user.subscription === 'gold' ? '👑' : 
                       user.subscription === 'premium' ? '⭐' : '🆓'}
                    </Badge>
                    
                    <div className="flex gap-1 ml-2">
                      {user.subscription === 'gratuit' && (
                        <Button size="sm" variant="outline" onClick={() => upgradeUser(user.id, 'premium')}>
                          ⭐ Premium
                        </Button>
                      )}
                      {user.subscription !== 'gold' && (
                        <Button size="sm" variant="outline" onClick={() => upgradeUser(user.id, 'gold')}>
                          👑 Gold
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" onClick={() => editUser(user)}>
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} sur {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}