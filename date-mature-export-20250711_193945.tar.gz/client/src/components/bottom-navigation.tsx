import { Link, useLocation } from "wouter";
import { Heart, MessageCircle, User, Gift } from "lucide-react";

interface BottomNavigationProps {
  unreadMessages?: number;
}

export default function BottomNavigation({ unreadMessages = 0 }: BottomNavigationProps) {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <div className="bg-white border-t border-gray-200 px-6 py-4">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`flex flex-col items-center space-y-1 ${
            isActive("/") ? "text-primary" : "text-gray-400"
          }`}>
            <Heart className="h-6 w-6" />
            <span className="text-sm font-medium">Découvrir</span>
          </a>
        </Link>
        
        <Link href="/messages">
          <a className={`flex flex-col items-center space-y-1 relative ${
            isActive("/messages") || isActive("/chat") ? "text-primary" : "text-gray-400"
          }`}>
            <MessageCircle className="h-6 w-6" />
            <span className="text-sm font-medium">Messages</span>
            {unreadMessages > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {unreadMessages}
              </span>
            )}
          </a>
        </Link>
        
        <Link href="/referral">
          <a className={`flex flex-col items-center space-y-1 ${
            isActive("/referral") ? "text-primary" : "text-gray-400"
          }`}>
            <Gift className="h-6 w-6" />
            <span className="text-sm font-medium">Parrainer</span>
          </a>
        </Link>
        
        <Link href="/profile">
          <a className={`flex flex-col items-center space-y-1 ${
            isActive("/profile") ? "text-primary" : "text-gray-400"
          }`}>
            <User className="h-6 w-6" />
            <span className="text-sm font-medium">Profil</span>
          </a>
        </Link>
      </div>
    </div>
  );
}
