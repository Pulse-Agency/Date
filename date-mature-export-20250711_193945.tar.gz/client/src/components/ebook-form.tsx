import React, { useState } from 'react';
import { X, BookOpen, Heart, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import mockupImage from '@assets/Mockup guide_1752135115680.png';

interface EbookFormProps {
  onClose: () => void;
  isVisible: boolean;
}

export default function EbookForm({ onClose, isVisible }: EbookFormProps) {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email, 
          firstName,
          source: 'footer_conseils',
          tags: ['ebook_guide', 'conseils_rencontres']
        })
      });

      if (!response.ok) {
        throw new Error('Erreur lors de l\'inscription');
      }

      setIsSubmitted(true);
      
      // Marquer comme souscrit pour éviter le popup automatique
      localStorage.setItem('newsletter-popup-subscribed', 'true');
      
      // Fermer après 3 secondes
      setTimeout(() => {
        onClose();
      }, 3000);
      
    } catch (error) {
      setError('Une erreur s\'est produite. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header avec mockup */}
        <div className="relative bg-gradient-to-br from-rose-500 to-pink-600 text-white p-6 rounded-t-2xl">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 transition-colors z-10"
          >
            <X className="h-6 w-6" />
          </button>
          
          <div className="flex items-center justify-between">
            {/* Texte à gauche */}
            <div className="flex-1 pr-6">
              <div className="flex items-center space-x-3 mb-3">
                <BookOpen className="h-8 w-8" />
                <Heart className="h-6 w-6 text-rose-200" />
              </div>
              
              <h2 className="text-xl font-bold mb-2">
                Redécouvrir le bonheur d'être aimé(e) après 40 ans
              </h2>
              <p className="text-rose-100 text-sm">
                Le guide complet pour retrouver l'amour authentique
              </p>
            </div>
            
            {/* Mockup à droite */}
            <div className="flex-shrink-0 hidden md:block">
              <img 
                src={mockupImage} 
                alt="Guide Amour Après 40 Ans" 
                className="h-40 w-auto object-contain"
              />
            </div>
          </div>
        </div>

        {/* Content avec layout horizontal */}
        <div className="p-6">
          {!isSubmitted ? (
            <div className="flex flex-col md:flex-row gap-6">
              {/* Benefits à gauche */}
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-4">Ce que vous découvrirez :</h3>
                <ul className="space-y-4 text-base text-gray-700">
                  <li className="flex items-start">
                    <span className="text-yellow-500 mr-3 mt-0.5 flex-shrink-0 text-lg">🌟</span>
                    <span><strong>Ce qui empêche d'aimer</strong> (sans le savoir)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-500 mr-3 mt-0.5 flex-shrink-0 text-lg">💬</span>
                    <span><strong>Dépasser ses blocages</strong> et oser une vraie rencontre</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-3 mt-0.5 flex-shrink-0 text-lg">❤️</span>
                    <span><strong>Créer un lien serein</strong>, sans refaire les mêmes erreurs</span>
                  </li>
                </ul>
                
                {/* Mockup mobile visible seulement sur mobile */}
                <div className="md:hidden mt-6 text-center">
                  <img 
                    src={mockupImage} 
                    alt="Guide Amour Après 40 Ans" 
                    className="h-32 w-auto mx-auto object-contain"
                  />
                </div>
              </div>

              {/* Form à droite */}
              <div className="flex-shrink-0 md:w-80">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="firstName" className="text-gray-700">Votre prénom</Label>
                    <Input
                      id="firstName"
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="Jean"
                      required
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-gray-700">Votre email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="jean@exemple.com"
                      required
                      className="mt-1"
                    />
                  </div>

                  {error && (
                    <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white py-3"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Envoi en cours...
                      </div>
                    ) : (
                      <>
                        <BookOpen className="h-4 w-4 mr-2" />
                        Recevoir le guide gratuit
                      </>
                    )}
                  </Button>
                </form>

                <p className="text-xs text-gray-500 mt-4 text-center">
                  Vos données sont protégées. Vous pouvez vous désinscrire à tout moment.
                </p>
              </div>
            </div>
          ) : (
            /* Success State */
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Merci {firstName} !
              </h3>
              <p className="text-gray-600 mb-4">
                Votre guide des rencontres matures vous attend dans votre boîte mail.
              </p>
              <p className="text-sm text-gray-500">
                Consultez également vos spams si vous ne le trouvez pas.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}