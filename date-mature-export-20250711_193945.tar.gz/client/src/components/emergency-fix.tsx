import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function EmergencyFix() {
  const { toast } = useToast();
  const [fixed, setFixed] = useState(false);

  useEffect(() => {
    if (!fixed) {
      // 1. FORCER la suppression popup newsletter
      localStorage.setItem('date_mature_newsletter_done', 'true');
      localStorage.setItem('newsletter_popup_dismissed_v2', 'true');
      localStorage.setItem('newsletter_subscribed', 'true');
      
      // 2. Vider complètement le cache
      if ('caches' in window) {
        caches.keys().then(names => {
          names.forEach(name => {
            caches.delete(name);
          });
        });
      }
      
      // 2. Générer manuellement des profils de test
      const generateProfile = async (name: string, age: number, city: string) => {
        const email = `admin+${name.toLowerCase().replace(' ', '')}@date-mature.com`;
        try {
          await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              firstName: name.split(' ')[0],
              lastName: name.split(' ')[1] || '',
              email,
              age,
              city,
              subscription: Math.random() > 0.5 ? 'premium' : 'gratuit',
              bio: `Bonjour, je suis ${name}, ${age} ans de ${city}. Je cherche une relation sincère.`,
              isTestProfile: true,
              photo: `https://images.unsplash.com/photo-${Math.floor(Math.random() * 10000000) + 1500000000000}/640x480?face&portrait`
            })
          });
        } catch (err) {
          console.error('Erreur création profil:', err);
        }
      };

      // Créer quelques profils de test
      const profiles = [
        ['Marie Dubois', 52, 'Paris'],
        ['Jean Martin', 58, 'Lyon'],
        ['Sophie Laurent', 45, 'Marseille'],
        ['Pierre Moreau', 61, 'Toulouse'],
        ['Anne Petit', 49, 'Nice']
      ];

      profiles.forEach(([name, age, city]) => {
        setTimeout(() => generateProfile(name as string, age as number, city as string), Math.random() * 1000);
      });

      setFixed(true);
      
      // 3. Forcer un rechargement complet après 3 secondes
      setTimeout(() => {
        toast({
          title: "Cache vidé - Page rechargée",
          description: "La popup a été supprimée définitivement",
        });
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      }, 3000);
    }
  }, [fixed, toast]);

  return null; // Composant invisible
}