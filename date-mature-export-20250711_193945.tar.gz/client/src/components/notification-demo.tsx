import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function NotificationDemo() {
  const triggerNotifications = () => {
    // Déclencher différents types de notifications
    if ((window as any).showNotifications) {
      const notifications = (window as any).showNotifications;
      
      // Match notification avec cœur qui vibre
      setTimeout(() => notifications.match("Sophie"), 500);
      
      // Flash notification
      setTimeout(() => notifications.flash("Marie"), 1500);
      
      // Message notification
      setTimeout(() => notifications.message("Claire"), 2500);
      
      // Visit notification
      setTimeout(() => notifications.visit("Françoise"), 3500);
      
      // Upgrade notification
      setTimeout(() => notifications.upgrade("Premium"), 4500);
    }
  };

  return (
    <Card className="max-w-md mx-auto mt-8">
      <CardHeader>
        <CardTitle className="text-center">🎉 Démonstration des Notifications</CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <p className="mb-4 text-gray-600">
          Testez les animations visuelles : cœur qui vibre pour les matches, éclair pour les flashs, etc.
        </p>
        <Button 
          onClick={triggerNotifications}
          className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600"
        >
          Déclencher les animations
        </Button>
      </CardContent>
    </Card>
  );
}