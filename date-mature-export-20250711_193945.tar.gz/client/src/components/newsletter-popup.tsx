import { useState, useEffect } from 'react';
import { X, Mail, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface NewsletterPopupProps {
  onClose: () => void;
  isVisible?: boolean;
}

export default function NewsletterPopup({ onClose, isVisible = true }: NewsletterPopupProps) {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !firstName) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir votre nom et email.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await apiRequest("POST", "/api/newsletter/subscribe", {
        email,
        firstName
      });
      
      if (response.ok) {
        toast({
          title: "🎉 Inscription réussie !",
          description: "Vérifiez votre email pour recevoir votre guide gratuit !",
        });
        
        // Sauvegarder l'inscription localement et marquer comme montré aujourd'hui
        localStorage.setItem('newsletter_subscribed', 'true');
        const today = new Date().toDateString();
        localStorage.setItem('newsletter_popup_last_shown', today);
        onClose();
      } else {
        const data = await response.json();
        toast({
          title: "Erreur d'inscription",
          description: data.message || "Une erreur est survenue.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-3 sm:p-4">
      <Card className="w-full max-w-sm sm:max-w-md mx-auto bg-gradient-to-br from-pink-50 to-purple-50 border-2 border-pink-200 shadow-2xl">
        <CardHeader className="relative text-center p-4 sm:p-6">
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-2 top-2 text-gray-500 hover:text-gray-700 h-8 w-8 p-0"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
          
          <div className="flex justify-center mb-3">
            <div className="bg-pink-100 p-2 sm:p-3 rounded-full">
              <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-pink-500" />
            </div>
          </div>
          
          <CardTitle className="text-lg sm:text-xl text-gray-800 leading-tight">
            🎁 Recevez votre guide gratuit !
          </CardTitle>
          <p className="text-gray-600 text-xs sm:text-sm mt-2 leading-relaxed">
            <strong>"7 secrets pour trouver l'amour après 40 ans"</strong><br/>
            + nos meilleurs conseils de rencontres seniors
          </p>
        </CardHeader>

        <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
          <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
            <div>
              <Label htmlFor="firstName" className="text-xs sm:text-sm font-medium text-gray-700">
                Votre prénom
              </Label>
              <Input
                id="firstName"
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="Votre prénom"
                className="mt-1 h-10 sm:h-11 text-sm"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="text-xs sm:text-sm font-medium text-gray-700">
                Votre email
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                className="mt-1 h-10 sm:h-11 text-sm"
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-pink-500 hover:bg-pink-600 text-white font-semibold py-2 sm:py-3 px-4 rounded-lg transition-colors text-sm sm:text-base"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Inscription...
                </>
              ) : (
                <>
                  <Mail className="h-4 w-4 mr-2" />
                  Recevoir mon guide gratuit
                </>
              )}
            </Button>
          </form>
          
          <p className="text-xs text-gray-500 text-center leading-relaxed">
            Pas de spam, désinscription en 1 clic. Vos données sont sécurisées.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}