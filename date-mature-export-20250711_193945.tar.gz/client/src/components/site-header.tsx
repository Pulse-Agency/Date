import { Heart, Bell, Zap, Users, Mail, Crown, User } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface SiteHeaderProps {
  showBackToHome?: boolean;
}

export default function SiteHeader({ showBackToHome = true }: SiteHeaderProps) {
  // Get current user data for display
  const { data: userData } = useQuery({
    queryKey: ["/api/users/current"],
  });

  const user = userData?.user;

  // Get user stats for counters
  const { data: statsData } = useQuery({
    queryKey: ["/api/users/stats"],
  });

  const flashsUsed = statsData?.flashsUsed || 0;
  const flashsLimit = user?.subscriptionTier === 'gold' ? 'unlimited' : 
                     user?.subscriptionTier === 'premium' ? 20 : 3;
  const flashsRemaining = flashsLimit === 'unlimited' ? 'unlimited' : 
                         Math.max(0, flashsLimit - flashsUsed);

  const unreadMessages = statsData?.unreadMessages || 0;
  const newMatches = statsData?.newMatches || 0;

  return (
    <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-2">
        {/* Top row with logo and account */}
        <div className="flex items-center justify-between mb-2">
          {showBackToHome ? (
            <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
              <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-1.5 rounded-full">
                <Heart className="h-5 w-5 text-white fill-current" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Date Mature</h1>
              </div>
            </Link>
          ) : (
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-1.5 rounded-full">
                <Heart className="h-5 w-5 text-white fill-current" />
              </div>
              <h1 className="text-lg font-bold text-gray-900">Date Mature</h1>
            </div>
          )}

          <div className="flex items-center space-x-2">
            {user?.subscriptionTier !== 'free' && (
              <Badge variant="secondary" className="text-xs">
                {user?.subscriptionTier === 'gold' ? (
                  <><Crown className="h-3 w-3 mr-1" />Gold</>
                ) : (
                  <><Crown className="h-3 w-3 mr-1" />Premium</>
                )}
              </Badge>
            )}
            <Link href="/subscription">
              <Button variant="outline" size="sm" className="text-xs">
                S'ABONNER
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Bottom row with stats */}
        <div className="flex items-center justify-center space-x-6 text-sm">
          <Link href="/messages" className="flex flex-col items-center space-y-1 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Bell className="h-5 w-5 text-blue-500" />
              {unreadMessages > 0 && (
                <Badge className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs bg-blue-500 flex items-center justify-center">
                  {unreadMessages}
                </Badge>
              )}
            </div>
            <span className="text-xs text-blue-500 font-medium">Alertes</span>
          </Link>

          <Link href="/profiles" className="flex flex-col items-center space-y-1 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Users className="h-5 w-5 text-gray-500" />
            </div>
            <span className="text-xs text-gray-500">Affinités</span>
          </Link>

          <Link href="/home" className="flex flex-col items-center space-y-1 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Zap className="h-5 w-5 text-pink-500" />
              {flashsRemaining !== 'unlimited' && (
                <Badge className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs bg-pink-500 flex items-center justify-center">
                  {flashsRemaining}
                </Badge>
              )}
            </div>
            <span className="text-xs text-pink-500 font-medium">Flashs</span>
            <span className="text-xs text-gray-400">
              {flashsRemaining === 'unlimited' ? '∞' : flashsRemaining}
            </span>
          </Link>

          <Link href="/messages" className="flex flex-col items-center space-y-1 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Heart className="h-5 w-5 text-purple-500" />
              {newMatches > 0 && (
                <Badge className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs bg-purple-500 flex items-center justify-center">
                  {newMatches}
                </Badge>
              )}
            </div>
            <span className="text-xs text-purple-500">Visites</span>
          </Link>

          <Link href="/messages" className="flex flex-col items-center space-y-1 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Mail className="h-5 w-5 text-green-500" />
              {unreadMessages > 0 && (
                <Badge className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs bg-red-500 flex items-center justify-center">
                  {unreadMessages}
                </Badge>
              )}
            </div>
            <span className="text-xs text-green-500">Messages</span>
            <span className="text-xs text-gray-400">{unreadMessages}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}