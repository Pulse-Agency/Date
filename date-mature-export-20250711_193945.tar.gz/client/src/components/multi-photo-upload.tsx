import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Plus, Camera } from 'lucide-react';

interface MultiPhotoUploadProps {
  onPhotosChange: (photos: string[]) => void;
  currentPhotos?: string[];
  maxPhotos?: number;
  className?: string;
}

export default function MultiPhotoUpload({ 
  onPhotosChange, 
  currentPhotos = [], 
  maxPhotos = 6,
  className = "" 
}: MultiPhotoUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [photos, setPhotos] = useState<string[]>(currentPhotos);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Synchroniser avec les photos actuelles quand elles changent
  useEffect(() => {
    console.log('MultiPhotoUpload - Photos reçues:', currentPhotos);
    console.log('MultiPhotoUpload - Photos actuelles état:', photos);
    setPhotos(currentPhotos || []);
  }, [currentPhotos]);

  // Notifier le parent quand les photos changent
  useEffect(() => {
    console.log('MultiPhotoUpload - Notification parent:', photos);
    onPhotosChange(photos);
  }, [photos, onPhotosChange]);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    if (photos.length + files.length > maxPhotos) {
      toast({
        title: "Limite atteinte",
        description: `Vous ne pouvez ajouter que ${maxPhotos} photos maximum.`,
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      const newPhotos = [...photos];
      
      for (const file of Array.from(files)) {
        // Validation du fichier
        if (!file.type.startsWith('image/')) {
          toast({
            title: "Format invalide",
            description: "Seules les images sont acceptées.",
            variant: "destructive",
          });
          continue;
        }

        if (file.size > 5 * 1024 * 1024) { // 5MB
          toast({
            title: "Fichier trop volumineux",
            description: "La taille maximum est de 5MB par photo.",
            variant: "destructive",
          });
          continue;
        }

        // Compression de l'image
        const compressedFile = await compressImage(file);
        
        // Upload vers le serveur
        const formData = new FormData();
        formData.append('photo', compressedFile);

        const response = await fetch('/api/upload/photo', {
          method: 'POST',
          body: formData,
        });

        if (response.ok) {
          const result = await response.json();
          newPhotos.push(result.url);
        } else {
          throw new Error('Erreur lors de l\'upload');
        }
      }

      setPhotos(newPhotos);
      onPhotosChange(newPhotos);
      
      toast({
        title: "Photos ajoutées",
        description: `${newPhotos.length - photos.length} photo(s) ajoutée(s) avec succès.`,
      });
    } catch (error) {
      console.error('Erreur upload:', error);
      toast({
        title: "Erreur d'upload",
        description: "Une erreur est survenue lors de l'upload des photos.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        // Redimensionner l'image (max 800x800)
        const maxSize = 800;
        let { width, height } = img;
        
        if (width > height) {
          if (width > maxSize) {
            height = (height * maxSize) / width;
            width = maxSize;
          }
        } else {
          if (height > maxSize) {
            width = (width * maxSize) / height;
            height = maxSize;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        ctx?.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const compressedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        }, 'image/jpeg', 0.8);
      };
      
      img.src = URL.createObjectURL(file);
    });
  };

  const removePhoto = (index: number) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    setPhotos(newPhotos);
    onPhotosChange(newPhotos);
    
    toast({
      title: "Photo supprimée",
      description: "La photo a été supprimée de votre profil.",
    });
  };

  const reorderPhotos = (fromIndex: number, toIndex: number) => {
    const newPhotos = [...photos];
    const [movedPhoto] = newPhotos.splice(fromIndex, 1);
    newPhotos.splice(toIndex, 0, movedPhoto);
    setPhotos(newPhotos);
    onPhotosChange(newPhotos);
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />
      
      {/* Grille des photos */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {photos.map((photo, index) => (
          <div key={index} className="relative group">
            <div className="aspect-square rounded-lg overflow-hidden border-2 border-gray-200 bg-gray-50">
              <img 
                src={photo} 
                alt={`Photo ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Badge numéro */}
            <div className="absolute top-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
              {index + 1}
            </div>
            
            {/* Bouton supprimer */}
            <Button
              type="button"
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2 h-6 w-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={() => removePhoto(index)}
              disabled={uploading}
            >
              <X className="h-3 w-3" />
            </Button>
            
            {/* Indicateur photo principale */}
            {index === 0 && (
              <div className="absolute bottom-2 left-2 bg-rose-500 text-white text-xs px-2 py-1 rounded">
                Photo principale
              </div>
            )}
          </div>
        ))}
        
        {/* Bouton d'ajout */}
        {photos.length < maxPhotos && (
          <div 
            className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-rose-400 transition-colors bg-gray-50"
            onClick={() => fileInputRef.current?.click()}
          >
            {uploading ? (
              <div className="flex flex-col items-center space-y-2">
                <div className="animate-spin w-6 h-6 border-2 border-rose-500 border-t-transparent rounded-full" />
                <span className="text-xs text-gray-600">Upload...</span>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-2">
                <Plus className="h-8 w-8 text-gray-400" />
                <span className="text-xs text-gray-600 text-center px-2">
                  Ajouter une photo
                </span>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Informations */}
      <div className="text-sm text-gray-600 space-y-1">
        <p>
          <Camera className="inline w-4 h-4 mr-1" />
          {photos.length}/{maxPhotos} photos
        </p>
        <p className="text-xs text-gray-500">
          • La première photo sera votre photo principale
          • Formats acceptés : JPG, PNG (max 5MB par photo)
          • Recommandé : 3-6 photos variées pour un profil attractif
        </p>
      </div>
    </div>
  );
}