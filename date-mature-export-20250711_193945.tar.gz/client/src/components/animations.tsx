import { useEffect, useState } from "react";
import { Heart, Star, Crown, Sparkles } from "lucide-react";

interface MatchAnimationProps {
  isVisible: boolean;
  onComplete: () => void;
}

export function MatchAnimation({ isVisible, onComplete }: MatchAnimationProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onComplete, 3000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative">
        {/* Confettis animés */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${1 + Math.random()}s`,
              }}
            >
              <div className={`w-2 h-2 rounded-full ${
                i % 4 === 0 ? 'bg-pink-400' :
                i % 4 === 1 ? 'bg-red-400' :
                i % 4 === 2 ? 'bg-purple-400' : 'bg-yellow-400'
              }`} />
            </div>
          ))}
        </div>

        {/* Cœurs vibrants */}
        <div className="bg-white rounded-2xl p-8 shadow-2xl text-center max-w-sm mx-4">
          <div className="relative mb-6">
            <Heart 
              className="h-16 w-16 text-red-500 mx-auto animate-pulse" 
              fill="currentColor"
            />
            <Heart 
              className="h-12 w-12 text-pink-400 absolute top-2 left-1/2 transform -translate-x-1/2 animate-bounce" 
              fill="currentColor"
              style={{ animationDelay: '0.5s' }}
            />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            🎉 C'est un match !
          </h2>
          <p className="text-gray-600">
            L'attraction est réciproque !
          </p>
          
          {/* Étoiles scintillantes */}
          <div className="flex justify-center mt-4 space-x-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Sparkles
                key={i}
                className="h-4 w-4 text-yellow-400 animate-pulse"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

interface UpgradeAnimationProps {
  isVisible: boolean;
  plan: 'premium' | 'gold';
  onComplete: () => void;
}

export function UpgradeAnimation({ isVisible, plan, onComplete }: UpgradeAnimationProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onComplete, 4000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  const isPremium = plan === 'premium';
  const bgColor = isPremium ? 'from-purple-600 to-purple-800' : 'from-yellow-500 to-yellow-700';
  const textColor = 'text-white';
  const icon = isPremium ? Star : Crown;
  const IconComponent = icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative">
        {/* Étoiles dorées animées pour Gold, violettes pour Premium */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 15 }).map((_, i) => (
            <div
              key={i}
              className="absolute animate-ping"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random()}s`,
              }}
            >
              <Star 
                className={`h-3 w-3 ${isPremium ? 'text-purple-300' : 'text-yellow-300'}`}
                fill="currentColor"
              />
            </div>
          ))}
        </div>

        {/* Card de félicitations */}
        <div className={`bg-gradient-to-br ${bgColor} rounded-2xl p-8 shadow-2xl text-center max-w-sm mx-4 ${textColor}`}>
          <div className="relative mb-6">
            <IconComponent 
              className="h-16 w-16 mx-auto animate-bounce" 
              fill="currentColor"
            />
            <div className="absolute inset-0 animate-ping">
              <IconComponent 
                className="h-16 w-16 mx-auto opacity-30" 
                fill="currentColor"
              />
            </div>
          </div>
          
          <h2 className="text-2xl font-bold mb-2">
            🎊 Félicitations !
          </h2>
          <p className="text-lg font-semibold mb-2">
            Vous êtes maintenant {isPremium ? 'Premium' : 'Gold'} !
          </p>
          <p className="text-sm opacity-90">
            {isPremium 
              ? 'Profitez de 20 flashs par jour et de fonctionnalités exclusives !'
              : 'Flashs illimités, mode incognito et priorité maximale !'
            }
          </p>
          
          {/* Animation de sparkle */}
          <div className="flex justify-center mt-4">
            <div className="relative">
              <Sparkles className="h-8 w-8 animate-spin" />
              <div className="absolute inset-0 animate-pulse">
                <Sparkles className="h-8 w-8 opacity-50" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface FlashSuccessAnimationProps {
  isVisible: boolean;
  onComplete: () => void;
}

export function FlashSuccessAnimation({ isVisible, onComplete }: FlashSuccessAnimationProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onComplete, 1500);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center pointer-events-none">
      <div className="relative">
        <Heart 
          className="h-20 w-20 text-red-500 animate-ping" 
          fill="currentColor"
        />
        <Heart 
          className="h-20 w-20 text-red-500 absolute inset-0 animate-pulse" 
          fill="currentColor"
        />
      </div>
    </div>
  );
}