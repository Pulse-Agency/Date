import { useState, useEffect } from "react";
import { Heart, Zap, Users, Mail, Crown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface NotificationEvent {
  id: string;
  type: 'match' | 'flash' | 'message' | 'visit' | 'upgrade';
  title: string;
  message: string;
  color: string;
  duration?: number;
}

// Animation du cœur qui vibre pour un match
const HeartPulse = ({ color = "#ff6b9d" }: { color?: string }) => (
  <motion.div
    animate={{
      scale: [1, 1.2, 1, 1.1, 1],
      rotate: [0, -5, 5, -3, 0],
    }}
    transition={{
      duration: 0.8,
      repeat: 3,
      ease: "easeInOut"
    }}
    style={{ color }}
  >
    <Heart className="h-8 w-8 fill-current" />
  </motion.div>
);

// Animation de l'éclair pour les flashs
const FlashAnimation = ({ color = "#f39c12" }: { color?: string }) => (
  <motion.div
    animate={{
      scale: [0.8, 1.3, 0.9, 1.1, 1],
      opacity: [0.7, 1, 0.8, 1, 0.9],
    }}
    transition={{
      duration: 0.6,
      repeat: 2,
      ease: "easeOut"
    }}
    style={{ color }}
  >
    <Zap className="h-8 w-8 fill-current" />
  </motion.div>
);

const getAnimatedIcon = (type: NotificationEvent['type'], color: string) => {
  switch (type) {
    case 'match':
      return <HeartPulse color={color} />;
    case 'flash':
      return <FlashAnimation color={color} />;
    case 'message':
      return <Mail className="h-8 w-8" style={{ color }} />;
    case 'upgrade':
      return <Crown className="h-8 w-8 fill-current" style={{ color }} />;
    case 'visit':
      return <Users className="h-8 w-8" style={{ color }} />;
    default:
      return <Heart className="h-8 w-8" style={{ color }} />;
  }
};

const NotificationToast = ({ 
  event, 
  onComplete 
}: { 
  event: NotificationEvent; 
  onComplete: () => void; 
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, event.duration || 4000);

    return () => clearTimeout(timer);
  }, [event.duration, onComplete]);

  return (
    <motion.div
      initial={{ x: 300, opacity: 0, scale: 0.8 }}
      animate={{ x: 0, opacity: 1, scale: 1 }}
      exit={{ x: 300, opacity: 0, scale: 0.8 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="bg-white rounded-xl shadow-lg border border-gray-100 p-4 mb-3 max-w-sm"
      style={{ borderLeft: `4px solid ${event.color}` }}
    >
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 mt-1">
          {getAnimatedIcon(event.type, event.color)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-gray-900 mb-1">
            {event.title}
          </p>
          <p className="text-sm text-gray-600">
            {event.message}
          </p>
        </div>
      </div>
      
      <motion.div
        className="mt-3 h-1 bg-gray-100 rounded-full overflow-hidden"
      >
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: event.color }}
          initial={{ width: "100%" }}
          animate={{ width: "0%" }}
          transition={{ duration: (event.duration || 4000) / 1000, ease: "linear" }}
        />
      </motion.div>
    </motion.div>
  );
};

export default function SimpleNotifications({ 
  events, 
  onEventComplete 
}: { 
  events: NotificationEvent[];
  onEventComplete: (id: string) => void;
}) {
  return (
    <div className="fixed top-20 right-4 z-50 pointer-events-none">
      <AnimatePresence>
        {events.map((event) => (
          <NotificationToast
            key={event.id}
            event={event}
            onComplete={() => onEventComplete(event.id)}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

// Hook pour gérer les notifications
export const useNotificationEvents = () => {
  const [events, setEvents] = useState<NotificationEvent[]>([]);

  const addNotification = (notification: Omit<NotificationEvent, 'id'>) => {
    const id = `notification-${Date.now()}-${Math.random()}`;
    setEvents(prev => [...prev, { ...notification, id }]);
  };

  const removeNotification = (id: string) => {
    setEvents(prev => prev.filter(event => event.id !== id));
  };

  const showMatchNotification = (matchName: string) => {
    addNotification({
      type: 'match',
      title: '🎉 Nouveau match !',
      message: `Vous avez matché avec ${matchName} !`,
      color: '#e91e63',
      duration: 5000
    });
  };

  const showFlashNotification = (flasherName: string) => {
    addNotification({
      type: 'flash',
      title: '⚡ Nouveau flash !',
      message: `${flasherName} vous a flashé !`,
      color: '#f39c12',
      duration: 4000
    });
  };

  const showMessageNotification = (senderName: string) => {
    addNotification({
      type: 'message',
      title: '💬 Nouveau message',
      message: `${senderName} vous a envoyé un message`,
      color: '#3498db',
      duration: 4000
    });
  };

  const showVisitNotification = (visitorName: string) => {
    addNotification({
      type: 'visit',
      title: '👁️ Visite de profil',
      message: `${visitorName} a visité votre profil`,
      color: '#9b59b6',
      duration: 3000
    });
  };

  const showUpgradeNotification = (planName: string) => {
    addNotification({
      type: 'upgrade',
      title: '👑 Abonnement activé !',
      message: `Votre abonnement ${planName} est maintenant actif`,
      color: '#f1c40f',
      duration: 6000
    });
  };

  return {
    events,
    removeNotification,
    showMatchNotification,
    showFlashNotification,
    showMessageNotification,
    showVisitNotification,
    showUpgradeNotification
  };
};

// Animation plein écran pour les matches
export const MatchAnimation = ({ 
  isVisible, 
  matchName, 
  onComplete 
}: { 
  isVisible: boolean; 
  matchName: string; 
  onComplete: () => void; 
}) => {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onComplete, 3000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="bg-white rounded-2xl p-8 text-center max-w-sm mx-4"
          >
            <div className="mb-6">
              <motion.div
                animate={{
                  scale: [1, 1.3, 1, 1.2, 1],
                  rotate: [0, -10, 10, -5, 0],
                }}
                transition={{
                  duration: 1,
                  repeat: 2,
                  ease: "easeInOut"
                }}
                className="text-6xl text-pink-500 mx-auto w-fit"
              >
                💖
              </motion.div>
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              C'est un match !
            </h2>
            <p className="text-gray-600 mb-6">
              Vous et {matchName} vous êtes mutuellement flashés
            </p>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onComplete}
              className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-6 py-3 rounded-full font-semibold"
            >
              Commencer la conversation
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};