import { Heart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { User } from "@shared/schema";

interface MatchNotificationProps {
  matchedUser: User;
  onContinue: () => void;
  onSendMessage: () => void;
}

export default function MatchNotification({ 
  matchedUser, 
  onContinue, 
  onSendMessage 
}: MatchNotificationProps) {
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="bg-white rounded-3xl p-8 mx-6 text-center max-w-sm">
        <div className="relative mb-6">
          <Heart className="h-16 w-16 text-red-500 mx-auto animate-pulse" />
          <div className="absolute -top-2 -right-2">
            <Star className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
        
        <h3 className="text-2xl font-bold text-gray-800 mb-2">C'est un match !</h3>
        <p className="text-gray-600 mb-6 text-lg">
          Vous et <span className="font-semibold">{matchedUser.firstName}</span> vous êtes plu mutuellement
        </p>
        
        <div className="flex space-x-4">
          <Button
            variant="outline"
            className="flex-1 py-3 px-6 text-lg"
            onClick={onContinue}
          >
            Continuer
          </Button>
          <Button
            className="flex-1 bg-primary hover:bg-primary/90 py-3 px-6 text-lg"
            onClick={onSendMessage}
          >
            Envoyer un message
          </Button>
        </div>
      </div>
    </div>
  );
}
