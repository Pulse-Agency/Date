import React from 'react';
import { Zap, Crown, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface FlashExhaustedNotificationProps {
  userPlan: 'gratuit' | 'premium' | 'gold';
  onOpenFlashBonus: () => void;
}

export default function FlashExhaustedNotification({ 
  userPlan, 
  onOpenFlashBonus 
}: FlashExhaustedNotificationProps) {
  const { toast } = useToast();

  const showFlashExhaustedToast = () => {
    if (userPlan === 'gratuit') {
      toast({
        title: "Flashs épuisés",
        description: "Passez Premium pour plus de flashs quotidiens !",
        action: (
          <Button 
            size="sm" 
            className="bg-rose-500 hover:bg-rose-600"
            onClick={() => window.location.href = '/subscription'}
          >
            <Crown className="h-3 w-3 mr-1" />
            Premium
          </Button>
        ),
        duration: 5000,
      });
    } else {
      toast({
        title: "Flashs épuisés",
        description: "Utilisez des flashs bonus pour continuer !",
        action: (
          <Button 
            size="sm" 
            className="bg-rose-500 hover:bg-rose-600"
            onClick={onOpenFlashBonus}
          >
            <Zap className="h-3 w-3 mr-1" />
            Bonus
          </Button>
        ),
        duration: 5000,
      });
    }
  };

  return { showFlashExhaustedToast };
}

// Hook pour utiliser facilement la notification
export function useFlashExhaustedNotification(userPlan: 'gratuit' | 'premium' | 'gold', onOpenFlashBonus: () => void) {
  const { toast } = useToast();

  const showFlashExhaustedToast = () => {
    if (userPlan === 'gratuit') {
      toast({
        title: "Flashs épuisés pour aujourd'hui",
        description: "Passez Premium pour 20 flashs par jour !",
        action: (
          <Button 
            size="sm" 
            className="bg-rose-500 hover:bg-rose-600"
            onClick={() => window.location.href = '/subscription'}
          >
            <Crown className="h-3 w-3 mr-1" />
            Premium
          </Button>
        ),
        duration: 6000,
      });
    } else {
      toast({
        title: "Flashs quotidiens épuisés",
        description: "Continuez avec des flashs bonus !",
        action: (
          <Button 
            size="sm" 
            className="bg-rose-500 hover:bg-rose-600"
            onClick={onOpenFlashBonus}
          >
            <Zap className="h-3 w-3 mr-1" />
            Flashs Bonus
          </Button>
        ),
        duration: 6000,
      });
    }
  };

  return { showFlashExhaustedToast };
}