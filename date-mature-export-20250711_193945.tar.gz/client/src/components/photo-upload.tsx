import { useState, useRef } from 'react';
import { Upload, X, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

// Fonction de compression d'image pour optimiser les performances
const compressImage = (file: File): Promise<File | null> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = document.createElement('img');
    
    img.onload = () => {
      // Redimensionner pour optimiser (max 800x600 pour les profils)
      const maxWidth = 800;
      const maxHeight = 600;
      let { width, height } = img;
      
      if (width > height) {
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }
      }
      
      canvas.width = width;
      canvas.height = height;
      
      ctx?.drawImage(img, 0, 0, width, height);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const compressedFile = new File([blob], file.name, {
            type: 'image/jpeg',
            lastModified: Date.now()
          });
          resolve(compressedFile);
        } else {
          resolve(null);
        }
      }, 'image/jpeg', 0.8); // 80% qualité pour un bon compromis
    };
    
    img.src = URL.createObjectURL(file);
  });
};

interface PhotoUploadProps {
  onPhotoSelected: (photoUrl: string) => void;
  currentPhoto?: string;
  className?: string;
}

export default function PhotoUpload({ onPhotoSelected, currentPhoto, className = "" }: PhotoUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string>(currentPhoto || '');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validation
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner une image",
        variant: "destructive",
      });
      return;
    }

    // Compression de l'image pour optimiser les performances
    const compressedFile = await compressImage(file);
    const finalFile = compressedFile || file;

    if (finalFile.size > 5 * 1024 * 1024) {
      toast({
        title: "Erreur",
        description: "L'image ne peut pas dépasser 5MB",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      // Prévisualisation locale avec l'image compressée
      const localPreview = URL.createObjectURL(finalFile);
      setPreviewUrl(localPreview);

      // Upload vers le serveur avec l'image optimisée
      const formData = new FormData();
      formData.append('photo', finalFile);

      const response = await fetch('/api/upload/photo', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Erreur lors de l\'upload');
      }

      const data = await response.json();
      
      // Nettoyer l'URL locale et utiliser l'URL du serveur
      URL.revokeObjectURL(localPreview);
      setPreviewUrl(data.url);
      onPhotoSelected(data.url);

      toast({
        title: "Photo uploadée",
        description: "Votre photo a été mise en ligne avec succès",
      });

    } catch (error) {
      console.error('Upload error:', error);
      setPreviewUrl(currentPhoto || '');
      toast({
        title: "Erreur d'upload",
        description: "Impossible de télécharger la photo. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = () => {
    setPreviewUrl('');
    onPhotoSelected('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
        disabled={uploading}
      />

      {previewUrl ? (
        <div className="relative">
          <div className="w-32 h-32 rounded-lg overflow-hidden border-2 border-gray-200">
            <img 
              src={previewUrl} 
              alt="Photo de profil" 
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
            onClick={removePhoto}
            disabled={uploading}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      ) : (
        <div 
          className="w-40 h-40 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-pink-400 transition-colors bg-gray-50"
          onClick={() => fileInputRef.current?.click()}
        >
          {uploading ? (
            <div className="flex flex-col items-center space-y-2">
              <div className="animate-spin w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full" />
              <span className="text-sm text-gray-600">Téléchargement...</span>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-2">
              <Upload className="h-10 w-10 text-gray-400" />
              <span className="text-sm text-gray-600 text-center px-2 font-medium">
                Cliquez pour ajouter une photo
              </span>
            </div>
          )}
        </div>
      )}

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          size="lg"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="flex items-center space-x-2 px-6 py-3 text-base font-medium border-2 hover:bg-pink-50 hover:border-pink-300"
        >
          <Image className="h-5 w-5" />
          <span>Choisir une photo</span>
        </Button>
      </div>
      
      <p className="text-xs text-gray-500">
        Formats acceptés: JPG, PNG, GIF (max 5MB)
      </p>
    </div>
  );
}