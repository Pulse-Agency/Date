import { X, Zap, Crown, Star, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { User } from "@shared/schema";

interface ProfileCardProps {
  user: User;
  onFlash: () => void;
  onPass: () => void;
  canFlash: boolean;
  style?: React.CSSProperties;
  className?: string;
}

export default function ProfileCard({ 
  user, 
  onFlash, 
  onPass, 
  canFlash, 
  style,
  className = "" 
}: ProfileCardProps) {
  const getSubscriptionBadge = () => {
    if (user.subscription === 'gold') {
      return (
        <Badge className="bg-yellow-500 text-white hover:bg-yellow-600">
          <Crown className="h-3 w-3 mr-1" />
          Gold
        </Badge>
      );
    }
    if (user.subscription === 'premium') {
      return (
        <Badge className="bg-purple-600 text-white hover:bg-purple-700">
          <Star className="h-3 w-3 mr-1" />
          Premium
        </Badge>
      );
    }
    return null;
  };

  const getGlowClass = () => {
    if (user.subscription === 'gold') return 'gold-glow';
    if (user.subscription === 'premium') return 'premium-glow';
    return '';
  };

  return (
    <div 
      className={`bg-white rounded-3xl shadow-xl card-swipe ${getGlowClass()} ${className}`}
      style={style}
    >
      {/* Subscription Badge */}
      <div className="absolute top-4 right-4 z-10">
        {getSubscriptionBadge()}
      </div>
      
      {/* Profile Image */}
      <div 
        className="h-3/5 rounded-t-3xl bg-cover bg-center relative"
        style={{ backgroundImage: `url(${user.photo})` }}
      >
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6 rounded-t-3xl">
          <h3 className="text-white text-2xl font-bold">
            {user.firstName}, {user.age} ans {(user as any).gender && `(${(user as any).gender})`}
          </h3>
          <p className="text-white/90 text-lg flex items-center">
            <MapPin className="h-5 w-5 mr-1" />
            {user.city}
          </p>
        </div>
      </div>
      
      {/* Profile Info */}
      <div className="p-6 h-2/5 flex flex-col">
        <p className="text-gray-700 text-lg leading-relaxed mb-4 flex-grow">
          {user.bio}
        </p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {user.interests?.map((interest, index) => (
            <Badge key={index} variant="secondary" className="bg-pink-100 text-primary">
              {interest}
            </Badge>
          ))}
        </div>
        
        {/* Action Buttons */}
        <div className="flex justify-center space-x-6 mt-auto">
          <Button
            variant="outline"
            size="lg"
            className="w-16 h-16 rounded-full border-2"
            onClick={onPass}
          >
            <X className="h-6 w-6 text-gray-500" />
          </Button>
          <Button
            size="lg"
            className="w-16 h-16 rounded-full bg-primary hover:bg-primary/90"
            onClick={onFlash}
            disabled={!canFlash}
          >
            <Zap className="h-6 w-6 text-white" />
          </Button>
        </div>
      </div>
    </div>
  );
}
