import { useState, useEffect } from "react";
import { Crown, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface SocialProofNotificationProps {
  onClose: () => void;
  isVisible: boolean;
}

// Messages de social proof pour les matures et seniors
const socialProofMessages = [
  { name: "Marie", age: 52, plan: "Premium", city: "Lyon" },
  { name: "Pierre", age: 58, plan: "Gold", city: "Marseille" },
  { name: "Françoise", age: 49, plan: "Premium", city: "Toulouse" },
  { name: "Jacques", age: 61, plan: "Gold", city: "Nice" },
  { name: "Annie", age: 55, plan: "Premium", city: "Bordeaux" },
  { name: "Robert", age: 53, plan: "Gold", city: "Nantes" },
  { name: "Sylvie", age: 47, plan: "Premium", city: "Strasbourg" },
  { name: "Michel", age: 59, plan: "Gold", city: "Lille" }
];

export default function SocialProofNotification({ onClose, isVisible }: SocialProofNotificationProps) {
  const [currentMessage, setCurrentMessage] = useState(socialProofMessages[0]);

  useEffect(() => {
    if (isVisible) {
      // Sélectionne un message aléatoirement
      const randomMessage = socialProofMessages[Math.floor(Math.random() * socialProofMessages.length)];
      setCurrentMessage(randomMessage);

      // Auto-ferme après 8 secondes
      const timer = setTimeout(() => {
        onClose();
      }, 8000);

      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 animate-in slide-in-from-left-5 duration-500">
      <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-sm">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-red-400 rounded-full flex items-center justify-center">
                <Crown className="h-5 w-5 text-white" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900">
                {currentMessage.name}, {currentMessage.age} ans
              </p>
              <p className="text-xs text-gray-600">
                {currentMessage.city}
              </p>
              <p className="text-sm text-gray-700 mt-1">
                vient de passer {currentMessage.plan} !
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex-shrink-0 ml-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        
        <div className="mt-3 pt-3 border-t border-gray-100">
          <Link href="/subscription">
            <Button 
              size="sm" 
              className="w-full bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white"
              onClick={onClose}
            >
              <Crown className="h-4 w-4 mr-2" />
              Découvrir {currentMessage.plan}
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}