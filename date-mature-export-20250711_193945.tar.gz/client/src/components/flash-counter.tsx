import { Zap } from "lucide-react";

interface FlashCounterProps {
  remaining: number | 'unlimited';
  limit: number | 'unlimited';
  used: number;
}

export default function FlashCounter({ remaining, limit, used }: FlashCounterProps) {
  const isUnlimited = remaining === 'unlimited';
  
  return (
    <div className="bg-gradient-to-r from-pink-50 to-orange-50 p-4 border-b border-gray-100">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Zap className="h-5 w-5 text-secondary mr-2" />
          <span className="font-medium text-lg">Flashs restants aujourd'hui</span>
        </div>
        <div className="flex items-center space-x-2">
          {!isUnlimited && (
            <div className="flex space-x-1">
              {Array.from({ length: limit as number }, (_, i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-full ${
                    i < (remaining as number) ? 'bg-secondary' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          )}
          <span className="text-sm font-semibold">
            {isUnlimited ? '∞' : `${remaining}/${limit}`}
          </span>
        </div>
      </div>
    </div>
  );
}
