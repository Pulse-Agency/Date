import React, { useState } from 'react';
import { X, Zap, Crown, Star, Heart, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FlashBonusModalProps {
  onClose: () => void;
  isVisible: boolean;
  userPlan: 'gratuit' | 'premium' | 'gold';
  remainingFlashes: number;
}

export default function FlashBonusModal({ onClose, isVisible, userPlan, remainingFlashes }: FlashBonusModalProps) {
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const handlePurchase = async () => {
    setIsLoading(true);
    try {
      // Simulation d'achat
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Ici on appellerait l'API Stripe
      console.log('Achat:', selectedOption);
      
      onClose();
    } catch (error) {
      console.error('Erreur achat:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isVisible) return null;

  const flashBonusOptions = [
    {
      id: 'pack-50',
      title: 'Pack 50 Flashs',
      price: '5€',
      description: 'Valables 30 jours',
      icon: <Zap className="h-6 w-6" />,
      color: 'from-blue-500 to-indigo-600',
      available: userPlan === 'premium'
    },
    {
      id: 'super-flash',
      title: 'Super Flash',
      price: '2€',
      description: 'Profil en première position 1h',
      icon: <Star className="h-6 w-6" />,
      color: 'from-yellow-500 to-orange-600',
      available: userPlan === 'gold'
    },
    {
      id: 'boost-profile',
      title: 'Mise en avant',
      price: '10€',
      description: 'Profil prioritaire 24h',
      icon: <Crown className="h-6 w-6" />,
      color: 'from-purple-500 to-pink-600',
      available: true
    }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-rose-500 to-pink-600 text-white p-6 rounded-t-2xl">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
          
          <div className="flex items-center space-x-3 mb-3">
            <Heart className="h-8 w-8" />
            <Zap className="h-6 w-6 text-rose-200" />
          </div>
          
          <h2 className="text-xl font-bold mb-2">
            Flashs Bonus
          </h2>
          <p className="text-rose-100 text-sm">
            {remainingFlashes === 0 
              ? "Vous avez épuisé vos flashs quotidiens" 
              : `Il vous reste ${remainingFlashes} flashs aujourd'hui`}
          </p>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="space-y-4">
            {flashBonusOptions.map((option) => (
              <div
                key={option.id}
                className={`relative rounded-xl border-2 transition-all cursor-pointer ${
                  selectedOption === option.id 
                    ? 'border-rose-500 bg-rose-50' 
                    : 'border-gray-200 hover:border-gray-300'
                } ${!option.available ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={() => option.available && setSelectedOption(option.id)}
              >
                <div className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${option.color} flex items-center justify-center text-white`}>
                        {option.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{option.title}</h3>
                        <p className="text-sm text-gray-600">{option.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-gray-900">{option.price}</div>
                      {!option.available && (
                        <div className="text-xs text-gray-500 mt-1">
                          {userPlan === 'gratuit' ? 'Nécessite Premium+' : 'Non disponible'}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {selectedOption === option.id && (
                    <div className="absolute top-2 right-2">
                      <CheckCircle className="h-5 w-5 text-rose-500" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Plan upgrade suggestion */}
          {userPlan === 'gratuit' && (
            <div className="mt-6 p-4 bg-gradient-to-r from-rose-50 to-pink-50 rounded-lg border border-rose-200">
              <div className="flex items-center space-x-3 mb-2">
                <Crown className="h-5 w-5 text-rose-500" />
                <h4 className="font-semibold text-gray-900">Passez Premium</h4>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Accédez aux flashs bonus et à toutes les fonctionnalités avancées
              </p>
              <Button 
                size="sm" 
                className="bg-rose-500 hover:bg-rose-600 text-white"
                onClick={() => window.location.href = '/subscription'}
              >
                Découvrir Premium
              </Button>
            </div>
          )}

          {/* Purchase button */}
          {selectedOption && (
            <Button
              onClick={handlePurchase}
              disabled={isLoading}
              className="w-full mt-6 bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white py-3"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Traitement...
                </div>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Acheter maintenant
                </>
              )}
            </Button>
          )}

          <p className="text-xs text-gray-500 mt-4 text-center">
            Paiement sécurisé par Stripe. Annulation possible sous 24h.
          </p>
        </div>
      </div>
    </div>
  );
}