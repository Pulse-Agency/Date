import { Heart } from "lucide-react";
import { Link } from "wouter";

export default function SiteFooter() {
  return (
    <div className="bg-gray-50 border-t border-gray-200 mt-8">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center justify-center mb-4">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-2 rounded-full">
              <Heart className="h-5 w-5 text-white fill-current" />
            </div>
            <div className="text-center">
              <h2 className="text-lg font-semibold text-gray-900">Retour à l'accueil</h2>
              <p className="text-sm text-gray-600">Date Mature - Votre profil vous attend</p>
            </div>
          </Link>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500 mb-4">
          <Link href="/legal/mentions-legales" className="hover:text-purple-600 transition-colors">
            Mentions légales
          </Link>
          <span>•</span>
          <Link href="/legal/cgv" className="hover:text-purple-600 transition-colors">
            CGV
          </Link>
          <span>•</span>
          <Link href="/legal/politique-confidentialite" className="hover:text-purple-600 transition-colors">
            Politique de confidentialité
          </Link>
        </div>
        
        <div className="text-center text-xs text-gray-400">
          © 2025 Date Mature - Rencontres sérieuses et sécurisées
        </div>
      </div>
    </div>
  );
}