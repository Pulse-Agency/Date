import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';

interface UseWebSocketProps {
  onMessage?: (message: any) => void;
  onTyping?: (data: { userId: number; isTyping: boolean }) => void;
}

export const useWebSocket = ({ onMessage, onTyping }: UseWebSocketProps = {}) => {
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    socketRef.current = io();

    if (onMessage) {
      socketRef.current.on('new_message', onMessage);
    }

    if (onTyping) {
      socketRef.current.on('user_typing', onTyping);
    }

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [onMessage, onTyping]);

  const joinConversation = (user1Id: number, user2Id: number) => {
    if (socketRef.current) {
      socketRef.current.emit('join_conversation', { user1Id, user2Id });
    }
  };

  const sendMessage = (senderId: number, receiverId: number, content: string) => {
    if (socketRef.current) {
      socketRef.current.emit('send_message', { senderId, receiverId, content });
    }
  };

  const sendTyping = (senderId: number, receiverId: number, isTyping: boolean) => {
    if (socketRef.current) {
      socketRef.current.emit('typing', { senderId, receiverId, isTyping });
    }
  };

  return {
    joinConversation,
    sendMessage,
    sendTyping
  };
};
