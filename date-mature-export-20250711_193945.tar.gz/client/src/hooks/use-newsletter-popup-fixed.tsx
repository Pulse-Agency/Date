import { useState, useEffect, useCallback } from 'react';

export const useNewsletterPopup = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [triggersActive, setTriggersActive] = useState(false);

  // Vérifier si le popup peut être affiché
  const shouldShowPopup = useCallback(() => {
    const today = new Date().toDateString();
    const lastShown = localStorage.getItem('newsletter_popup_last_shown');
    const dismissed = localStorage.getItem('newsletter_popup_dismissed_v2');
    const subscribed = localStorage.getItem('newsletter_subscribed');

    return !(lastShown === today || dismissed === 'true' || subscribed === 'true');
  }, []);

  // Fonction pour déclencher le popup UNIQUEMENT quand les conditions sont remplies
  const triggerPopup = useCallback(() => {
    if (shouldShowPopup() && !showPopup) {
      console.log('Popup newsletter déclenché');
      setShowPopup(true);
      const today = new Date().toDateString();
      localStorage.setItem('newsletter_popup_last_shown', today);
    }
  }, [shouldShowPopup, showPopup]);

  // Fonction pour fermer le popup
  const closePopup = useCallback(() => {
    setShowPopup(false);
    localStorage.setItem('newsletter_popup_dismissed_v2', 'true');
  }, []);

  // Initialisation des déclencheurs SEULEMENT si les conditions sont remplies
  useEffect(() => {
    // Vérifier IMMÉDIATEMENT si on peut afficher le popup
    if (!shouldShowPopup()) {
      console.log('Popup non autorisé - conditions non remplies');
      return;
    }

    // Délai avant d'activer les déclencheurs (pas d'affichage automatique)
    const initTimer = setTimeout(() => {
      console.log('Déclencheurs popup activés');
      setTriggersActive(true);
    }, 3000); // 3 secondes avant d'activer les déclencheurs

    return () => clearTimeout(initTimer);
  }, [shouldShowPopup]);

  // Déclencheurs actifs SEULEMENT après l'initialisation
  useEffect(() => {
    if (!triggersActive) return;

    let timeoutTriggered = false;
    let scrollTriggered = false;
    let exitTriggered = false;

    // Déclencheur 1: Timer 30 secondes
    const timer = setTimeout(() => {
      if (!timeoutTriggered && !scrollTriggered && !exitTriggered) {
        console.log('Déclencheur timer 30s');
        timeoutTriggered = true;
        triggerPopup();
      }
    }, 30000);

    // Déclencheur 2: Scroll 80%
    const handleScroll = () => {
      if (scrollTriggered || timeoutTriggered || exitTriggered) return;
      
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight;
      const clientHeight = document.documentElement.clientHeight;
      const scrollPercent = (scrollTop / (scrollHeight - clientHeight)) * 100;

      if (scrollPercent >= 80) {
        console.log('Déclencheur scroll 80%');
        scrollTriggered = true;
        triggerPopup();
      }
    };

    // Déclencheur 3: Exit intent
    const handleMouseLeave = (e: MouseEvent) => {
      if (exitTriggered || timeoutTriggered || scrollTriggered) return;
      if (e.clientY <= 0) {
        console.log('Déclencheur exit intent');
        exitTriggered = true;
        triggerPopup();
      }
    };

    // Déclencheur 4: Avant de quitter la page
    const handleBeforeUnload = () => {
      if (!exitTriggered && !timeoutTriggered && !scrollTriggered) {
        console.log('Déclencheur before unload');
        triggerPopup();
      }
    };

    // Ajouter les event listeners
    window.addEventListener('scroll', handleScroll, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [triggersActive, triggerPopup]);

  return {
    showPopup,
    closePopup,
    triggersActive // Pour debug
  };
};