import { useState, useEffect, useCallback } from 'react';

export const useNewsletterPopupDebug = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [debugInfo, setDebugInfo] = useState<string[]>([]);

  const log = useCallback((message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    const logMessage = `[${timestamp}] ${message}`;
    console.log(logMessage);
    setDebugInfo(prev => [...prev.slice(-4), logMessage]); // Garder les 5 derniers
  }, []);

  const shouldShowPopup = useCallback(() => {
    const today = new Date().toDateString();
    const lastShown = localStorage.getItem('newsletter_popup_last_shown');
    const dismissed = localStorage.getItem('newsletter_popup_dismissed_v2');
    const subscribed = localStorage.getItem('newsletter_subscribed');

    const shouldShow = !(lastShown === today || dismissed === 'true' || subscribed === 'true');
    
    log(`shouldShowPopup: ${shouldShow} (lastShown: ${lastShown}, dismissed: ${dismissed}, subscribed: ${subscribed})`);
    return shouldShow;
  }, [log]);

  const triggerPopup = useCallback(() => {
    const canShow = shouldShowPopup();
    if (canShow && !showPopup) {
      log('POPUP DÉCLENCHÉ !');
      setShowPopup(true);
      const today = new Date().toDateString();
      localStorage.setItem('newsletter_popup_last_shown', today);
    } else {
      log(`Popup NOT déclenché - canShow: ${canShow}, showPopup: ${showPopup}`);
    }
  }, [shouldShowPopup, showPopup, log]);

  useEffect(() => {
    log('Hook initialisé');
    
    if (!shouldShowPopup()) {
      log('Conditions non remplies - pas de déclencheurs');
      return;
    }

    log('Conditions OK - démarrage des déclencheurs dans 3 secondes');
    
    const initTimer = setTimeout(() => {
      log('Déclencheurs activés !');
      
      // Timer 30 secondes
      const timer = setTimeout(() => {
        log('30 secondes écoulées - déclenchement timer');
        triggerPopup();
      }, 30000);

      // Scroll 80%
      const handleScroll = () => {
        const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
        if (scrollPercent > 80) {
          log(`80% scroll atteint (${scrollPercent.toFixed(1)}%) - déclenchement scroll`);
          triggerPopup();
        }
      };

      // Exit intent
      const handleMouseLeave = (e: MouseEvent) => {
        if (e.clientY <= 0) {
          log('Exit intent détecté - déclenchement souris');
          triggerPopup();
        }
      };

      window.addEventListener('scroll', handleScroll);
      document.addEventListener('mouseleave', handleMouseLeave);

      return () => {
        clearTimeout(timer);
        window.removeEventListener('scroll', handleScroll);
        document.removeEventListener('mouseleave', handleMouseLeave);
      };
    }, 3000);

    return () => clearTimeout(initTimer);
  }, [shouldShowPopup, triggerPopup, log]);

  const closePopup = useCallback(() => {
    log('Popup fermé');
    setShowPopup(false);
    localStorage.setItem('newsletter_popup_dismissed_v2', 'true');
  }, [log]);

  return {
    showPopup,
    closePopup,
    debugInfo
  };
};