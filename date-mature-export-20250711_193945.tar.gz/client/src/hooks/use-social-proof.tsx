import { useState, useEffect } from "react";

export const useSocialProof = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [lastShown, setLastShown] = useState<number>(0);

  useEffect(() => {
    // Affiche la notification après un délai initial de 30 secondes
    const initialDelay = setTimeout(() => {
      showNotification();
    }, 30000);

    // Puis affiche périodiquement avec un rythme plus lent
    const interval = setInterval(() => {
      const now = Date.now();
      const timeSinceLastShown = now - lastShown;
      
      // Affiche seulement si plus de 20 secondes se sont écoulées
      if (timeSinceLastShown > 20000) {
        // Probabilité de 40% d'afficher la notification pour un rythme d'environ 25-30 secondes
        if (Math.random() < 0.4) {
          showNotification();
        }
      }
    }, 10000); // Vérifie toutes les 10 secondes

    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, [lastShown]);

  const showNotification = () => {
    setIsVisible(true);
    setLastShown(Date.now());
  };

  const hideNotification = () => {
    setIsVisible(false);
  };

  return {
    isVisible,
    showNotification,
    hideNotification
  };
};