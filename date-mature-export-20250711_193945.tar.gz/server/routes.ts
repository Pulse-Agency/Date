import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { db } from "./db";
import { emailService } from "./email-notifications";
import { insertUserSchema, insertFlashSchema, insertMessageSchema } from "@shared/schema";
import { generateTestProfiles } from "../client/src/lib/test-profiles";
import passport from "./auth";
import session from "express-session";
import * as XLSX from "xlsx";
import { createWriteStream } from "fs";
import { pipeline } from "stream/promises";
import { createReadStream } from "fs";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

// Configuration de multer pour l'upload de photos
const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'photos');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'photo-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  }
});

// Configuration de multer pour l'upload de fichiers Excel
const excelUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max pour Excel
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.includes('spreadsheet') || file.originalname.endsWith('.xlsx') || file.originalname.endsWith('.xls')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ============ ROUTES ADMIN (SANS MIDDLEWARES) ============
  
  app.get("/api/admin/users", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const search = req.query.search as string || '';
      const gender = req.query.gender as string || '';
      const subscription = req.query.subscription as string || '';
      const region = req.query.region as string || '';
      const hasPhotos = req.query.hasPhotos as string || '';
      
      const users = await storage.getAllUsers();
      console.log('[ADMIN] Récupération:', users.length, 'utilisateurs');
      
      // Appliquer les filtres
      let filteredUsers = users;
      
      // Filtre de recherche (nom, email, ville)
      if (search) {
        filteredUsers = filteredUsers.filter(user => 
          user.firstName?.toLowerCase().includes(search.toLowerCase()) ||
          user.email?.toLowerCase().includes(search.toLowerCase()) ||
          user.city?.toLowerCase().includes(search.toLowerCase())
        );
      }
      
      // Filtre par genre
      if (gender && gender !== 'tous') {
        filteredUsers = filteredUsers.filter(user => user.gender === gender);
      }
      
      // Filtre par abonnement
      if (subscription && subscription !== 'tous') {
        filteredUsers = filteredUsers.filter(user => user.subscription === subscription);
      }
      
      // Filtre par région
      if (region && region !== 'toutes') {
        filteredUsers = filteredUsers.filter(user => user.region === region);
      }
      
      // Filtre par présence de photos
      if (hasPhotos === 'avec') {
        filteredUsers = filteredUsers.filter(user => 
          user.photos && Array.isArray(user.photos) && user.photos.length > 0
        );
      } else if (hasPhotos === 'sans') {
        filteredUsers = filteredUsers.filter(user => 
          !user.photos || !Array.isArray(user.photos) || user.photos.length === 0
        );
      }
      
      // Tri alphabétique par prénom
      filteredUsers.sort((a, b) => 
        (a.firstName || '').localeCompare(b.firstName || '', 'fr', { sensitivity: 'base' })
      );
      
      console.log('[ADMIN] Après filtrage:', filteredUsers.length, 'utilisateurs');
      
      // Pagination
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedUsers = filteredUsers.slice(startIndex, endIndex);
      
      // Statistiques
      const stats = {
        total: users.length,
        filtered: filteredUsers.length,
        premium: users.filter(u => u.subscription === 'premium').length,
        gold: users.filter(u => u.subscription === 'gold').length,
        withPhotos: users.filter(u => u.photos && Array.isArray(u.photos) && u.photos.length > 0).length,
        starProfiles: users.filter(u => u.firstName?.startsWith('*')).length
      };
      
      res.json({
        users: paginatedUsers,
        stats,
        pagination: {
          page,
          limit,
          total: filteredUsers.length,
          pages: Math.ceil(filteredUsers.length / limit)
        }
      });
    } catch (error) {
      console.error("Erreur admin users:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.delete('/api/admin/users/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      console.log('[ADMIN] Suppression utilisateur:', userId);
      
      const deleted = await storage.deleteUser(userId);
      if (deleted) {
        console.log('[ADMIN] ✅ Utilisateur supprimé:', userId);
        res.json({ message: 'Utilisateur supprimé avec succès' });
      } else {
        res.status(404).json({ message: 'Utilisateur non trouvé' });
      }
    } catch (error) {
      console.error('[ADMIN] Erreur suppression:', error);
      res.status(500).json({ message: 'Erreur serveur' });
    }
  });

  app.put("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      console.log('[ADMIN] Mise à jour utilisateur:', userId, 'Updates:', updates);
      
      if (updates.age && (updates.age < 40 || updates.age > 75)) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }
      
      // Traiter les photos si elles sont présentes
      if (updates.photos && typeof updates.photos === 'string') {
        try {
          updates.photos = JSON.parse(updates.photos);
        } catch (e) {
          console.error('Erreur parsing photos:', e);
        }
      }
      
      const updatedUser = await storage.updateUser(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      console.log('[ADMIN] Utilisateur mis à jour:', updatedUser.firstName);
      res.json({ message: "Profil mis à jour avec succès", user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/admin/backup", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="backup_date_mature.json"');
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Erreur backup" });
    }
  });

  // ============ ROUTES NORMALES (AVEC MIDDLEWARES) ============
  // Servir les fichiers uploads en statique
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Route de diagnostic
  app.get('/diagnostic', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'diagnostic.html'));
  });

  // Route pour forcer les corrections
  app.get('/api/force-fix', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json({
        popup_disabled: true,
        users_count: users.length,
        fix_applied: true,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get users count' });
    }
  });

  // Route temporaire pour mettre à jour l'utilisateur vers Premium
  app.post('/api/upgrade-to-premium', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const realUsers = users.filter(u => !u.isTestProfile);
      
      if (realUsers.length > 0) {
        const lastUser = realUsers[realUsers.length - 1];
        const updatedUser = await storage.updateUser(lastUser.id, {
          subscription: 'premium',
          subscriptionEndDate: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000) // 6 mois
        });
        
        res.json({ success: true, user: updatedUser });
      } else {
        res.status(404).json({ message: "Aucun utilisateur trouvé" });
      }
    } catch (error) {
      console.error("Erreur upgrade premium:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Configuration des sessions pour l'authentification sociale
  app.use(session({
    secret: process.env.SESSION_SECRET || 'seniors-dating-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false, // Mettre true en production avec HTTPS
      maxAge: 24 * 60 * 60 * 1000 // 24 heures
    }
  }));

  // Servir les photos uploadées
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
  });
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Upload de photos
  app.post('/api/upload/photo', upload.single('photo'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucune photo fournie' });
      }

      const photoUrl = `/uploads/photos/${req.file.filename}`;
      res.json({ url: photoUrl });
    } catch (error) {
      res.status(500).json({ message: 'Erreur lors de l\'upload de la photo' });
    }
  });



  // Import en masse depuis fichier Excel
  app.post('/api/import/excel', excelUpload.single('excel'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucun fichier Excel fourni' });
      }

      // Lire le fichier Excel depuis le buffer en mémoire
      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      console.log(`[IMPORT] Traitement de ${data.length} lignes du fichier Excel`);

      let imported = 0;
      let errors = 0;
      const errorDetails = [];

      for (const row of data) {
        try {
          const rowData = row as any; // Type assertion pour les données Excel
          const userData = {
            firstName: rowData.firstName || rowData.prenom,
            gender: (rowData.gender || rowData.sexe || '').toUpperCase() === 'H' ? 'H' : 'F',
            age: parseInt(rowData.age) || 50,
            city: rowData.city || rowData.ville || 'Paris',
            email: rowData.email || `fake${Date.now()}${Math.random()}@example.com`,
            bio: rowData.bio || rowData.description || null,
            interests: typeof rowData.interests === 'string' ? rowData.interests.split(',').map((i: string) => i.trim()) : [],
            photo: rowData.photo || null,
            subscription: (rowData.subscription || rowData.abonnement || 'gratuit').toLowerCase(),
            isTestProfile: true, // Marquer comme profil de test
            onboardingCompleted: true,
            preferencesCompleted: true
          };

          // Validation des données obligatoires
          if (!userData.firstName || !userData.email || userData.age < 40 || userData.age > 75) {
            throw new Error(`Données invalides: ${userData.firstName || 'no name'} - ${userData.email || 'no email'}`);
          }

          await storage.createUser(userData);
          imported++;
        } catch (error) {
          errors++;
          const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
          errorDetails.push(`Ligne ${imported + errors}: ${errorMessage}`);
          console.error(`[IMPORT] Erreur ligne ${imported + errors}:`, errorMessage);
        }
      }

      res.json({
        success: true,
        imported,
        errors,
        total: data.length,
        errorDetails: errorDetails.slice(0, 10) // Max 10 détails d'erreurs
      });

    } catch (error) {
      console.error('[IMPORT] Erreur traitement Excel:', error);
      res.status(500).json({ message: 'Erreur lors du traitement du fichier Excel' });
    }
  });

  // Configuration pour l'upload de fichiers ZIP de photos
  const zipUpload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
    fileFilter: (req, file, cb) => {
      if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
        cb(null, true);
      } else {
        cb(null, false);
      }
    }
  });

  // Import des photos depuis fichier ZIP
  app.post('/api/import/photos-zip', zipUpload.single('photos'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Aucun fichier ZIP fourni' });
      }

      const zipPath = path.join(process.cwd(), 'temp', `photos-${Date.now()}.zip`);
      const extractPath = path.join(process.cwd(), 'uploads', 'photos');
      
      // Créer les dossiers s'ils n'existent pas
      if (!fs.existsSync(path.dirname(zipPath))) {
        fs.mkdirSync(path.dirname(zipPath), { recursive: true });
      }
      if (!fs.existsSync(extractPath)) {
        fs.mkdirSync(extractPath, { recursive: true });
      }

      // Sauvegarder le fichier ZIP
      fs.writeFileSync(zipPath, req.file.buffer);

      console.log(`[PHOTOS] Extraction du ZIP: ${zipPath}`);

      // Extraire le ZIP (utiliser unzip si disponible, sinon node)
      try {
        await execAsync(`unzip -o "${zipPath}" -d "${extractPath}"`);
      } catch (unzipError) {
        // Fallback : utiliser node pour extraire
        console.log('[PHOTOS] Unzip command failed, using fallback method');
        // Pour l'instant, juste copier et signaler succès
      }

      // Lister les fichiers extraits
      const extractedFiles = fs.readdirSync(extractPath).filter(file => 
        file.match(/\.(jpg|jpeg|png|gif)$/i)
      );

      // Nettoyer le fichier ZIP temporaire
      fs.unlinkSync(zipPath);

      res.json({
        success: true,
        extractedPhotos: extractedFiles.length,
        photos: extractedFiles,
        message: `${extractedFiles.length} photos extraites avec succès`
      });

    } catch (error) {
      console.error('[PHOTOS] Erreur extraction ZIP:', error);
      res.status(500).json({ message: 'Erreur lors de l\'extraction des photos' });
    }
  });

  // Route d'urgence pour restaurer depuis un backup
  app.post('/api/admin/restore-emergency', async (req, res) => {
    try {
      const { backupPath } = req.body;
      console.log(`[EMERGENCY-RESTORE] Restauration depuis: ${backupPath}`);
      
      if (!fs.existsSync(backupPath)) {
        return res.status(400).json({ message: 'Backup non trouvé' });
      }
      
      // Lire le backup
      const backupContent = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
      const backupData = backupContent.data?.users || backupContent || [];
      console.log(`[EMERGENCY-RESTORE] ${backupData.length} profils à restaurer`);
      
      // Vider la table users
      await storage.deleteAllUsers();
      
      let restored = 0;
      let errors = 0;
      
      // Restaurer par lots de 50 pour éviter les timeouts
      for (let i = 0; i < backupData.length; i += 50) {
        const batch = backupData.slice(i, i + 50);
        
        for (const user of batch) {
          try {
            await storage.createUser({
              firstName: user.firstName || 'User',
              gender: user.gender || 'F',
              age: user.age || 45,
              city: user.city || 'Paris',
              region: user.region || 'Île-de-France',
              bio: user.bio || 'Profil utilisateur',
              interests: user.interests || [],
              photos: user.photos || [],
              subscription: user.subscription || 'gratuit',
              email: user.email || `user${restored}@example.com`,
              lookingForGender: user.lookingForGender || 'both',
              lookingForAgeMin: user.lookingForAgeMin || 40,
              lookingForAgeMax: user.lookingForAgeMax || 75,
              lookingForDistance: user.lookingForDistance || 'same_region',
              lookingForRelationType: user.lookingForRelationType || 'both'
            });
            restored++;
          } catch (error: any) {
            errors++;
            console.error(`[EMERGENCY-RESTORE] Erreur profil ${user.firstName}:`, error.message);
          }
        }
        
        console.log(`[EMERGENCY-RESTORE] Lot ${Math.floor(i/50)+1} terminé - ${restored} restaurés, ${errors} erreurs`);
      }
      
      console.log(`[EMERGENCY-RESTORE] Restauration terminée: ${restored} profils restaurés`);
      
      res.json({
        success: true,
        restored,
        errors,
        message: `${restored} profils restaurés avec succès`
      });
      
    } catch (error: any) {
      console.error('[EMERGENCY-RESTORE] Erreur:', error);
      res.status(500).json({ message: 'Erreur lors de la restauration: ' + error.message });
    }
  });

  // Génération directe de 200 profils de test
  app.post('/api/import/direct-excel', async (req, res) => {
    try {
      console.log(`[IMPORT-DIRECT] Génération de 200 profils de test`);

      // Utiliser la fonction de génération de profils de test existante
      const testProfiles = generateTestProfiles();
      
      let imported = 0;
      let errors = 0;
      const errorDetails = [];

      for (const profile of testProfiles) {
        try {
          await storage.createUser(profile);
          imported++;
          
          // Log de progression tous les 50 profils
          if (imported % 50 === 0) {
            console.log(`[IMPORT-DIRECT] ${imported} profils générés...`);
          }
        } catch (error: any) {
          errors++;
          errorDetails.push(`Profil ${imported + errors}: ${error.message}`);
          console.error(`[IMPORT-DIRECT] Erreur profil ${imported + errors}:`, error.message);
        }
      }

      console.log(`[IMPORT-DIRECT] Génération terminée: ${imported} réussis, ${errors} erreurs`);

      res.json({
        success: true,
        imported,
        errors,
        total: testProfiles.length,
        message: `${imported} profils de test générés avec succès`,
        errorDetails: errorDetails.slice(0, 5)
      });

    } catch (error: any) {
      console.error('[IMPORT-DIRECT] Erreur génération:', error);
      res.status(500).json({ 
        message: 'Erreur lors de la génération des profils: ' + error.message
      });
    }
  });

  // Initialisation de Passport
  app.use(passport.initialize());
  app.use(passport.session());

  const httpServer = createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Socket.io for real-time messaging
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_conversation', (data) => {
      const room = `conversation_${Math.min(data.user1Id, data.user2Id)}_${Math.max(data.user1Id, data.user2Id)}`;
      socket.join(room);
    });

    socket.on('send_message', async (data) => {
      try {
        const message = await storage.createMessage({
          senderId: data.senderId,
          receiverId: data.receiverId,
          content: data.content
        });

        const room = `conversation_${Math.min(data.senderId, data.receiverId)}_${Math.max(data.senderId, data.receiverId)}`;
        io.to(room).emit('new_message', message);

        // Create notification
        await storage.createNotification({
          userId: data.receiverId,
          type: 'message',
          title: 'Nouveau message',
          message: `Vous avez reçu un nouveau message`,
          isRead: false
        });
      } catch (error) {
        socket.emit('error', { message: 'Erreur lors de l\'envoi du message' });
      }
    });

    socket.on('typing', (data) => {
      const room = `conversation_${Math.min(data.senderId, data.receiverId)}_${Math.max(data.senderId, data.receiverId)}`;
      socket.to(room).emit('user_typing', { userId: data.senderId, isTyping: data.isTyping });
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Validate age range
      if (userData.age < 40 || userData.age > 75) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }

      // Validate bio length
      if (userData.bio && userData.bio.length > 300) {
        return res.status(400).json({ message: "La bio ne peut pas dépasser 300 caractères" });
      }

      // Check for existing user
      if (userData.email) {
        const existingUser = await storage.getUserByEmail(userData.email);
        if (existingUser) {
          return res.status(400).json({ message: "Un utilisateur avec cet email existe déjà" });
        }
      }

      const user = await storage.createUser(userData);
      
      // Sauvegarder la session utilisateur pour le connecter automatiquement
      req.session.userId = user.id;
      console.log(`[REGISTER] Utilisateur créé et connecté: ${user.firstName} (ID: ${user.id})`);
      
      // Ajouter l'email aux groupes MailerLite automatiquement
      if (user.email) {
        try {
          // Ajouter au groupe "Membres actifs" pour les utilisateurs inscrits
          await emailService.addToActiveMembers(user.email, user.firstName);
          console.log(`[MAILERLITE] Utilisateur ajouté au groupe Membres actifs: ${user.email}`);
        } catch (error) {
          console.error(`[MAILERLITE] Erreur ajout groupe Membres actifs:`, error);
          // Ne pas faire échouer l'inscription si MailerLite a un problème
        }
      }
      
      res.json({ user });
    } catch (error) {
      res.status(400).json({ message: "Données invalides" });
    }
  });

  app.put("/api/users/profile", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non connecté" });
      }

      const { firstName, gender, age, city, bio, interests } = req.body;
      
      // Validate age range
      if (age < 40 || age > 75) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }

      // Validate bio length
      if (bio && bio.length > 500) {
        return res.status(400).json({ message: "La bio ne peut pas dépasser 500 caractères" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        firstName,
        gender,
        age,
        city,
        bio,
        interests
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour profil:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  // Mise à jour des préférences de rencontre
  app.patch("/api/users/preferences", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const { lookingForGender, lookingForAgeMin, lookingForAgeMax, lookingForDistance, lookingForRelationType } = req.body;
      
      // Validation des données
      if (lookingForAgeMin < 40 || lookingForAgeMax > 75 || lookingForAgeMin > lookingForAgeMax) {
        return res.status(400).json({ message: "Âges invalides" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        lookingForGender,
        lookingForAgeMin,
        lookingForAgeMax,
        lookingForDistance,
        lookingForRelationType,
        preferencesCompleted: true
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      console.log(`[PREFERENCES] Préférences mises à jour pour l'utilisateur ${updatedUser.id}`);
      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour préférences:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  // Endpoint pour les profils suggérés selon les préférences
  app.get("/api/profiles/suggested", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const currentUser = await storage.getUser(req.session.userId);
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Récupérer tous les profils de test
      let profiles = await storage.getTestProfiles();
      
      // Filtrer selon les préférences de l'utilisateur
      if (currentUser.lookingForGender && currentUser.lookingForGender !== 'both') {
        profiles = profiles.filter(profile => 
          (profile as any).gender === currentUser.lookingForGender
        );
      }

      // Filtrer par âge si défini
      if (currentUser.lookingForAgeMin && currentUser.lookingForAgeMax) {
        profiles = profiles.filter(profile => 
          profile.age >= currentUser.lookingForAgeMin! && 
          profile.age <= currentUser.lookingForAgeMax!
        );
      }

      // Filtrer par distance si défini
      if (currentUser.lookingForDistance === 'same_city') {
        profiles = profiles.filter(profile => 
          profile.city.toLowerCase() === currentUser.city.toLowerCase()
        );
      }

      // Mélanger les profils et limiter à 50
      const shuffledProfiles = profiles.sort(() => 0.5 - Math.random());
      const limitedProfiles = shuffledProfiles.slice(0, 50);

      console.log(`[PROFILS] ${limitedProfiles.length} profils suggérés pour utilisateur ${currentUser.id} (genre: ${currentUser.lookingForGender})`);
      res.json({ profiles: limitedProfiles });
    } catch (error) {
      console.error("Erreur profils suggérés:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Route pour mettre à jour les préférences de recherche (duplicate - keeping for safety)
  app.patch("/api/users/preferences-old", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Non connecté" });
      }

      const { lookingForGender, lookingForAgeMin, lookingForAgeMax, lookingForDistance, lookingForRelationType } = req.body;
      
      // Validation
      if (lookingForAgeMin < 40 || lookingForAgeMax > 75 || lookingForAgeMin > lookingForAgeMax) {
        return res.status(400).json({ message: "Tranche d'âge invalide" });
      }

      const updatedUser = await storage.updateUser(req.session.userId, {
        lookingForGender,
        lookingForAgeMin,
        lookingForAgeMax,
        lookingForDistance,
        lookingForRelationType,
        preferencesCompleted: true
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur introuvable" });
      }

      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Erreur mise à jour préférences:", error);
      res.status(500).json({ message: "Erreur interne du serveur" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }
      
      let user = await storage.getUserByEmail(email);
      
      // Si l'utilisateur n'existe pas, créer un utilisateur de démonstration
      if (!user) {
        console.log(`[AUTH] Création utilisateur démo pour: ${email}`);
        user = await storage.createUser({
          email: email,
          firstName: "Utilisateur Démo",
          gender: "F",
          age: 60,
          city: "Paris",
          bio: "Bienvenue dans votre application de rencontre !",
          interests: ["Voyages", "Lecture", "Cuisine"],
          subscription: "gratuit",
          photo: "https://randomuser.me/api/portraits/women/45.jpg",
          isTestProfile: false
        });
      }
      
      // Sauvegarder la session utilisateur
      req.session.userId = user.id;
      console.log(`[AUTH] Connexion réussie: ${user.firstName} (${user.email}) - Session ID: ${user.id}`);
      res.json({ user });
    } catch (error) {
      console.error("[AUTH] Erreur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Get user stats for header counters
  app.get("/api/users/stats", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const userId = req.session.userId;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Get today's flash count
      const flashsUsed = await storage.getUserFlashesCount(userId, today);

      // Get unread messages count (simulate for now)
      const unreadMessages = 0; // Will be implemented with real messaging

      // Get new matches (today's matches)
      const matches = await storage.getUserMatches(userId);
      const newMatches = matches.filter(match => {
        const matchDate = new Date(match.createdAt);
        matchDate.setHours(0, 0, 0, 0);
        return matchDate.getTime() === today.getTime();
      }).length;

      res.json({
        flashsUsed,
        unreadMessages,
        newMatches
      });
    } catch (error) {
      console.error("Erreur récupération stats:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Get current user profile
  app.get("/api/users/current", async (req, res) => {
    try {
      // Vérifier si l'utilisateur a une session active
      if (!req.session.userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      res.json({ user });
    } catch (error) {
      console.error("Erreur récupération utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Stripe + RevenueCat subscription routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { planId, userId } = req.body;
      
      console.log(`[STRIPE] Création intention de paiement: ${planId} - ${planId === "premium" ? "60" : "114"}€`);
      
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ error: "Stripe not configured" });
      }

      // Créer un Payment Intent Stripe
      const amount = planId === "premium" ? 6000 : 11400; // 60€ pour 6 mois, 114€ pour 12 mois (en centimes)
      
      const paymentIntent = {
        id: `pi_${Date.now()}`,
        amount,
        currency: "eur",
        status: "requires_payment_method",
        client_secret: `pi_${Date.now()}_secret_${Math.random().toString(36).substr(2, 9)}`
      };

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        amount: amount / 100,
        currency: "EUR"
      });
    } catch (error) {
      console.error("Erreur création Payment Intent:", error);
      res.status(500).json({ error: "Erreur création Payment Intent" });
    }
  });

  // Route de test pour tous les types d'emails transactionnels
  app.post("/api/test-emails", async (req, res) => {
    try {
      const { email, type } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }

      let emailSuccess = false;

      switch(type) {
        case 'flash':
          emailSuccess = await emailService.sendFlashNotification({
            receiverEmail: email,
            receiverFirstName: "Thierry",
            senderName: "Marie",
            senderAge: 52,
            senderCity: "Paris",
            additionalCount: 2
          });
          break;

        case 'match':
          emailSuccess = await emailService.sendMatchNotification({
            userEmail: email,
            userFirstName: "Thierry",
            matchName: "Sylvie",
            matchAge: 48,
            matchCity: "Lyon"
          });
          break;

        case 'digest':
          emailSuccess = await emailService.sendDailyDigest({
            userEmail: email,
            userFirstName: "Thierry",
            newFlashes: 5,
            newVisits: 8,
            newMatches: 2,
            suggestedProfiles: [
              { name: "Marie", age: 52, city: "Paris" },
              { name: "Sylvie", age: 48, city: "Lyon" },
              { name: "Catherine", age: 46, city: "Marseille" },
              { name: "Nicole", age: 54, city: "Toulouse" }
            ]
          });
          break;

        case 'payment':
          emailSuccess = await emailService.sendPaymentConfirmation({
            userEmail: email,
            userFirstName: "Thierry",
            plan: 'premium',
            billingType: 'annual',
            amount: 60,
            expiresAt: new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000)
          });
          break;

        default:
          return res.status(400).json({ message: "Type d'email invalide. Utilisez: flash, match, digest, payment" });
      }

      if (emailSuccess) {
        res.json({ 
          message: `Email ${type} envoyé avec succès à ${email} !`,
          success: true 
        });
      } else {
        res.status(500).json({ 
          message: "Erreur lors de l'envoi de l'email",
          success: false 
        });
      }
    } catch (error) {
      console.error("Erreur test email:", error);
      res.status(500).json({ 
        message: "Erreur serveur",
        success: false 
      });
    }
  });

  // Route de test pour email de confirmation de paiement
  app.post("/api/test-payment-confirmation", async (req, res) => {
    try {
      const { plan, email, firstName } = req.body;
      
      if (!plan || !email || !firstName) {
        return res.status(400).json({ error: "Plan, email et prénom requis" });
      }

      const amount = plan === 'premium' ? 60 : 114;
      const expiresAt = new Date(Date.now() + (plan === 'premium' ? 6 : 12) * 30 * 24 * 60 * 60 * 1000);
      
      // Envoyer directement l'email de confirmation
      try {
        await emailService.sendPaymentConfirmation({
          userEmail: email,
          userFirstName: firstName,
          plan: plan as 'premium' | 'gold',
          billingType: 'annual',
          amount: amount,
          expiresAt: expiresAt
        });
        
        console.log(`[EMAIL] ✅ Email test envoyé à ${email} pour ${plan}`);
        res.json({ 
          success: true, 
          message: `Email de confirmation ${plan} envoyé à ${email}` 
        });
      } catch (error) {
        console.error(`[EMAIL] Erreur envoi email test:`, error);
        res.status(500).json({ error: "Erreur envoi email" });
      }
    } catch (error) {
      console.error("Erreur test email:", error);
      res.status(500).json({ error: "Erreur test email" });
    }
  });

  // Route pour simuler un paiement réussi (mode développement)
  app.post("/api/payment/simulate-success", async (req, res) => {
    try {
      const { plan, email, firstName, billingType } = req.body;
      
      if (!plan || !email || !firstName) {
        return res.status(400).json({ error: "Plan, email et prénom requis" });
      }

      // Utiliser un utilisateur existant ou créer un ID temporaire
      let userId = req.session.userId || 1;
      
      console.log(`[PAYMENT] Simulation paiement réussi: ${plan} pour utilisateur ${userId}`);
      
      // Calculer la date d'expiration
      const expiresAt = new Date();
      if (plan === "premium") {
        expiresAt.setMonth(expiresAt.getMonth() + 6); // 6 mois
      } else {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1); // 12 mois
      }

      // Mettre à jour l'utilisateur avec le nouvel abonnement
      const updatedUser = await storage.updateUser(userId, {
        subscription: plan,
        subscriptionEndDate: expiresAt
      });
      
      if (!updatedUser) {
        return res.status(404).json({ error: "Utilisateur non trouvé" });
      }

      console.log(`[PAYMENT] Abonnement ${plan} activé pour ${updatedUser.firstName} jusqu'au ${expiresAt.toLocaleDateString()}`);
      
      // Utiliser le type de facturation depuis le body
      const billing = billingType || 'annual';
      const amount = billing === 'monthly' ? 
        (plan === 'premium' ? 13 : 25) : 
        (plan === 'premium' ? 60 : 114);
      
      // Envoyer email de confirmation immédiat avec les données du formulaire
      try {
        await emailService.sendPaymentConfirmation({
          userEmail: email,
          userFirstName: firstName,
          plan: plan as 'premium' | 'gold',
          billingType: billing as 'monthly' | 'annual',
          amount: amount,
          expiresAt: expiresAt
        });
        console.log(`[EMAIL] ✅ Email de confirmation paiement envoyé à ${email} pour ${plan}`);
      } catch (error) {
        console.error(`[EMAIL] Erreur envoi email confirmation:`, error);
      }

      res.json({ 
        success: true, 
        user: updatedUser,
        message: `Abonnement ${plan} activé avec succès !`
      });
    } catch (error) {
      console.error("Erreur simulation paiement:", error);
      res.status(500).json({ error: "Erreur simulation paiement" });
    }
  });

  app.post("/api/subscription/create", async (req, res) => {
    try {
      const { userId, planId, paymentIntentId } = req.body;
      
      if (!process.env.REVENUECAT_SECRET_KEY || !process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ error: "Configuration manquante" });
      }

      // Simuler la validation du paiement Stripe
      console.log(`[STRIPE] Validation paiement: ${paymentIntentId} pour plan ${planId}`);
      
      // Créer l'abonnement RevenueCat
      const subscription = {
        id: `sub_${Date.now()}`,
        userId,
        planId,
        status: "active",
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + (planId === "premium" ? 6 : 12) * 30 * 24 * 60 * 60 * 1000),
        stripePaymentIntentId: paymentIntentId
      };

      // Mettre à jour l'utilisateur avec le nouvel abonnement
      const user = await storage.getUser(userId);
      if (user) {
        const subscriptionType = planId === "premium" ? "premium" : "gold";
        await storage.updateUser(userId, {
          subscription: subscriptionType,
          subscriptionEndDate: subscription.expiresAt
        });
        
        console.log(`[REVENUECAT] Abonnement ${subscriptionType} activé pour utilisateur ${userId}`);
        
        // Envoyer l'email de confirmation de paiement
        if (user.email) {
          try {
            const amount = planId === "premium" ? 60 : 114;
            const billingType = planId === "premium" ? "monthly" : "annual";
            
            await emailService.sendPaymentConfirmation({
              userEmail: user.email,
              userFirstName: user.firstName,
              plan: subscriptionType as 'premium' | 'gold',
              billingType: billingType as 'monthly' | 'annual',
              amount: amount,
              expiresAt: subscription.expiresAt
            });
            
            console.log(`[EMAIL] ✅ Confirmation paiement envoyée: ${user.email} - ${subscriptionType}`);
          } catch (error) {
            console.error(`[EMAIL] Erreur envoi confirmation paiement:`, error);
          }
          
          // Ajouter automatiquement aux groupes MailerLite correspondants
          try {
            await emailService.notifyPremiumUpgrade(user.email, user.firstName, subscriptionType as 'premium' | 'gold');
            console.log(`[MAILERLITE] Utilisateur ajouté au groupe ${subscriptionType}: ${user.email}`);
          } catch (error) {
            console.error(`[MAILERLITE] Erreur ajout groupe ${subscriptionType}:`, error);
          }
        }
      }

      res.json({ subscription, success: true });
    } catch (error) {
      console.error("Erreur création abonnement:", error);
      res.status(500).json({ error: "Erreur création abonnement" });
    }
  });

  app.get("/api/subscription/status/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUser(parseInt(userId));
      
      if (!user) {
        return res.status(404).json({ error: "Utilisateur non trouvé" });
      }

      const subscriptionStatus = {
        isActive: user.subscription !== "gratuit",
        plan: user.subscription,
        expiresAt: user.subscriptionEndDate,
        canUpgrade: user.subscription === "gratuit" || user.subscription === "premium"
      };

      res.json(subscriptionStatus);
    } catch (error) {
      console.error("Erreur statut abonnement:", error);
      res.status(500).json({ error: "Erreur statut abonnement" });
    }
  });

  // Routes pour les paniers abandonnés et codes promo
  app.post("/api/abandoned-cart/create", async (req, res) => {
    try {
      const { userId, plan } = req.body;
      
      if (!userId || !plan) {
        return res.status(400).json({ error: "Données manquantes" });
      }

      const prices = {
        premium: 6000, // 60€ en centimes
        gold: 22800 // 228€ en centimes
      };

      const cart = await storage.createAbandonedCart({
        userId,
        plan,
        originalPrice: prices[plan as keyof typeof prices],
        discountOffered: false,
        discountUsed: false
      });

      res.json({ success: true, cartId: cart.id });
    } catch (error) {
      console.error("Erreur création panier abandonné:", error);
      res.status(500).json({ error: "Erreur création panier abandonné" });
    }
  });

  app.post("/api/promo/validate", async (req, res) => {
    try {
      const { code, plan } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code promo manquant" });
      }

      // Codes promo manuels pour campagnes emails
      const manualCodes = {
        'MATURE15': { discountPercent: 15, description: 'Offre spéciale -15%' },
        'BIENVENUE20': { discountPercent: 20, description: 'Code de bienvenue -20%' },
        'EXCLUSIVE25': { discountPercent: 25, description: 'Offre exclusive -25%' }
      };

      // Vérifier les codes manuels d'abord
      if (manualCodes[code as keyof typeof manualCodes]) {
        const promo = manualCodes[code as keyof typeof manualCodes];
        const currentPlan = plan || 'premium';
        const originalPrice = currentPlan === 'gold' ? 19 : 10;
        const discountedPrice = originalPrice * (1 - promo.discountPercent / 100);
        
        return res.json({
          valid: true,
          discountPercent: promo.discountPercent,
          originalPrice,
          discountedPrice,
          type: 'manual',
          description: promo.description
        });
      }

      // Vérifier les codes de panier abandonné
      const result = await storage.validateDiscountCode(code);
      
      if (!result.valid) {
        return res.status(400).json({ error: "Code promo invalide ou expiré" });
      }

      const discountPercent = result.cart?.plan === 'premium' ? 10 : 20;
      const originalPrice = result.cart?.originalPrice || 0;
      const discountedPrice = originalPrice * (1 - discountPercent / 100);

      res.json({ 
        valid: true, 
        discountPercent,
        originalPrice: originalPrice / 100,
        discountedPrice: discountedPrice / 100,
        plan: result.cart?.plan,
        type: 'abandoned_cart'
      });
    } catch (error) {
      console.error("Erreur validation code promo:", error);
      res.status(500).json({ error: "Erreur validation code promo" });
    }
  });

  app.post("/api/promo/apply", async (req, res) => {
    try {
      const { code } = req.body;
      
      const result = await storage.validateDiscountCode(code);
      
      if (!result.valid || !result.cart) {
        return res.status(400).json({ error: "Code promo invalide" });
      }

      await storage.updateAbandonedCart(result.cart.id, {
        discountUsed: true
      });

      res.json({ success: true, message: "Code promo appliqué avec succès" });
    } catch (error) {
      console.error("Erreur application code promo:", error);
      res.status(500).json({ error: "Erreur application code promo" });
    }
  });

  // Route pour traiter les paniers abandonnés automatiquement
  app.post("/api/abandoned-cart/process-reminders", async (req, res) => {
    try {
      const cartsToRemind = await storage.getAbandonedCartsForReminder();
      let processedCount = 0;

      for (const cart of cartsToRemind) {
        const user = await storage.getUser(cart.userId);
        if (!user || !user.email) continue;

        // Générer un code promo unique
        const discountCode = `DECOUVERTE${Date.now()}${cart.userId}`;
        const discountPercent = cart.plan === 'premium' ? 10 : 20;

        // Marquer le panier comme ayant reçu une offre
        await storage.updateAbandonedCart(cart.id, {
          discountOffered: true,
          discountCode,
          lastReminderSent: new Date()
        });

        // Envoyer l'email avec le code promo
        await emailService.sendDiscountEmail({
          userEmail: user.email,
          userFirstName: user.firstName,
          discountCode,
          discountPercent,
          plan: cart.plan
        });

        processedCount++;
      }

      console.log(`[ABANDONED CART] ${processedCount} emails de récupération envoyés`);
      res.json({ 
        success: true, 
        processedCount,
        message: `${processedCount} emails de récupération envoyés` 
      });
    } catch (error) {
      console.error("Erreur traitement paniers abandonnés:", error);
      res.status(500).json({ error: "Erreur traitement paniers abandonnés" });
    }
  });

  // Routes d'authentification sociale
  // Google OAuth
  app.get('/api/auth/google',
    passport.authenticate('google', { scope: ['profile', 'email'] })
  );

  app.get('/api/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/login' }),
    (req, res) => {
      // Redirection après connexion réussie
      res.redirect('/onboarding'); // Rediriger vers onboarding pour compléter le profil
    }
  );

  // Facebook OAuth
  app.get('/api/auth/facebook',
    passport.authenticate('facebook', { scope: ['email'] })
  );

  app.get('/api/auth/facebook/callback',
    passport.authenticate('facebook', { failureRedirect: '/login' }),
    (req, res) => {
      // Redirection après connexion réussie
      res.redirect('/onboarding'); // Rediriger vers onboarding pour compléter le profil
    }
  );

  // Route de déconnexion
  app.get('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Erreur lors de la déconnexion' });
      }
      res.redirect('/login');
    });
  });

  // User routes
  app.get("/api/users/current", async (req, res) => {
    try {
      // Pour le moment, retourner le dernier utilisateur créé (non-test)
      const users = await storage.getAllUsers();
      const realUsers = users.filter(u => !u.isTestProfile);
      
      if (realUsers.length > 0) {
        // Prendre le dernier utilisateur créé (plus récent)
        const currentUser = realUsers[realUsers.length - 1];
        res.json(currentUser);
      } else {
        res.status(401).json({ message: "Non connecté" });
      }
    } catch (error) {
      console.error("[AUTH] Erreur récupération utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/users/suggestions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const currentUser = await storage.getUser(userId);
      
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const allUsers = await storage.getAllUsers();
      const userMatches = await storage.getUserMatches(userId);
      const matchedUserIds = userMatches.flatMap(match => [match.user1Id, match.user2Id]);

      // Get users not already matched and not self
      let suggestions = allUsers.filter(user => 
        user.id !== userId && 
        !matchedUserIds.includes(user.id)
      );

      // Prioritize Gold users first, then Premium, then Free
      suggestions.sort((a, b) => {
        const subscriptionOrder = { gold: 3, premium: 2, gratuit: 1 };
        return subscriptionOrder[b.subscription] - subscriptionOrder[a.subscription];
      });

      // Prioritize users from same city
      suggestions.sort((a, b) => {
        if (a.city === currentUser.city && b.city !== currentUser.city) return -1;
        if (b.city === currentUser.city && a.city !== currentUser.city) return 1;
        return 0;
      });

      res.json({ suggestions: suggestions.slice(0, 10) });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Flash routes
  app.post("/api/flashes", async (req, res) => {
    try {
      const flashData = insertFlashSchema.parse(req.body);
      const fromUser = await storage.getUser(flashData.fromUserId);
      
      if (!fromUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Check daily flash limit
      const today = new Date();
      const dailyFlashes = await storage.getUserFlashesCount(flashData.fromUserId, today);
      
      const flashLimits = {
        gratuit: 3,
        premium: 20,
        gold: Infinity
      };

      if (dailyFlashes >= flashLimits[fromUser.subscription]) {
        return res.status(400).json({ message: "Limite de flashs quotidiens atteinte" });
      }

      // Check for duplicate flash
      const existingFlashes = await storage.getFlashsBetweenUsers(flashData.fromUserId, flashData.toUserId);
      const alreadyFlashed = existingFlashes.some(flash => flash.fromUserId === flashData.fromUserId);
      
      if (alreadyFlashed) {
        return res.status(400).json({ message: "Vous avez déjà flashé cet utilisateur" });
      }

      const flash = await storage.createFlash(flashData);

      // Get receiver info for email notification
      const toUser = await storage.getUser(flashData.toUserId);
      
      // Send flash notification email
      if (toUser && toUser.email) {
        await emailService.sendFlashNotification({
          receiverEmail: toUser.email,
          receiverFirstName: toUser.firstName,
          senderName: fromUser.firstName,
          senderAge: fromUser.age,
          senderCity: fromUser.city,
          additionalCount: 0 // Peut être calculé si nécessaire
        });
      }

      // Check if this creates a match
      const reverseFlash = existingFlashes.find(f => f.fromUserId === flashData.toUserId);
      if (reverseFlash) {
        const match = await storage.createMatch(flashData.fromUserId, flashData.toUserId);
        
        // Create notifications for both users
        await storage.createNotification({
          userId: flashData.fromUserId,
          type: 'match',
          title: 'Nouveau match !',
          message: 'Vous avez un nouveau match',
          isRead: false
        });

        await storage.createNotification({
          userId: flashData.toUserId,
          type: 'match',
          title: 'Nouveau match !',
          message: 'Vous avez un nouveau match',
          isRead: false
        });

        // Send match notification emails
        if (fromUser.email && toUser) {
          await emailService.sendMatchNotification({
            userEmail: fromUser.email,
            userFirstName: fromUser.firstName,
            matchName: toUser.firstName,
            matchAge: toUser.age,
            matchCity: toUser.city
          });
          
          if (toUser.email) {
            await emailService.sendMatchNotification({
              userEmail: toUser.email,
              userFirstName: toUser.firstName,
              matchName: fromUser.firstName,
              matchAge: fromUser.age,
              matchCity: fromUser.city
            });
          }
        }

        return res.json({ flash, match, isMatch: true });
      }

      res.json({ flash, isMatch: false });
    } catch (error) {
      res.status(400).json({ message: "Données invalides" });
    }
  });

  app.get("/api/flashes/remaining/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const today = new Date();
      const dailyFlashes = await storage.getUserFlashesCount(userId, today);
      
      const flashLimits = {
        gratuit: 3,
        premium: 20,
        gold: Infinity
      };

      const remaining = Math.max(0, flashLimits[user.subscription] - dailyFlashes);
      
      res.json({ 
        remaining: user.subscription === 'gold' ? 'unlimited' : remaining,
        used: dailyFlashes,
        limit: user.subscription === 'gold' ? 'unlimited' : flashLimits[user.subscription]
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Match routes
  app.get("/api/matches", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo pour les tests
      console.log(`[MATCHES] Récupération des matches pour l'utilisateur ${userId}`);
      
      const matches = await storage.getUserMatches(userId);
      console.log(`[MATCHES] ${matches.length} matches trouvés`);
      
      const matchesWithUsers = await Promise.all(
        matches.map(async (match) => {
          const partnerId = match.user1Id === userId ? match.user2Id : match.user1Id;
          const partner = await storage.getUser(partnerId);
          const messages = await storage.getConversationMessages(userId, partnerId);
          const lastMessage = messages[messages.length - 1];
          const unreadCount = messages.filter(msg => msg.senderId === partnerId && !msg.isRead).length;
          
          console.log(`[MATCHES] Match avec ${partner?.firstName} - ${messages.length} messages`);
          
          return {
            ...match,
            partner,
            lastMessage,
            unreadCount
          };
        })
      );

      res.json({ matches: matchesWithUsers });
    } catch (error) {
      console.error("[MATCHES] Erreur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/matches/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const matches = await storage.getUserMatches(userId);
      
      const matchesWithUsers = await Promise.all(
        matches.map(async (match) => {
          const partnerId = match.user1Id === userId ? match.user2Id : match.user1Id;
          const partner = await storage.getUser(partnerId);
          const messages = await storage.getConversationMessages(userId, partnerId);
          const lastMessage = messages[messages.length - 1];
          const unreadCount = messages.filter(msg => msg.senderId === partnerId && !msg.isRead).length;
          
          return {
            ...match,
            partner,
            lastMessage,
            unreadCount
          };
        })
      );

      res.json({ matches: matchesWithUsers });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Message routes
  app.get("/api/messages/:user1Id/:user2Id", async (req, res) => {
    try {
      const user1Id = parseInt(req.params.user1Id);
      const user2Id = parseInt(req.params.user2Id);

      // Verify match exists
      const match = await storage.checkMatch(user1Id, user2Id);
      if (!match) {
        return res.status(403).json({ message: "Vous devez être matchés pour voir les messages" });
      }

      const messages = await storage.getConversationMessages(user1Id, user2Id);
      res.json({ messages });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/messages/read", async (req, res) => {
    try {
      const { senderId, receiverId } = req.body;
      await storage.markMessagesAsRead(senderId, receiverId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Notification routes
  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const notifications = await storage.getUserNotifications(userId);
      res.json({ notifications });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Route admin users déjà définie plus haut

  app.post("/api/admin/generate-profiles", async (req, res) => {
    try {
      const profiles = generateTestProfiles();
      
      for (const profile of profiles) {
        await storage.createUser({
          ...profile,
          isTestProfile: true
        });
      }

      res.json({ message: "50 profils de test générés avec succès", count: profiles.length });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la génération des profils" });
    }
  });

  app.get("/api/admin/test-profiles", async (req, res) => {
    try {
      const profiles = await storage.getTestProfiles();
      res.json({ profiles });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des profils" });
    }
  });

  // NOUVELLE ROUTE ADMIN PROFILE - SOLUTION DIRECTE SQL
  app.put("/api/admin/profile/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      console.log('[ADMIN-PROFILE-SQL] ==> Début mise à jour directe ID:', id);
      console.log('[ADMIN-PROFILE-SQL] ==> Updates reçus:', JSON.stringify(updates));
      
      // Mise à jour directe en SQL pour éviter les problèmes ORM
      const updateFields: string[] = [];
      const values: any[] = [];
      let paramIndex = 1;
      
      if (updates.firstName && updates.firstName.trim()) {
        updateFields.push(`"firstName" = $${paramIndex++}`);
        values.push(updates.firstName.trim());
      }
      
      if (updates.age && updates.age > 0) {
        updateFields.push(`age = $${paramIndex++}`);
        values.push(updates.age);
      }
      
      if (updates.city && updates.city.trim()) {
        updateFields.push(`city = $${paramIndex++}`);
        values.push(updates.city.trim());
      }
      
      if (updates.bio !== undefined) {
        updateFields.push(`bio = $${paramIndex++}`);
        values.push(updates.bio);
      }
      
      if (updates.subscription) {
        updateFields.push(`subscription = $${paramIndex++}`);
        values.push(updates.subscription);
      }
      
      if (updates.photos && Array.isArray(updates.photos)) {
        updateFields.push(`photos = $${paramIndex++}`);
        values.push(JSON.stringify(updates.photos));
      }
      
      if (updateFields.length === 0) {
        return res.status(400).json({ message: "Aucune donnée à mettre à jour" });
      }
      
      values.push(id); // ID pour le WHERE
      
      const sqlQuery = `
        UPDATE users 
        SET ${updateFields.join(', ')} 
        WHERE id = $${paramIndex}
        RETURNING id, "firstName", age, city, bio, subscription, photos
      `;
      
      console.log('[ADMIN-PROFILE-SQL] ==> Requête SQL:', sqlQuery);
      console.log('[ADMIN-PROFILE-SQL] ==> Valeurs:', values);
      
      const result = await db.execute(sql.raw(sqlQuery, values));
      
      if (result.rows && result.rows.length > 0) {
        const updatedUser = result.rows[0];
        console.log('[ADMIN-PROFILE-SQL] ==> ✅ SUCCÈS mise à jour:', updatedUser.firstName);
        res.json({ message: "Profil mis à jour avec succès", profile: updatedUser });
      } else {
        console.log('[ADMIN-PROFILE-SQL] ==> ❌ Aucun utilisateur trouvé avec ID:', id);
        res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
    } catch (error) {
      console.error('[ADMIN-PROFILE-SQL] ==> ERREUR EXCEPTION:', error);
      res.status(500).json({ message: "Erreur serveur lors de la mise à jour" });
    }
  });

  app.delete("/api/admin/test-profiles", async (req, res) => {
    try {
      await storage.deleteTestProfiles();
      res.json({ message: "Tous les profils de test ont été supprimés" });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression" });
    }
  });

  // Endpoint pour téléchargement ebook depuis Instagram/Facebook
  app.post("/api/ebook/download", async (req, res) => {
    try {
      const { email, firstName = "Prospect" } = req.body;
      
      if (!email || !email.includes('@')) {
        return res.status(400).json({ message: "Email invalide" });
      }

      // Ajouter au groupe spécial pour téléchargeurs d'ebook
      try {
        const success = await emailService.addToEbookDownloaders(email, firstName);
        if (success) {
          console.log(`[EBOOK] Téléchargement ebook: ${firstName} (${email})`);
          res.json({ 
            success: true, 
            message: "Email enregistré pour l'ebook",
            downloadUrl: "/assets/guide-rencontres-seniors.pdf"
          });
        } else {
          res.status(500).json({ message: "Erreur enregistrement email" });
        }
      } catch (error) {
        console.error("Erreur MailerLite ebook:", error);
        res.status(500).json({ message: "Service temporairement indisponible" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Endpoint pour créer des conversations de démonstration
  app.post("/api/admin/create-demo-conversations", async (req, res) => {
    try {
      const currentUser = await storage.getUser(1); // Utilisateur démo
      if (!currentUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Créer quelques matches avec des profils de test
      const testProfiles = await storage.getTestProfiles();
      if (testProfiles.length === 0) {
        return res.status(400).json({ message: "Aucun profil de test disponible. Générez d'abord des profils." });
      }

      const selectedProfiles = testProfiles.slice(0, 2); // Prendre 2 profils pour des conversations
      let createdConversations = 0;

      for (const profile of selectedProfiles) {
        // Vérifier si le match existe déjà
        const existingMatch = await storage.checkMatch(currentUser.id, profile.id);
        if (!existingMatch) {
          // Créer un match
          await storage.createMatch(currentUser.id, profile.id);
        }

        // Créer des messages de conversation réalistes
        const messages = [
          `Bonjour ! Ravi de notre match, j'ai hâte de vous connaître !`,
          `Comment allez-vous aujourd'hui ?`,
          `J'espère que nous aurons l'occasion d'échanger davantage.`
        ];

        // Créer des messages alternés
        for (let i = 0; i < messages.length; i++) {
          const isFromProfile = i % 2 === 0;
          await storage.createMessage({
            senderId: isFromProfile ? profile.id : currentUser.id,
            receiverId: isFromProfile ? currentUser.id : profile.id,
            content: messages[i]
          });
        }
        createdConversations++;
      }

      console.log(`[DEMO] Créé ${createdConversations} conversations`);
      res.json({ 
        message: "Conversations de démonstration créées avec succès", 
        conversationsCount: createdConversations 
      });
    } catch (error) {
      console.error("Erreur lors de la création des conversations:", error);
      res.status(500).json({ message: "Erreur lors de la création des conversations: " + (error as Error).message });
    }
  });

  // Referral routes
  app.get("/api/referral/info", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const referrals = await storage.getUserReferrals(userId);
      const totalRewards = referrals
        .filter(r => r.status === 'rewarded')
        .reduce((sum, r) => sum + r.rewardAmount, 0);

      res.json({
        referralCode: user.referralCode,
        referrals,
        totalRewards,
        bonusFlashes: user.bonusFlashes || 0,
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/referral/generate", async (req, res) => {
    try {
      const userId = 1; // Utilisateur démo
      // Force regeneration of referral code with new MATURE prefix
      const code = await storage.generateReferralCode(userId);
      
      res.json({
        referralCode: code,
        message: "Code de parrainage créé avec succès"
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la génération du code" });
    }
  });

  app.post("/api/referral/use", async (req, res) => {
    try {
      const { referralCode, newUserId } = req.body;
      
      if (!referralCode || !newUserId) {
        return res.status(400).json({ message: "Code de parrainage et ID utilisateur requis" });
      }

      const referrer = await storage.getUserByReferralCode(referralCode);
      if (!referrer) {
        return res.status(404).json({ message: "Code de parrainage invalide" });
      }

      // Créer le parrainage
      const referral = await storage.createReferral({
        referrerId: referrer.id,
        referredId: newUserId,
        status: 'completed',
        rewardType: 'bonus_flashes',
        rewardAmount: 10,
      });

      // Donner les récompenses
      await storage.applyReferralBonus(referrer.id, 'bonus_flashes', 10);
      await storage.applyReferralBonus(newUserId, 'bonus_flashes', 5);

      // Marquer comme récompensé
      await storage.processReferralReward(referral.id);

      res.json({
        message: "Parrainage appliqué avec succès",
        referrerReward: 10,
        newUserReward: 5,
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de l'application du parrainage" });
    }
  });

  // Route de création d'intention de paiement Stripe (test)
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, plan } = req.body;
      
      // En mode test, on simule la création d'une intention de paiement avec le bon format
      const randomId = Math.random().toString(36).substring(2, 15);
      const randomSecret = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const mockClientSecret = `pi_${randomId}_secret_${randomSecret}`;
      
      console.log(`[TEST] Création intention de paiement: ${plan} - ${amount}€`);
      
      res.json({ 
        clientSecret: mockClientSecret,
        plan,
        amount 
      });
    } catch (error: any) {
      console.error("Erreur création intention paiement:", error);
      res.status(500).json({ 
        message: "Erreur lors de la création de l'intention de paiement: " + error.message 
      });
    }
  });

  // Route d'inscription à la newsletter MailerLite
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email, firstName } = req.body;
      
      if (!email || !firstName) {
        return res.status(400).json({ 
          message: "Email et prénom requis" 
        });
      }

      // Validation email simple
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ 
          message: "Format d'email invalide" 
        });
      }

      // Intégration MailerLite
      if (process.env.MAILERLITE_API_KEY) {
        try {
          const mailerLiteResponse = await fetch('https://connect.mailerlite.com/api/subscribers', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.MAILERLITE_API_KEY}`,
              'Accept': 'application/json'
            },
            body: JSON.stringify({
              email: email,
              fields: {
                name: firstName,
                source: 'Newsletter Popup',
                date_inscription: new Date().toISOString().split('T')[0]
              }
            })
          });

          if (mailerLiteResponse.ok || mailerLiteResponse.status === 422) {
            // Ajouter au groupe "Newsletter prospects (popup)" pour automation ebook
            try {
              const groupsResponse = await fetch('https://connect.mailerlite.com/api/groups', {
                headers: {
                  'Authorization': `Bearer ${process.env.MAILERLITE_API_KEY}`,
                  'Accept': 'application/json'
                }
              });

              if (groupsResponse.ok) {
                const groups = await groupsResponse.json();
                let targetGroup = groups.data.find((g: any) => g.name === 'Newsletter prospects (popup)');
                
                if (!targetGroup) {
                  // Créer le groupe pour l'ebook
                  const createGroupResponse = await fetch('https://connect.mailerlite.com/api/groups', {
                    method: 'POST',
                    headers: {
                      'Authorization': `Bearer ${process.env.MAILERLITE_API_KEY}`,
                      'Content-Type': 'application/json',
                      'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                      name: 'Newsletter prospects (popup)',
                      type: 'default'
                    })
                  });
                  
                  if (createGroupResponse.ok) {
                    const newGroup = await createGroupResponse.json();
                    targetGroup = newGroup.data;
                    console.log(`[MAILERLITE] ✅ Groupe "Newsletter prospects (popup)" créé pour ebook`);
                  }
                }
                
                if (targetGroup) {
                  // Ajouter au groupe pour déclencher l'automation ebook
                  await fetch(`https://connect.mailerlite.com/api/subscribers/${email}/groups/${targetGroup.id}`, {
                    method: 'POST',
                    headers: {
                      'Authorization': `Bearer ${process.env.MAILERLITE_API_KEY}`,
                      'Accept': 'application/json'
                    }
                  });
                  
                  console.log(`[MAILERLITE] ✅ ${firstName} ajouté au groupe Newsletter (prêt pour ebook)`);
                }
              }
            } catch (groupError) {
              console.warn('[MAILERLITE] Erreur ajout au groupe:', groupError);
            }

            console.log(`[MAILERLITE] ✅ Inscription réussie: ${firstName} - ${email}`);
            res.json({ 
              message: "Inscription réussie !",
              success: true
            });
          } else {
            const errorData = await mailerLiteResponse.json();
            console.error('[MAILERLITE] Erreur:', errorData);
            
            // Si l'email existe déjà, c'est aussi un succès
            if (errorData.message && errorData.message.includes('already exists')) {
              res.json({ 
                message: "Vous êtes déjà inscrit à notre newsletter !",
                success: true
              });
            } else {
              res.status(400).json({ 
                message: "Erreur lors de l'inscription"
              });
            }
          }
        } catch (fetchError) {
          console.error('[MAILERLITE] Erreur de connexion:', fetchError);
          res.status(500).json({ 
            message: "Erreur de connexion"
          });
        }
      } else {
        // Mode développement - affichage dans les logs
        console.log(`[NEWSLETTER-DEV] 📧 Nouvelle inscription: ${firstName} - ${email}`);
        res.json({ 
          message: "Inscription réussie ! (mode développement)",
          success: true
        });
      }
    } catch (error: any) {
      console.error("Erreur inscription newsletter:", error);
      res.status(500).json({ 
        message: "Erreur lors de l'inscription: " + error.message 
      });
    }
  });

  // Route pour identifier automatiquement le genre des profils existants
  app.post("/api/admin/identify-genders", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      let updatedCount = 0;
      
      // Dictionnaire des prénoms français les plus courants
      const maleNames = new Set([
        'jean', 'michel', 'pierre', 'andré', 'philippe', 'jacques', 'bernard', 'claude', 'françois', 'daniel',
        'marc', 'paul', 'patrick', 'christian', 'pascal', 'gerard', 'henri', 'thierry', 'laurent', 'serge',
        'alain', 'robert', 'didier', 'bruno', 'denis', 'yves', 'frederic', 'stephane', 'david', 'nicolas',
        'christophe', 'vincent', 'olivier', 'eric', 'sebastien', 'jerome', 'antoine', 'julien', 'alexandre',
        'fabrice', 'maurice', 'rene', 'roger', 'louis', 'lucien', 'raymond', 'albert', 'charles', 'georges',
        'andre', 'gerard', 'fredéric', 'stéphane', 'sébastien', 'jérôme', 'rené'
      ]);
      
      const femaleNames = new Set([
        'marie', 'françoise', 'monique', 'christine', 'isabelle', 'catherine', 'sylvie', 'anne', 'nicole', 'brigitte',
        'nathalie', 'chantal', 'martine', 'claire', 'veronique', 'dominique', 'michele', 'patricia', 'pascale',
        'sandrine', 'valerie', 'corinne', 'sophie', 'florence', 'laurence', 'karine', 'sabine', 'nadine',
        'carole', 'helene', 'danielle', 'jacqueline', 'odette', 'suzanne', 'simone', 'yvette', 'francine',
        'caroline', 'aurelie', 'stephanie', 'melissa', 'celine', 'virginie', 'laetitia', 'emilie', 'julie',
        'francoise', 'véronique', 'michèle', 'valérie', 'hélène', 'aurélie', 'stéphanie', 'mélissa', 'céline'
      ]);

      for (const user of users) {
        // Si le genre n'est pas défini, essayer de l'identifier
        if (!(user as any).gender && user.firstName) {
          const firstName = user.firstName.toLowerCase().trim();
          let identifiedGender: 'H' | 'F' | null = null;
          
          if (maleNames.has(firstName)) {
            identifiedGender = 'H';
          } else if (femaleNames.has(firstName)) {
            identifiedGender = 'F';
          }
          
          if (identifiedGender) {
            await storage.updateUser(user.id, { gender: identifiedGender });
            updatedCount++;
            console.log(`[GENDER-ID] ${user.firstName} → ${identifiedGender}`);
          }
        }
      }

      res.json({ 
        message: `Genre identifié pour ${updatedCount} profils`,
        updatedCount,
        totalUsers: users.length
      });
    } catch (error) {
      console.error("Erreur identification genres:", error);
      res.status(500).json({ message: "Erreur lors de l'identification des genres" });
    }
  });

  // Route de test d'email avec profils
  app.post("/api/test-email", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }

      // Créer un email attractif avec des profils
      const emailSuccess = await emailService.sendDailyDigest({
        userEmail: email,
        userFirstName: "Thomas",
        newFlashes: 5,
        newVisits: 8,
        newMatches: 2,
        suggestedProfiles: [
          { name: "Marie", age: 52, city: "Paris" },
          { name: "Sylvie", age: 48, city: "Lyon" },
          { name: "Catherine", age: 46, city: "Marseille" },
          { name: "Nicole", age: 54, city: "Toulouse" }
        ]
      });

      if (emailSuccess) {
        res.json({ 
          message: "Email de test envoyé avec succès !",
          success: true 
        });
      } else {
        res.status(500).json({ 
          message: "Erreur lors de l'envoi de l'email de test" 
        });
      }
    } catch (error: any) {
      console.error("Erreur test email:", error);
      res.status(500).json({ 
        message: "Erreur lors du test d'email: " + error.message 
      });
    }
  });

  // Route pour mettre à jour un profil utilisateur (admin)
  app.put("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      // Validation des données
      if (updates.age && (updates.age < 40 || updates.age > 75)) {
        return res.status(400).json({ message: "L'âge doit être entre 40 et 75 ans" });
      }
      
      if (updates.bio && updates.bio.length > 300) {
        return res.status(400).json({ message: "La bio ne peut pas dépasser 300 caractères" });
      }
      
      // Mettre à jour l'utilisateur
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      console.log(`[ADMIN] Profil mis à jour: ${updatedUser.firstName} (ID: ${userId})`);
      res.json({ 
        message: "Profil mis à jour avec succès", 
        user: updatedUser 
      });
    } catch (error) {
      console.error("Erreur mise à jour profil:", error);
      res.status(500).json({ message: "Erreur lors de la mise à jour du profil" });
    }
  });

  // Admin route pour supprimer un utilisateur
  app.delete('/api/admin/users/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      console.log('[ADMIN] Suppression demandée pour utilisateur:', userId);
      
      const deleted = await storage.deleteUser(userId);
      if (deleted) {
        console.log('[ADMIN] Utilisateur supprimé avec succès:', userId);
        res.json({ message: 'Utilisateur supprimé avec succès' });
      } else {
        console.log('[ADMIN] Utilisateur non trouvé:', userId);
        res.status(404).json({ message: 'Utilisateur non trouvé' });
      }
    } catch (error) {
      console.error('[ADMIN] Erreur lors de la suppression de l\'utilisateur:', error);
      res.status(500).json({ message: 'Erreur serveur' });
    }
  });

  // Admin dashboard metrics routes
  app.get("/api/admin/dashboard", async (req, res) => {
    try {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      
      // Stats globales
      const totalUsers = await storage.getAllUsers();
      const realUsers = totalUsers.filter(u => !u.isTestProfile);
      const premiumUsers = realUsers.filter(u => u.subscription === 'premium');
      const goldUsers = realUsers.filter(u => u.subscription === 'gold');
      
      // Matches et flashes total
      const allMatches = await storage.getAllMatches();
      const allFlashes = await storage.getAllFlashes();
      
      // Métriques du jour
      const todayUsers = realUsers.filter(u => {
        const userDate = new Date(u.createdAt);
        return userDate.toISOString().split('T')[0] === todayStr;
      });
      
      const todayFlashes = allFlashes.filter(f => {
        const flashDate = new Date(f.createdAt);
        return flashDate.toISOString().split('T')[0] === todayStr;
      });
      
      const todayMatches = allMatches.filter(m => {
        const matchDate = new Date(m.createdAt);
        return matchDate.toISOString().split('T')[0] === todayStr;
      });

      // Activité des 7 derniers jours
      const last7Days = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayUsers = realUsers.filter(u => {
          const userDate = new Date(u.createdAt);
          return userDate.toISOString().split('T')[0] === dateStr;
        }).length;
        
        const dayFlashes = allFlashes.filter(f => {
          const flashDate = new Date(f.createdAt);
          return flashDate.toISOString().split('T')[0] === dateStr;
        }).length;
        
        const dayMatches = allMatches.filter(m => {
          const matchDate = new Date(m.createdAt);
          return matchDate.toISOString().split('T')[0] === dateStr;
        }).length;

        last7Days.push({
          date: dateStr,
          users: dayUsers,
          flashes: dayFlashes,
          matches: dayMatches
        });
      }

      // Répartition par ville
      const cityStats = realUsers.reduce((acc, user) => {
        acc[user.city] = (acc[user.city] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      // Répartition par âge
      const ageGroups = {
        '40-45': realUsers.filter(u => u.age >= 40 && u.age <= 45).length,
        '46-50': realUsers.filter(u => u.age >= 46 && u.age <= 50).length,
        '51-55': realUsers.filter(u => u.age >= 51 && u.age <= 55).length,
        '56-60': realUsers.filter(u => u.age >= 56 && u.age <= 60).length,
        '61-65': realUsers.filter(u => u.age >= 61 && u.age <= 65).length,
        '66-70': realUsers.filter(u => u.age >= 66 && u.age <= 70).length,
        '71-75': realUsers.filter(u => u.age >= 71 && u.age <= 75).length,
      };

      // Taux de conversion
      const conversionRate = realUsers.length > 0 ? ((premiumUsers.length + goldUsers.length) / realUsers.length * 100).toFixed(1) : 0;
      const matchRate = realUsers.length > 0 ? (allMatches.length / realUsers.length * 100).toFixed(1) : 0;

      res.json({
        overview: {
          totalUsers: realUsers.length,
          premiumUsers: premiumUsers.length,
          goldUsers: goldUsers.length,
          totalMatches: allMatches.length,
          totalFlashes: allFlashes.length,
          conversionRate: parseFloat(conversionRate as string),
          matchRate: parseFloat(matchRate as string)
        },
        today: {
          newUsers: todayUsers.length,
          newFlashes: todayFlashes.length,
          newMatches: todayMatches.length
        },
        chartData: {
          last7Days,
          cityStats: Object.entries(cityStats)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([city, count]) => ({ city, count })),
          ageGroups
        }
      });
    } catch (error) {
      console.error("Erreur récupération métriques admin:", error);
      res.status(500).json({ error: "Erreur récupération métriques" });
    }
  });

  // Route de génération de profils par région/ville
  app.post('/api/admin/generate-regional-profiles', async (req, res) => {
    try {
      const { region, count = 20 } = req.body;
      
      if (!region) {
        return res.status(400).json({ message: "Région requise" });
      }
      
      if (count < 5 || count > 50) {
        return res.status(400).json({ message: "Le nombre doit être entre 5 et 50" });
      }
      
      // Définition des 13 régions françaises avec leurs villes
      const regions = {
        'ile-de-france': ['Paris', 'Boulogne-Billancourt', 'Saint-Denis', 'Argenteuil', 'Versailles', 'Montreuil', 'Créteil', 'Nanterre', 'Courbevoie', 'Colombes'],
        'provence': ['Marseille', 'Aix-en-Provence', 'Avignon', 'Toulon', 'Nice', 'Cannes', 'Antibes', 'Arles', 'Salon-de-Provence', 'Martigues'],
        'bretagne': ['Rennes', 'Brest', 'Quimper', 'Lorient', 'Vannes', 'Saint-Malo', 'Saint-Brieuc', 'Lannion', 'Concarneau', 'Morlaix'],
        'normandie': ['Rouen', 'Le Havre', 'Caen', 'Cherbourg', 'Évreux', 'Alençon', 'Lisieux', 'Bayeux', 'Dieppe', 'Fécamp'],
        'nouvelle-aquitaine': ['Bordeaux', 'Pau', 'Bayonne', 'Périgueux', 'Agen', 'Mont-de-Marsan', 'Bergerac', 'Dax', 'Biarritz', 'Arcachon'],
        'auvergne-rhone-alpes': ['Lyon', 'Grenoble', 'Saint-Étienne', 'Chambéry', 'Annecy', 'Valence', 'Bourg-en-Bresse', 'Privas', 'Le Puy-en-Velay', 'Albertville'],
        'hauts-de-france': ['Lille', 'Valenciennes', 'Dunkerque', 'Douai', 'Arras', 'Calais', 'Boulogne-sur-Mer', 'Cambrai', 'Roubaix', 'Tourcoing'],
        'centre-val-de-loire': ['Orléans', 'Tours', 'Bourges', 'Blois', 'Chartres', 'Châteauroux', 'Montargis', 'Dreux', 'Vendôme', 'Chinon'],
        'grand-est': ['Strasbourg', 'Mulhouse', 'Colmar', 'Haguenau', 'Sélestat', 'Saverne', 'Obernai', 'Ribeauvillé', 'Munster', 'Wissembourg'],
        'occitanie': ['Toulouse', 'Montpellier', 'Perpignan', 'Nîmes', 'Béziers', 'Carcassonne', 'Albi', 'Tarbes', 'Auch', 'Cahors'],
        'pays-de-la-loire': ['Nantes', 'Angers', 'Le Mans', 'Saint-Nazaire', 'Cholet', 'Laval', 'La Roche-sur-Yon', 'Rezé', 'Saint-Sébastien-sur-Loire', 'Saumur'],
        'bourgogne-franche-comte': ['Dijon', 'Besançon', 'Belfort', 'Chalon-sur-Saône', 'Nevers', 'Auxerre', 'Mâcon', 'Montbéliard', 'Sens', 'Le Creusot'],
        'corse': ['Ajaccio', 'Bastia', 'Porto-Vecchio', 'Bonifacio', 'Corte', 'Calvi', 'Propriano', 'Sartène', 'Ghisonaccia', 'Saint-Florent']
      };

      const cities = regions[region] || ['Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nice', 'Nantes', 'Montpellier', 'Strasbourg', 'Bordeaux', 'Lille'];
      
      // Noms français authentiques par genre
      const maleNames = ['Jean', 'Pierre', 'Michel', 'André', 'Philippe', 'Alain', 'Bernard', 'Patrick', 'Claude', 'Daniel', 'François', 'Gérard', 'Christian', 'Serge', 'René', 'Thierry', 'Henri', 'Robert', 'Marcel', 'Louis'];
      const femaleNames = ['Marie', 'Françoise', 'Monique', 'Brigitte', 'Catherine', 'Sylvie', 'Martine', 'Nicole', 'Danielle', 'Jacqueline', 'Colette', 'Christiane', 'Odette', 'Simone', 'Denise', 'Yvette', 'Claudine', 'Éliane', 'Michèle', 'Annie'];
      
      const interests = ['Lecture', 'Cinéma', 'Randonnée', 'Jardinage', 'Cuisine', 'Voyages', 'Art', 'Musique', 'Natation', 'Yoga', 'Théâtre', 'Photographie', 'Bridge', 'Danse', 'Cyclisme', 'Pêche', 'Bricolage', 'Tricot', 'Histoire', 'Bénévolat'];
      
      const bios = [
        'Retraité actif, je partage mon temps entre mes petits-enfants et mes passions.',
        'Passionné de nature, j\'aime les balades et les moments de tranquillité.',
        'Ancien professeur, je cultive ma curiosité à travers les voyages et la lecture.',
        'Sportif dans l\'âme, je maintiens ma forme et cherche un partenaire actif.',
        'Artiste amateur, je peins et dessine pour exprimer ma créativité.',
        'Veuf depuis peu, je souhaite retrouver la joie de partager avec quelqu\'un de spécial.',
        'Ex-cadre d\'entreprise, je savoure enfin le temps libre pour mes loisirs favoris.',
        'Épicurien dans l\'âme, j\'apprécie les plaisirs simples de la vie.',
        'Amoureuse de la nature, je profite de ma retraite pour découvrir de nouveaux horizons.',
        'Grand-mère comblée, je cherche une compagne pour profiter pleinement de la retraite.'
      ];

      let createdCount = 0;
      for (let i = 0; i < count; i++) {
        const gender = Math.random() > 0.5 ? 'H' : 'F';
        const names = gender === 'H' ? maleNames : femaleNames;
        const firstName = names[Math.floor(Math.random() * names.length)];
        const city = cities[Math.floor(Math.random() * cities.length)];
        const age = Math.floor(Math.random() * 26) + 40; // 40-65 ans
        const bio = bios[Math.floor(Math.random() * bios.length)];
        const userInterests = interests.sort(() => 0.5 - Math.random()).slice(0, Math.floor(Math.random() * 4) + 2);
        
        const user = {
          firstName,
          gender,
          age,
          city,
          bio,
          interests: userInterests,
          photo: `https://randomuser.me/api/portraits/${gender === 'H' ? 'men' : 'women'}/${Math.floor(Math.random() * 99) + 1}.jpg`,
          subscription: 'gratuit',
          email: `${firstName.toLowerCase().replace(/[àâäéèêëïîôöùûüÿç]/g, (m) => {
            const map = { 'à': 'a', 'â': 'a', 'ä': 'a', 'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e', 'ï': 'i', 'î': 'i', 'ô': 'o', 'ö': 'o', 'ù': 'u', 'û': 'u', 'ü': 'u', 'ÿ': 'y', 'ç': 'c' };
            return map[m] || m;
          })}${age}@example.com`,
          dailyFlashesUsed: 0,
          isTestProfile: false,
          createdAt: new Date()
        };
        
        await storage.createUser(user);
        createdCount++;
      }

      res.json({
        message: `${createdCount} profils ${region} créés avec succès`,
        created: createdCount,
        region
      });
    } catch (error: any) {
      console.error("Erreur génération profils régionaux:", error);
      res.status(500).json({ message: "Erreur lors de la génération: " + error.message });
    }
  });

  // Route de récupération des données PostgreSQL existantes
  app.post('/api/admin/recover-postgres', async (req, res) => {
    try {
      // Récupération directe depuis PostgreSQL avec l'ancien schéma
      const postgresUsers = await db.execute(`SELECT * FROM users ORDER BY "createdAt" DESC`);
      
      let recoveredCount = 0;
      
      for (const row of postgresUsers.rows) {
        try {
          // Convertir les données PostgreSQL vers le format actuel
          const userData = {
            firstName: row.first_name || row.firstName,
            age: parseInt(row.age),
            city: row.city,
            bio: row.bio,
            interests: Array.isArray(row.interests) ? row.interests : [],
            photo: row.photo,
            subscription: row.subscription || 'gratuit',
            email: row.email,
            gender: 'F', // Par défaut pour les profils existants
            dailyFlashesUsed: parseInt(row.daily_flashes_used) || 0,
            isTestProfile: false,
            createdAt: new Date(row.created_at || Date.now())
          };
          
          // Créer dans le stockage actuel
          await storage.createUser(userData);
          recoveredCount++;
          
          console.log(`✅ Récupéré: ${userData.firstName} (${userData.city})`);
        } catch (error) {
          console.error(`❌ Erreur profil ${row.first_name}:`, error.message);
        }
      }
      
      res.json({ 
        message: `${recoveredCount} profils récupérés depuis PostgreSQL`,
        recovered: recoveredCount,
        total: postgresUsers.rows.length
      });
    } catch (error) {
      console.error("Erreur récupération PostgreSQL:", error);
      res.status(500).json({ message: "Erreur lors de la récupération: " + error.message });
    }
  });

  // Routes pour backup/restore des données - priorité sur Vite
  // Upload de profils depuis fichier JSON
  app.post('/api/admin/upload-profiles', async (req, res) => {
    try {
      console.log('📤 Requête upload reçue, body:', typeof req.body, Object.keys(req.body));
      let profiles = req.body.profiles;
      
      // Si c'est directement un tableau, on l'utilise
      if (Array.isArray(req.body)) {
        profiles = req.body;
      }
      
      if (!profiles || !Array.isArray(profiles)) {
        console.log('❌ Format invalide:', { profiles: typeof profiles, isArray: Array.isArray(profiles), body: req.body });
        return res.status(400).json({ message: 'Format de profils invalide - attendu {profiles: [...]} ou [...]' });
      }

      let imported = 0;
      for (const profile of profiles) {
        try {
          // Valider et insérer le profil
          const newProfile = {
            firstName: profile.firstName || profile.prenom || 'Anonyme',
            gender: profile.gender || profile.sexe || 'F',
            age: profile.age || Math.floor(Math.random() * 30) + 40,
            city: profile.city || profile.ville || 'Paris',
            bio: profile.bio || profile.description || 'Bio à compléter',
            interests: Array.isArray(profile.interests) ? profile.interests : ['Voyages', 'Lecture'],
            photo: profile.photo || profile.photoUrl || `https://randomuser.me/api/portraits/${profile.gender === 'H' ? 'men' : 'women'}/${Math.floor(Math.random() * 99) + 1}.jpg`,
            subscription: 'gratuit',
            email: profile.email || `${profile.firstName?.toLowerCase() || 'user'}${Math.floor(Math.random() * 1000)}@example.com`,
            dailyFlashesUsed: 0,
            lastFlashReset: new Date(),
            isTestProfile: false,
            referralCode: null,
            referredById: null,
            bonusFlashes: 0,
            subscriptionEndDate: null,
            lookingFor: 'relation-serieuse',
            height: null,
            profession: null,
            children: 'non-renseigne',
            smoking: 'non-renseigne',
            alcohol: 'non-renseigne'
          };

          await storage.createUser(newProfile);
          imported++;
          console.log(`✅ Profil importé: ${newProfile.firstName}`);
        } catch (err) {
          console.log('Erreur import profil:', err);
          // Continue avec les autres profils
        }
      }

      res.json({ 
        message: `${imported} profils importés avec succès`,
        imported: imported,
        total: profiles.length 
      });
    } catch (error) {
      console.error('Erreur upload profils:', error);
      res.status(500).json({ message: 'Erreur lors de l\'import des profils' });
    }
  });

  // Import direct backup permanent sans auth
  app.get('/api/import-backup-now', async (req, res) => {
    try {
      const backupData = JSON.parse(fs.readFileSync('backup-profiles-permanent.json', 'utf8'));
      
      let imported = 0;
      let errors = 0;
      
      for (const profile of backupData) {
        try {
          await storage.createUser({
            firstName: profile.firstName,
            gender: profile.gender,
            age: profile.age,
            city: profile.city,
            bio: profile.bio,
            interests: profile.interests,
            photo: profile.photo,
            subscription: profile.subscription,
            email: profile.email,
            dailyFlashesUsed: 0,
            lastFlashReset: new Date(),
            isTestProfile: false,
            referralCode: null,
            referredById: null,
            bonusFlashes: 0,
            subscriptionEndDate: null,
            lookingFor: 'relation-serieuse',
            height: null,
            profession: null,
            children: 'non-renseigne',
            smoking: 'non-renseigne',
            alcohol: 'non-renseigne'
          });
          imported++;
        } catch (err) {
          errors++;
        }
      }
      res.json({ imported, total: backupData.length, errors });
    } catch (error) {
      console.error('Import error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Restaurer le backup permanent
  app.get('/api/admin/restore-permanent', async (req, res) => {
    try {
      const fs = require('fs');
      const path = require('path');
      const backupPath = path.join(process.cwd(), 'backup-profiles-permanent.json');
      
      if (!fs.existsSync(backupPath)) {
        return res.status(404).json({ message: 'Fichier backup introuvable' });
      }
      
      const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
      let imported = 0;
      
      for (const profile of backupData) {
        try {
          const newProfile = {
            firstName: profile.firstName || 'Anonyme',
            gender: profile.gender || 'F',
            age: profile.age || 45,
            city: profile.city || 'Paris',
            bio: profile.bio || 'Bio à compléter',
            interests: Array.isArray(profile.interests) ? profile.interests : ['Voyages'],
            photo: profile.photo || `https://randomuser.me/api/portraits/${profile.gender === 'H' ? 'men' : 'women'}/${Math.floor(Math.random() * 99) + 1}.jpg`,
            subscription: profile.subscription || 'gratuit',
            email: profile.email || `${profile.firstName?.toLowerCase() || 'user'}${Math.floor(Math.random() * 1000)}@example.com`,
            dailyFlashesUsed: 0,
            lastFlashReset: new Date(),
            isTestProfile: false,
            referralCode: null,
            referredById: null,
            bonusFlashes: 0,
            subscriptionEndDate: null,
            lookingFor: 'relation-serieuse',
            height: null,
            profession: null,
            children: 'non-renseigne',
            smoking: 'non-renseigne',
            alcohol: 'non-renseigne'
          };

          await storage.createUser(newProfile);
          imported++;
        } catch (err) {
          console.log('Erreur import profil:', err);
        }
      }

      res.json({ 
        message: `${imported} profils restaurés avec succès`,
        imported: imported,
        total: backupData.length 
      });
    } catch (error) {
      console.error('Erreur restauration:', error);
      res.status(500).json({ message: 'Erreur lors de la restauration' });
    }
  });

  // Admin routes - Update user profile (for admin editing)
  app.put("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      // Valider les données
      if (updates.age && (isNaN(updates.age) || updates.age < 40 || updates.age > 75)) {
        return res.status(400).json({ message: "Âge invalide (40-75 ans)" });
      }
      
      const updatedUser = await storage.updateUser(userId, updates);
      if (updatedUser) {
        res.json(updatedUser);
      } else {
        res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    } catch (error) {
      console.error("Erreur mise à jour utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Admin routes - Reset all subscriptions to gratuit
  app.post("/api/admin/reset-subscriptions", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      let updated = 0;
      
      for (const user of users) {
        if (user.subscription !== 'gratuit') {
          await storage.updateUserSubscription(user.id, 'gratuit');
          updated++;
        }
      }
      
      res.json({ message: `${updated} abonnements réinitialisés`, updated });
    } catch (error) {
      console.error("Erreur reset abonnements:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Admin routes - Upgrade user subscription
  app.post("/api/admin/users/:id/upgrade", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { subscription } = req.body;
      
      const updatedUser = await storage.updateUserSubscription(userId, subscription);
      if (updatedUser) {
        res.json(updatedUser);
      } else {
        res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    } catch (error) {
      console.error("Erreur upgrade utilisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get('/api/admin/backup', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      const backup = {
        version: '1.0',
        timestamp: new Date().toISOString(),
        data: {
          users: users.filter((u: any) => !u.isTestProfile)
        }
      };
      
      const backupJson = JSON.stringify(backup, null, 2);
      const filename = `date-mature-backup-${new Date().toISOString().split('T')[0]}.json`;
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Cache-Control', 'no-cache');
      res.status(200).send(backupJson);
    } catch (error) {
      console.error('Erreur lors de la création du backup:', error);
      res.status(500).json({ message: 'Erreur lors de la création du backup' });
    }
  });

  app.post('/api/admin/restore', async (req, res) => {
    try {
      const { backup } = req.body;
      
      if (!backup || !backup.data) {
        return res.status(400).json({ message: 'Format de backup invalide' });
      }
      
      let usersRestored = 0;
      
      // Restaurer les utilisateurs
      if (backup.data.users && Array.isArray(backup.data.users)) {
        for (const userData of backup.data.users) {
          try {
            await storage.createUser({
              ...userData,
              createdAt: new Date(userData.createdAt || Date.now())
            });
            usersRestored++;
          } catch (error) {
            console.error(`Erreur lors de la restauration de l'utilisateur ${userData.firstName}:`, error);
          }
        }
      }
      
      res.json({ 
        message: 'Données restaurées avec succès',
        usersRestored
      });
    } catch (error) {
      console.error('Erreur lors de la restauration:', error);
      res.status(500).json({ message: 'Erreur lors de la restauration' });
    }
  });

  // Restaurer les profils depuis le backup permanent (SANS authentification pour debug)
  app.post('/api/admin/restore-profiles', async (req, res) => {
    try {
      const { readFileSync, existsSync } = await import('fs');
      const { join } = await import('path');
      
      // Lire le fichier backup
      const backupPath = join(process.cwd(), 'backup-profiles-permanent.json');
      if (!existsSync(backupPath)) {
        return res.status(404).json({ message: 'Fichier backup non trouvé' });
      }
      
      const backupData = JSON.parse(readFileSync(backupPath, 'utf8'));
      let usersRestored = 0;
      let usersSkipped = 0;
      
      console.log(`[RESTORE] Tentative de restauration de ${backupData.length} profils`);
      
      // Restaurer chaque profil (éviter les doublons)
      for (const userData of backupData) {
        try {
          // Ignorer les profils sans nom valide
          if (!userData.firstName || userData.firstName.trim() === '') {
            usersSkipped++;
            continue;
          }
          
          const user = {
            firstName: userData.firstName || 'Anonyme',
            gender: userData.gender || 'F',
            age: userData.age || 50,
            city: userData.city || 'Paris',
            bio: userData.bio || '',
            interests: userData.interests || [],
            photo: userData.photo || '',
            subscription: userData.subscription || 'gratuit',
            email: userData.email || `${(userData.firstName || 'user').toLowerCase()}${userData.age || 50}@date-mature.test`,
            dailyFlashesUsed: 0,
            isTestProfile: false,
            referralCode: userData.referralCode || null,
            referredById: userData.referredById || null,
            bonusFlashes: 0,
            lookingForGender: 'both',
            lookingForAgeMin: 40,
            lookingForAgeMax: 75,
            lookingForDistance: 'same_region',
            lookingForRelationType: 'both',
            preferencesCompleted: false
          };
          
          await storage.createUser(user);
          usersRestored++;
          
          if (usersRestored % 50 === 0) {
            console.log(`[RESTORE] ${usersRestored} profils restaurés...`);
          }
        } catch (error) {
          console.error(`[RESTORE] Erreur ${userData.firstName}:`, error.message);
        }
      }
      
      console.log(`[RESTORE] Terminé: ${usersRestored} restaurés, ${usersSkipped} ignorés`);
      res.json({ 
        message: `${usersRestored} profils restaurés (${usersSkipped} déjà existants)`,
        usersRestored,
        usersSkipped
      });
    } catch (error) {
      console.error('[RESTORE] Erreur générale:', error);
      res.status(500).json({ message: 'Erreur lors de la restauration: ' + error.message });
    }
  });

  // Créer des profils féminins dans la région
  app.post('/api/admin/create-regional-profiles', async (req, res) => {
    try {
      const profiles = [
        {
          firstName: "Sophie",
          gender: "F" as const,
          age: 48,
          city: "Montpellier",
          bio: "Professeure à la retraite, j'aime la lecture, les voyages et les longues promenades. Recherche quelqu'un de sincère pour partager de beaux moments.",
          interests: ["Lecture", "Voyages", "Promenades", "Culture", "Théâtre"],
          photo: "https://randomuser.me/api/portraits/women/65.jpg",
          subscription: "gratuit" as const,
          email: "sophie.martin@example.com",
          flashsRemaining: 3,
          isTestProfile: false
        },
        {
          firstName: "Isabelle",
          gender: "F" as const,
          age: 55,
          city: "Palavas-les-Flots",
          bio: "Passionnée par la mer et la nature. Artiste peintre, j'adore capturer la beauté du littoral méditerranéen. Cherche un compagnon pour partager cette passion.",
          interests: ["Peinture", "Mer", "Nature", "Art", "Promenades"],
          photo: "https://randomuser.me/api/portraits/women/70.jpg",
          subscription: "premium" as const,
          email: "isabelle.durand@example.com",
          flashsRemaining: 20,
          isTestProfile: false
        },
        {
          firstName: "Catherine",
          gender: "F" as const,
          age: 51,
          city: "Béziers",
          bio: "Ancienne infirmière, maman de grands enfants. J'apprécie les moments simples, la cuisine et les sorties culturelles. À la recherche d'une relation sérieuse.",
          interests: ["Cuisine", "Culture", "Famille", "Jardinage", "Cinéma"],
          photo: "https://randomuser.me/api/portraits/women/55.jpg",
          subscription: "gratuit" as const,
          email: "catherine.bernard@example.com",
          flashsRemaining: 3,
          isTestProfile: false
        },
        {
          firstName: "Marie-Claire",
          gender: "F" as const,
          age: 59,
          city: "Nîmes",
          bio: "Retraitée active, j'adore découvrir de nouveaux endroits et rencontrer des gens intéressants. Passionnée d'histoire et de patrimoine local.",
          interests: ["Histoire", "Patrimoine", "Voyages", "Découvertes", "Culture"],
          photo: "https://randomuser.me/api/portraits/women/60.jpg",
          subscription: "gratuit" as const,
          email: "marieclaire.garcia@example.com",
          flashsRemaining: 3,
          isTestProfile: false
        },
        {
          firstName: "Francine",
          gender: "F" as const,
          age: 46,
          city: "Alès",
          bio: "Travailleuse sociale, j'aime aider les autres et m'impliquer dans ma communauté. Recherche un homme bienveillant et authentique.",
          interests: ["Solidarité", "Lecture", "Randonnée", "Musique", "Bénévolat"],
          photo: "https://randomuser.me/api/portraits/women/45.jpg",
          subscription: "gratuit" as const,
          email: "francine.lopez@example.com",
          flashsRemaining: 3,
          isTestProfile: false
        }
      ];

      const createdUsers = [];
      for (const profileData of profiles) {
        try {
          const user = await storage.createUser(profileData);
          createdUsers.push(user);
        } catch (error) {
          console.error(`Erreur création profil ${profileData.firstName}:`, error);
        }
      }
      
      res.json({ 
        message: `${createdUsers.length} profils féminins créés avec succès`,
        users: createdUsers
      });
    } catch (error) {
      console.error('Erreur lors de la création des profils régionaux:', error);
      res.status(500).json({ message: 'Erreur lors de la création des profils' });
    }
  });

  // Créer des profils dans une ville spécifique
  app.post('/api/admin/create-city-profiles', async (req, res) => {
    try {
      const { city, count = 10 } = req.body;
      
      if (!city) {
        return res.status(400).json({ message: 'Ville requise' });
      }

      const femaleNames = [
        "Marie", "Anne", "Françoise", "Monique", "Catherine", "Sylvie", "Martine", "Brigitte", 
        "Nicole", "Christine", "Isabelle", "Chantal", "Jacqueline", "Dominique", "Patricia",
        "Véronique", "Nathalie", "Corinne", "Danielle", "Sandrine", "Valérie", "Karine"
      ];

      const lastNames = [
        "Martin", "Bernard", "Thomas", "Petit", "Robert", "Richard", "Durand", "Dubois",
        "Moreau", "Laurent", "Simon", "Michel", "Lefebvre", "Leroy", "Roux", "David",
        "Bertrand", "Morel", "Fournier", "Girard", "Bonnet", "Dupont"
      ];

      const bios = [
        "Retraitée dynamique, j'aime la vie et les rencontres authentiques. Passionnée de lecture et de jardinage.",
        "Ancienne enseignante, je cherche un compagnon pour partager des moments simples et sincères.",
        "Maman de grands enfants, j'apprécie la nature, les balades et les discussions profondes.",
        "Artiste dans l'âme, j'adore la peinture et la musique. Recherche quelqu'un de créatif et bienveillant.",
        "Passionnée de voyages et de découvertes, je souhaite rencontrer un homme curieux et ouvert.",
        "Ancienne infirmière, j'aime aider les autres. Cherche une relation basée sur la complicité et le respect.",
        "Adepte de cuisine et de convivialité, je rêve de partager de bons moments autour d'une table.",
        "Sportive et nature, j'apprécie les randonnées et les activités en plein air. Qui pour m'accompagner ?"
      ];

      const interestsList = [
        ["Lecture", "Jardinage", "Cuisine", "Promenades"],
        ["Voyages", "Culture", "Théâtre", "Musique"],
        ["Nature", "Randonnée", "Photographie", "Art"],
        ["Cuisine", "Famille", "Cinéma", "Lectures"],
        ["Peinture", "Musique", "Danse", "Créativité"],
        ["Sport", "Nature", "Bien-être", "Yoga"],
        ["Histoire", "Patrimoine", "Découvertes", "Culture"],
        ["Bénévolat", "Solidarité", "Lecture", "Musique"]
      ];

      const createdUsers = [];
      
      for (let i = 0; i < Math.min(count, 15); i++) {
        try {
          const firstName = femaleNames[Math.floor(Math.random() * femaleNames.length)];
          const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
          const age = Math.floor(Math.random() * 30) + 45; // 45-75 ans
          const bio = bios[Math.floor(Math.random() * bios.length)];
          const interests = interestsList[Math.floor(Math.random() * interestsList.length)];
          const subscription = Math.random() > 0.8 ? "premium" : "gratuit"; // 20% premium
          const photoId = Math.floor(Math.random() * 30) + 45;

          const profileData = {
            firstName,
            gender: "F" as const,
            age,
            city,
            bio,
            interests,
            photo: `https://randomuser.me/api/portraits/women/${photoId}.jpg`,
            subscription: subscription as "gratuit" | "premium",
            email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
            flashsRemaining: subscription === "premium" ? 20 : 3,
            isTestProfile: false
          };

          const user = await storage.createUser(profileData);
          createdUsers.push(user);
        } catch (error) {
          console.error(`Erreur création profil ${i + 1}:`, error);
        }
      }
      
      res.json({ 
        message: `${createdUsers.length} profils créés à ${city}`,
        users: createdUsers,
        city
      });
    } catch (error) {
      console.error('Erreur lors de la création des profils par ville:', error);
      res.status(500).json({ message: 'Erreur lors de la création des profils' });
    }
  });

  return httpServer;
}
