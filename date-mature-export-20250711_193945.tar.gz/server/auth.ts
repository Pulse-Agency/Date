import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import { storage } from './storage';
import type { User } from '@shared/schema';

// Configuration Google OAuth
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: "/api/auth/google/callback"
  },
  async (accessToken, refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      if (!email) {
        return done(new Error('Aucun email trouvé dans le profil Google'));
      }

      // Vérifier si l'utilisateur existe déjà
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Créer un nouvel utilisateur
        const firstName = profile.name?.givenName || 'Utilisateur';
        const lastName = profile.name?.familyName || '';
        const fullName = lastName ? `${firstName} ${lastName}` : firstName;
        
        user = await storage.createUser({
          email: email,
          firstName: fullName,
          age: 60, // Age par défaut, sera modifié lors de l'onboarding
          city: "Paris", // Ville par défaut
          bio: "Nouveau membre inscrit via Google",
          interests: [],
          subscription: "gratuit",
          photo: profile.photos?.[0]?.value || undefined,
          isTestProfile: false
        });
      }

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));
}

// Configuration Facebook OAuth
if (process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET) {
  passport.use(new FacebookStrategy({
    clientID: process.env.FACEBOOK_APP_ID,
    clientSecret: process.env.FACEBOOK_APP_SECRET,
    callbackURL: "/api/auth/facebook/callback",
    profileFields: ['id', 'emails', 'name', 'photos']
  },
  async (accessToken, refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      if (!email) {
        return done(new Error('Aucun email trouvé dans le profil Facebook'));
      }

      // Vérifier si l'utilisateur existe déjà
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Créer un nouvel utilisateur
        const firstName = profile.name?.givenName || 'Utilisateur';
        const lastName = profile.name?.familyName || '';
        const fullName = lastName ? `${firstName} ${lastName}` : firstName;
        
        user = await storage.createUser({
          email: email,
          firstName: fullName,
          age: 60, // Age par défaut
          city: "Paris", // Ville par défaut
          bio: "Nouveau membre inscrit via Facebook",
          interests: [],
          subscription: "gratuit",
          photo: profile.photos?.[0]?.value || undefined,
          isTestProfile: false
        });
      }

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));
}

// Sérialisation des utilisateurs pour les sessions
passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (error) {
    done(error);
  }
});

export default passport;