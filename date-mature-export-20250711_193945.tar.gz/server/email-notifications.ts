interface EmailNotificationData {
  to: string;
  firstName: string;
  subject: string;
  htmlContent: string;
  textContent: string;
}

interface FlashNotificationData {
  receiverEmail: string;
  receiverFirstName: string;
  senderName: string;
  senderAge: number;
  senderCity: string;
  additionalCount: number;
}

interface MatchNotificationData {
  userEmail: string;
  userFirstName: string;
  matchName: string;
  matchAge: number;
  matchCity: string;
}

interface DailyDigestData {
  userEmail: string;
  userFirstName: string;
  newFlashes: number;
  newVisits: number;
  newMatches: number;
  suggestedProfiles: Array<{
    name: string;
    age: number;
    city: string;
  }>;
}

interface DiscountEmailData {
  userEmail: string;
  userFirstName: string;
  discountCode: string;
  discountPercent: number;
  plan: 'premium' | 'gold';
}

interface DownsellEmailData {
  userEmail: string;
  userFirstName: string;
  originalPlan: 'premium' | 'gold';
  monthlyPrice: number;
  annualSavings: string;
}

interface PaymentConfirmationData {
  userEmail: string;
  userFirstName: string;
  plan: 'premium' | 'gold';
  billingType: 'monthly' | 'annual';
  amount: number;
  expiresAt: Date;
}

interface FlashBonusConfirmationData {
  userEmail: string;
  userFirstName: string;
  plan: 'premium' | 'gold';
  bonusType: 'flash_pack' | 'super_flash' | 'mise_en_avant';
  amount: number;
  flashsAdded?: number;
  durationHours?: number;
}

export class EmailNotificationService {
  private mailerliteApiKey: string | undefined;
  private mailersendApiKey: string | undefined;

  constructor() {
    this.mailerliteApiKey = process.env.MAILERLITE_API_KEY;
    this.mailersendApiKey = process.env.MAILERSEND_API_KEY;
    
    if (!this.mailerliteApiKey) {
      console.warn('⚠️ MAILERLITE_API_KEY non configurée - segmentation désactivée');
    } else {
      console.log('✅ Service MailerLite (segmentation) initialisé');
    }

    // MailerSend désactivé - compte refusé pour activité commerciale
    this.mailersendApiKey = undefined;
    console.log('ℹ️  MailerSend désactivé - utilisation de MailerLite uniquement');
  }

  // Ajouter un subscriber à un groupe MailerLite spécifique
  private async addToMailerLiteGroup(email: string, firstName: string, groupName: string): Promise<boolean> {
    if (!this.mailerliteApiKey) {
      console.warn("MailerLite API key not configured");
      return false;
    }

    try {
      // D'abord créer/mettre à jour le subscriber
      const subscriberResponse = await fetch('https://connect.mailerlite.com/api/subscribers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.mailerliteApiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          fields: {
            name: firstName
          }
        })
      });

      if (subscriberResponse.ok || subscriberResponse.status === 422) {
        // 422 = déjà existant, c'est OK
        
        // Récupérer les groupes pour trouver l'ID du groupe correspondant
        const groupsResponse = await fetch('https://connect.mailerlite.com/api/groups', {
          headers: {
            'Authorization': `Bearer ${this.mailerliteApiKey}`,
            'Accept': 'application/json'
          }
        });

        if (groupsResponse.ok) {
          const groups = await groupsResponse.json();
          const targetGroup = groups.data.find((g: any) => g.name === groupName);
          
          if (targetGroup) {
            // Ajouter le subscriber au groupe
            const assignResponse = await fetch(`https://connect.mailerlite.com/api/subscribers/${email}/groups/${targetGroup.id}`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${this.mailerliteApiKey}`,
                'Accept': 'application/json'
              }
            });

            if (assignResponse.ok) {
              console.log(`[EMAIL] ✅ ${email} ajouté au groupe "${groupName}"`);
              return true;
            }
          } else {
            // Créer le groupe s'il n'existe pas
            console.log(`[EMAIL] Création du groupe "${groupName}" dans MailerLite`);
            const createGroupResponse = await fetch('https://connect.mailerlite.com/api/groups', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${this.mailerliteApiKey}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
              },
              body: JSON.stringify({
                name: groupName,
                type: 'default'
              })
            });

            if (createGroupResponse.ok) {
              const newGroup = await createGroupResponse.json();
              console.log(`[EMAIL] ✅ Groupe "${groupName}" créé avec succès`);
              
              // Maintenant ajouter le subscriber au nouveau groupe
              const assignResponse = await fetch(`https://connect.mailerlite.com/api/subscribers/${email}/groups/${newGroup.data.id}`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${this.mailerliteApiKey}`,
                  'Accept': 'application/json'
                }
              });

              if (assignResponse.ok) {
                console.log(`[EMAIL] ✅ ${email} ajouté au nouveau groupe "${groupName}"`);
                return true;
              }
            } else {
              console.error(`[EMAIL] Erreur création groupe "${groupName}":`, createGroupResponse.status);
            }
          }
        }
      }
    } catch (error) {
      console.error(`[EMAIL] Erreur ajout groupe ${groupName} pour ${email}:`, error);
    }
    
    return false;
  }

  // Segmentation MailerLite pour emails futurs
  private async sendTransactionalEmail(
    email: string, 
    firstName: string, 
    subject: string, 
    htmlContent: string, 
    textContent: string,
    tags: string[] = []
  ): Promise<boolean> {
    // Créer/mettre à jour le subscriber dans MailerLite avec tags
    await this.createSubscriberWithTags(email, firstName, tags);

    console.log(`[EMAIL] ✅ Contact segmenté pour ${email}`);
    console.log(`[EMAIL] 📝 Sujet préparé: ${subject}`);
    console.log(`[EMAIL] 🏷️ Tags: ${tags.join(', ')}`);
    console.log(`[EMAIL] 🎯 Prêt pour automations MailerLite`);
    
    return true;
  }





  // Créer des subscribers avec des groupes/tags pour automations MailerLite
  private async createSubscriberWithTags(email: string, firstName: string, tags: string[]): Promise<boolean> {
    if (!this.mailerliteApiKey) {
      console.warn("MailerLite API key not configured");
      return false;
    }

    try {
      const response = await fetch('https://connect.mailerlite.com/api/subscribers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.mailerliteApiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          fields: {
            name: firstName
          }
        })
      });

      if (response.ok || response.status === 422) {
        console.log(`[EMAIL] ✅ Subscriber ${email} créé/mis à jour dans MailerLite`);
        return true;
      }
    } catch (error) {
      console.error(`[EMAIL] Erreur MailerLite pour ${email}:`, error);
    }
    
    return false;
  }

  // Envoyer email via MailerSend API
  private async sendMailerSendEmail(to: string, subject: string, html: string, text: string): Promise<boolean> {
    if (!this.mailersendApiKey) {
      console.warn('MailerSend API key not configured');
      return false;
    }

    try {
      const emailPayload = {
        from: {
          email: 'noreply@date-mature.com',
          name: 'Date Mature'
        },
        to: [
          {
            email: to
          }
        ],
        subject: subject,
        html: html,
        text: text
      };

      const response = await fetch('https://api.mailersend.com/v1/email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.mailersendApiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify(emailPayload)
      });

      if (response.ok) {
        console.log('✅ Email envoyé avec succès via MailerSend');
        return true;
      } else {
        console.error('❌ Erreur MailerSend:', await response.text());
        return false;
      }
    } catch (error) {
      console.error('Erreur envoi email MailerSend:', error);
      return false;
    }
  }

  // Flash notification - envoi via MailerSend + segmentation MailerLite
  async sendFlashNotification(data: FlashNotificationData): Promise<boolean> {
    console.log('📧 Traitement notification flash:', data.receiverEmail);

    // 1. Segmentation MailerLite pour futures automations
    if (this.mailerliteApiKey) {
      const success = await this.createSubscriberWithTags(data.receiverEmail, data.receiverFirstName, ['flash_received']);
      if (success) {
        console.log('✅ Subscriber ajouté à MailerLite avec tag "flash_received"');
        console.log('ℹ️  Créez une automation MailerLite avec déclencheur "tag ajouté: flash_received"');
      }
      return success;
    }

    console.log('⚠️  MailerLite non configuré - segmentation ignorée');
    return false;
  }

  // Flash notification - méthode de fallback pour envoi direct (si pas d'automation)
  async sendFlashNotificationDirect(data: FlashNotificationData): Promise<boolean> {
    console.log(`[EMAIL] 💖 Flash notification: ${data.senderName} → ${data.receiverFirstName}`);
    
    const subject = `💕 ${data.senderName} vous a flashé sur Date Mature !`;
    
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <div style="background: linear-gradient(135deg, #f472b6, #ec4899); color: white; padding: 40px 30px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; font-weight: bold;">💕 Date Mature</h1>
          <p style="margin: 10px 0 0; font-size: 16px; opacity: 0.9;">Quelqu'un vous a flashé !</p>
        </div>
        
        <div style="padding: 40px 30px;">
          <h2 style="color: #333; margin: 0 0 20px; font-size: 24px;">Bonjour ${data.receiverFirstName} ! 👋</h2>
          
          <div style="background: #fdf2f8; border: 2px solid #f472b6; border-radius: 12px; padding: 25px; margin: 30px 0; text-align: center;">
            <div style="color: #be185d; font-size: 18px; font-weight: bold; margin-bottom: 15px;">
              💖 Nouveau flash reçu !
            </div>
            <div style="font-size: 20px; font-weight: bold; color: #9f1239; margin: 10px 0;">
              ${data.senderName}, ${data.senderAge} ans
            </div>
            <div style="color: #be185d; font-size: 16px;">
              📍 ${data.senderCity}
            </div>
            ${data.additionalCount > 0 ? `
              <div style="background: #fbbf24; color: #92400e; padding: 10px; border-radius: 8px; margin-top: 15px; font-weight: bold;">
                +${data.additionalCount} autre${data.additionalCount > 1 ? 's' : ''} vous ont aussi flashé !
              </div>
            ` : ''}
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://date-mature.com/profiles" 
               style="display: inline-block; background: linear-gradient(135deg, #f472b6, #ec4899); color: white; text-decoration: none; padding: 15px 30px; border-radius: 25px; font-weight: bold; font-size: 16px; box-shadow: 0 4px 15px rgba(244, 114, 182, 0.3);">
              💕 Voir qui vous a flashé
            </a>
          </div>
          
          <p style="color: #666; text-align: center; font-size: 14px; line-height: 1.6;">
            Connectez-vous pour découvrir tous vos admirateurs<br>
            et peut-être trouver votre âme sœur !
          </p>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px 30px; text-align: center; border-top: 1px solid #eee;">
          <p style="margin: 0; color: #999; font-size: 12px;">
            © 2025 Date Mature - L'amour n'attend pas
          </p>
        </div>
      </div>
    `;

    const textContent = `
Bonjour ${data.receiverFirstName} !

${data.senderName}, ${data.senderAge} ans de ${data.senderCity} vous a flashé sur Date Mature !

${data.additionalCount > 0 ? `+${data.additionalCount} autre${data.additionalCount > 1 ? 's' : ''} vous ont aussi flashé !` : ''}

Connectez-vous pour voir qui vous a flashé : https://date-mature.com/profiles

L'équipe Date Mature
    `;

    // Segmentation MailerLite uniquement
    return await this.createSubscriberWithTags(
      data.receiverEmail,
      data.receiverFirstName,
      ['flash_received', 'app_user']
    );
  }

  // Match notification - segmentation MailerLite uniquement
  async sendMatchNotification(data: MatchNotificationData): Promise<boolean> {
    try {
      if (!this.mailerliteApiKey) {
        console.warn('MailerLite API key not configured');
        return false;
      }

      console.log('📧 Traitement notification match:', data.userEmail);

      // Segmentation MailerLite uniquement
      const success = await this.createSubscriberWithTags(data.userEmail, data.userFirstName, ['match_created']);
      if (success) {
        console.log('✅ Subscriber ajouté à MailerLite avec tag "match_created"');
        console.log('ℹ️  Créez une automation MailerLite avec déclencheur "tag ajouté: match_created"');
      }
      return success;
    } catch (error) {
      console.error('Erreur match notification:', error);
      return false;
    }
  }

  // Match notification - méthode de fallback pour envoi direct (si pas d'automation)
  async sendMatchNotificationDirect(data: MatchNotificationData): Promise<boolean> {
    console.log(`[EMAIL] 🎉 Match notification: ${data.userFirstName} ↔ ${data.matchName}`);
    
    const subject = `🎉 C'est un match avec ${data.matchName} !`;
    
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <div style="background: linear-gradient(135deg, #f59e0b, #d97706); color: white; padding: 40px 30px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; font-weight: bold;">💕 Date Mature</h1>
          <p style="margin: 10px 0 0; font-size: 16px; opacity: 0.9;">C'est un match !</p>
        </div>
        
        <div style="padding: 40px 30px;">
          <h2 style="color: #333; margin: 0 0 20px; font-size: 24px;">Félicitations ${data.userFirstName} ! 🎊</h2>
          
          <div style="background: #fef3c7; border: 2px solid #f59e0b; border-radius: 12px; padding: 25px; margin: 30px 0; text-align: center;">
            <div style="color: #92400e; font-size: 18px; font-weight: bold; margin-bottom: 15px;">
              🎉 Nouveau match !
            </div>
            <div style="font-size: 20px; font-weight: bold; color: #78350f; margin: 10px 0;">
              ${data.matchName}, ${data.matchAge} ans
            </div>
            <div style="color: #92400e; font-size: 16px;">
              📍 ${data.matchCity}
            </div>
            <div style="background: #10b981; color: white; padding: 12px; border-radius: 8px; margin-top: 15px; font-weight: bold;">
              Vous vous êtes flashés mutuellement ! 💕
            </div>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://date-mature.com/messages" 
               style="display: inline-block; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; text-decoration: none; padding: 15px 30px; border-radius: 25px; font-weight: bold; font-size: 16px; box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);">
              💬 Commencer la conversation
            </a>
          </div>
          
          <div style="background: #f0f9ff; border: 1px solid #0ea5e9; border-radius: 8px; padding: 20px; margin: 30px 0;">
            <h4 style="margin: 0 0 10px; color: #0369a1; font-size: 16px;">💡 Conseils pour bien commencer</h4>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #075985; line-height: 1.6; font-size: 14px;">
              <li>Envoyez un message personnalisé et authentique</li>
              <li>Posez des questions sur ses centres d'intérêt</li>
              <li>Soyez patient(e) - les belles relations se construisent</li>
              <li>Restez respectueux(se) et bienveillant(e)</li>
            </ul>
          </div>
          
          <p style="color: #666; text-align: center; font-size: 14px; line-height: 1.6;">
            Votre match vous attend !<br>
            Connectez-vous pour commencer votre conversation.
          </p>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px 30px; text-align: center; border-top: 1px solid #eee;">
          <p style="margin: 0; color: #999; font-size: 12px;">
            © 2025 Date Mature - L'amour n'attend pas
          </p>
        </div>
      </div>
    `;

    const textContent = `
Félicitations ${data.userFirstName} !

C'est un match avec ${data.matchName}, ${data.matchAge} ans de ${data.matchCity} !

Vous vous êtes flashés mutuellement 💕

Commencez votre conversation dès maintenant : https://date-mature.com/messages

Conseils pour bien commencer :
- Envoyez un message personnalisé et authentique
- Posez des questions sur ses centres d'intérêt
- Soyez patient(e) - les belles relations se construisent

L'équipe Date Mature
    `;

    // Segmenter le contact pour automations futures
    return await this.createSubscriberWithTags(
      data.userEmail,
      data.userFirstName,
      ['new_match', 'app_user']
    );
  }

  // Daily digest - envoi d'email transactionnel avec recommandations
  async sendDailyDigest(data: DailyDigestData): Promise<boolean> {
    console.log(`[EMAIL] 📊 Daily digest: ${data.userFirstName} - ${data.newFlashes + data.newVisits + data.newMatches} activités`);
    
    const subject = `📊 Votre activité du jour sur Date Mature`;
    
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <div style="background: linear-gradient(135deg, #6366f1, #4f46e5); color: white; padding: 40px 30px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; font-weight: bold;">💕 Date Mature</h1>
          <p style="margin: 10px 0 0; font-size: 16px; opacity: 0.9;">Votre activité quotidienne</p>
        </div>
        
        <div style="padding: 40px 30px;">
          <h2 style="color: #333; margin: 0 0 20px; font-size: 24px;">Bonjour ${data.userFirstName} ! 👋</h2>
          
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 25px; margin: 30px 0;">
            <h3 style="margin: 0 0 15px; color: #334155; font-size: 18px;">📊 Votre activité d'aujourd'hui</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; text-align: center;">
              <div style="background: #fdf2f8; padding: 15px; border-radius: 8px; border: 1px solid #f9a8d4;">
                <div style="font-size: 24px; font-weight: bold; color: #be185d;">${data.newFlashes}</div>
                <div style="font-size: 12px; color: #9f1239;">Nouveaux flashs</div>
              </div>
              <div style="background: #f0f9ff; padding: 15px; border-radius: 8px; border: 1px solid #7dd3fc;">
                <div style="font-size: 24px; font-weight: bold; color: #0369a1;">${data.newVisits}</div>
                <div style="font-size: 12px; color: #075985;">Visites de profil</div>
              </div>
              <div style="background: #f0fdf4; padding: 15px; border-radius: 8px; border: 1px solid #86efac;">
                <div style="font-size: 24px; font-weight: bold; color: #059669;">${data.newMatches}</div>
                <div style="font-size: 12px; color: #047857;">Nouveaux matchs</div>
              </div>
            </div>
          </div>
          
          ${data.suggestedProfiles.length > 0 ? `
            <div style="background: #fefce8; border: 1px solid #fbbf24; border-radius: 12px; padding: 25px; margin: 30px 0;">
              <h3 style="margin: 0 0 20px; color: #92400e; font-size: 18px;">✨ Profils recommandés pour vous</h3>
              ${data.suggestedProfiles.map(profile => `
                <div style="background: white; border: 1px solid #fbbf24; border-radius: 8px; padding: 15px; margin: 10px 0; display: flex; align-items: center;">
                  <div style="flex: 1;">
                    <div style="font-weight: bold; color: #78350f; font-size: 16px;">${profile.name}, ${profile.age} ans</div>
                    <div style="color: #92400e; font-size: 14px;">📍 ${profile.city}</div>
                  </div>
                  <div style="background: #f59e0b; color: white; padding: 8px 15px; border-radius: 20px; font-size: 12px; font-weight: bold;">
                    💕 Compatible
                  </div>
                </div>
              `).join('')}
            </div>
          ` : ''}
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://date-mature.com/profiles" 
               style="display: inline-block; background: linear-gradient(135deg, #6366f1, #4f46e5); color: white; text-decoration: none; padding: 15px 30px; border-radius: 25px; font-weight: bold; font-size: 16px; box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);">
              🔍 Découvrir de nouveaux profils
            </a>
          </div>
          
          <div style="background: #f0f9ff; border: 1px solid #0ea5e9; border-radius: 8px; padding: 20px; margin: 30px 0;">
            <h4 style="margin: 0 0 10px; color: #0369a1; font-size: 16px;">💡 Conseils du jour</h4>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #075985; line-height: 1.6; font-size: 14px;">
              <li>Visitez les profils qui vous intéressent pour augmenter vos chances de match</li>
              <li>Envoyez des messages personnalisés à vos nouveaux matchs</li>
              <li>Complétez votre profil avec de nouvelles photos si besoin</li>
              <li>Restez actif(ve) - l'amour favorise les audacieux !</li>
            </ul>
          </div>
          
          <p style="color: #666; text-align: center; font-size: 14px; line-height: 1.6;">
            Continuez à explorer et à faire de belles rencontres !<br>
            Votre âme sœur vous attend peut-être.
          </p>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px 30px; text-align: center; border-top: 1px solid #eee;">
          <p style="margin: 0; color: #999; font-size: 12px;">
            © 2025 Date Mature - L'amour n'attend pas
          </p>
        </div>
      </div>
    `;

    const textContent = `
Bonjour ${data.userFirstName} !

Votre activité d'aujourd'hui sur Date Mature :
- ${data.newFlashes} nouveaux flashs reçus
- ${data.newVisits} visites de votre profil
- ${data.newMatches} nouveaux matchs

${data.suggestedProfiles.length > 0 ? `
Profils recommandés pour vous :
${data.suggestedProfiles.map(profile => `- ${profile.name}, ${profile.age} ans de ${profile.city}`).join('\n')}
` : ''}

Découvrez de nouveaux profils : https://date-mature.com/profiles

Conseils du jour :
- Visitez les profils qui vous intéressent
- Envoyez des messages personnalisés à vos matchs
- Restez actif(ve) pour maximiser vos chances

L'équipe Date Mature
    `;

    return await this.createSubscriberWithTags(
      data.userEmail,
      data.userFirstName,
      ['daily_digest', 'app_user']
    );
  }

  // Inscription Premium/Gold - ajouter aux groupes MailerLite correspondants
  async notifyPremiumUpgrade(email: string, firstName: string, subscriptionType: 'premium' | 'gold'): Promise<boolean> {
    console.log(`[EMAIL] 💎 Upgrade notification: ${firstName} → ${subscriptionType.toUpperCase()}`);
    
    // Ajouter au groupe correspondant dans MailerLite
    const groupName = subscriptionType === 'premium' ? 'Premium subscribers' : 'Gold subscribers';
    const success = await this.addToMailerLiteGroup(email, firstName, groupName);

    if (success) {
      console.log(`[EMAIL] ✅ Utilisateur ajouté au groupe ${groupName} - automation de bienvenue déclenchée`);
    }

    return success;
  }

  // Newsletter signup - ajouter au groupe Newsletter prospects
  async addToNewsletter(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 📰 Newsletter signup: ${firstName}`);
    
    // Ajouter au groupe "Newsletter prospects (popup)" dans MailerLite
    const success = await this.addToMailerLiteGroup(email, firstName, "Newsletter prospects (popup)");

    if (success) {
      console.log(`[EMAIL] ✅ Subscriber ajouté au groupe Newsletter prospects - automation déclenchée`);
    }

    return success;
  }

  // Ajouter un utilisateur au groupe "Membres actifs" lors de l'inscription
  async addToActiveMembers(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 👤 New user registration: ${firstName} (${email})`);
    
    const success = await this.addToMailerLiteGroup(email, firstName, "Membres actifs (utilisateurs inscrits)");

    if (success) {
      console.log(`[EMAIL] ✅ Nouvel utilisateur ajouté au groupe Membres actifs`);
    }

    return success;
  }

  // Ajouter un utilisateur qui télécharge l'ebook (depuis Instagram/Facebook)
  async addToEbookDownloaders(email: string, firstName: string): Promise<boolean> {
    console.log(`[EMAIL] 📖 Ebook download: ${firstName} (${email})`);
    
    // Vous pouvez créer un groupe "Ebook downloaders" dans MailerLite pour cette automation
    // Pour l'instant, on l'ajoute au groupe Newsletter prospects
    const success = await this.addToMailerLiteGroup(email, firstName, "Newsletter prospects (popup)");
    
    if (success) {
      console.log(`[EMAIL] ✅ Téléchargeur ebook ajouté aux prospects newsletter`);
    }

    return success;
  }

  // Envoyer un email de récupération de panier abandonné avec code promo
  async sendDiscountEmail(data: DiscountEmailData): Promise<boolean> {
    console.log(`[EMAIL] 🛒 Discount email: ${data.userFirstName} (${data.discountPercent}% off ${data.plan})`);
    
    const planName = data.plan === 'premium' ? 'Premium' : 'Gold';
    const originalPrice = data.plan === 'premium' ? '60€' : '228€';
    const newPrice = data.plan === 'premium' ? '54€' : '182€';
    
    // Créer le subscriber avec tags spéciaux pour automation
    const success = await this.createSubscriberWithTags(data.userEmail, data.userFirstName, [
      'abandoned_cart_discount',
      `discount_${data.plan}`,
      `discount_${data.discountPercent}pct`
    ]);
    
    if (success) {
      console.log(`[EMAIL] ✅ Email récupération panier envoyé avec code ${data.discountCode}`);
      
      // Optionnel : ajouter à un groupe spécifique "Panier abandonné"
      await this.addToMailerLiteGroup(data.userEmail, data.userFirstName, "Panier abandonné");
    }

    return success;
  }

  async sendPaymentConfirmation(data: PaymentConfirmationData): Promise<boolean> {
    if (!this.mailerliteApiKey) {
      console.error('MailerLite API key manquante');
      return false;
    }

    const planName = data.plan === 'premium' ? 'Premium' : 'Gold';
    const billingText = data.billingType === 'monthly' ? 'mensuel' : 'annuel';
    const nextBillingDate = data.expiresAt.toLocaleDateString('fr-FR');

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <div style="background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 40px 30px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; font-weight: bold;">💕 Date Mature</h1>
          <p style="margin: 10px 0 0; font-size: 16px; opacity: 0.9;">Confirmation de votre abonnement</p>
        </div>
        
        <div style="padding: 40px 30px;">
          <h2 style="color: #333; margin: 0 0 20px; font-size: 24px;">Merci ${data.userFirstName} ! 🎉</h2>
          
          <div style="background: #f0fdf4; border: 2px solid #10b981; border-radius: 12px; padding: 25px; margin: 30px 0; text-align: center;">
            <div style="color: #059669; font-size: 18px; font-weight: bold; margin-bottom: 10px;">
              ✅ Paiement confirmé
            </div>
            <div style="font-size: 24px; font-weight: bold; color: #065f46; margin: 10px 0;">
              Abonnement ${planName}
            </div>
            <div style="color: #047857; font-size: 16px;">
              ${data.amount}€ - Facturation ${billingText}
            </div>
          </div>
          
          <div style="background: #fff7ed; border: 1px solid #fb923c; border-radius: 8px; padding: 20px; margin: 30px 0;">
            <h3 style="margin: 0 0 15px; color: #ea580c; font-size: 18px;">🎯 Vos avantages maintenant actifs</h3>
            ${data.plan === 'premium' ? `
              <ul style="margin: 0; padding: 0 0 0 20px; color: #9a3412; line-height: 1.8;">
                <li><strong>20 flashs par jour</strong> au lieu de 3</li>
                <li><strong>Voir qui vous a flashé</strong></li>
                <li><strong>Support client prioritaire</strong></li>
                <li><strong>Filtres de recherche avancés</strong></li>
              </ul>
            ` : `
              <ul style="margin: 0; padding: 0 0 0 20px; color: #9a3412; line-height: 1.8;">
                <li><strong>Flashs illimités</strong></li>
                <li><strong>Messages illimités</strong></li>
                <li><strong>Profil en avant</strong> dans les recherches</li>
                <li><strong>Mode incognito</strong></li>
                <li><strong>Badge exclusif</strong> sur votre profil</li>
              </ul>
            `}
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://date-mature.com/" 
               style="display: inline-block; background: linear-gradient(135deg, #10b981, #059669); color: white; text-decoration: none; padding: 15px 30px; border-radius: 25px; font-weight: bold; font-size: 16px; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);">
              🚀 Commencer à explorer
            </a>
          </div>
          
          <div style="background: #f8fafc; border-radius: 8px; padding: 20px; margin: 30px 0;">
            <h4 style="margin: 0 0 10px; color: #334155; font-size: 16px;">📅 Détails de facturation</h4>
            <div style="color: #64748b; line-height: 1.6; font-size: 14px;">
              • Prochain prélèvement : ${nextBillingDate}<br>
              • Montant : ${data.amount}€<br>
              • Résiliation possible à tout moment depuis vos paramètres
            </div>
          </div>
          
          <div style="background: #fef7ff; border: 1px solid #d8b4fe; border-radius: 8px; padding: 20px; margin: 30px 0;">
            <h4 style="margin: 0 0 10px; color: #7c3aed; font-size: 16px;">💡 Conseils pour bien commencer</h4>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #6b21a8; line-height: 1.6; font-size: 14px;">
              <li>Complétez votre profil avec une belle photo</li>
              <li>Rédigez une bio authentique et chaleureuse</li>
              <li>Commencez à flasher les profils qui vous plaisent</li>
              <li>Soyez patient(e) - les belles rencontres prennent du temps</li>
            </ul>
          </div>
          
          <p style="color: #999; font-size: 14px; line-height: 1.6; margin: 30px 0 0; text-align: center;">
            Des questions ? Notre équipe est là pour vous aider.<br>
            Répondez à cet email ou contactez-nous depuis l'application.
          </p>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px 30px; text-align: center; border-top: 1px solid #eee;">
          <p style="margin: 0; color: #999; font-size: 12px;">
            © 2025 Date Mature - L'amour n'attend pas
          </p>
        </div>
      </div>
    `;

    const textContent = `
Merci ${data.userFirstName} !

Votre paiement a été confirmé avec succès.

Abonnement ${planName} activé
${data.amount}€ - Facturation ${billingText}

Vos avantages sont maintenant actifs :
${data.plan === 'premium' ? `
- 20 flashs par jour au lieu de 3
- Voir qui vous a flashé
- Support client prioritaire
- Filtres de recherche avancés
` : `
- Flashs illimités
- Messages illimités
- Profil en avant dans les recherches
- Mode incognito
- Badge exclusif sur votre profil
`}

Prochain prélèvement : ${nextBillingDate}

Commencez dès maintenant : https://date-mature.com/

L'équipe Date Mature
    `;

    const subject = `✅ Confirmation de votre abonnement ${planName} - Date Mature`;

    // Segmenter pour emails futurs et ajouter au groupe
    await this.createSubscriberWithTags(
      data.userEmail,
      data.userFirstName,
      [
        'payment_confirmed',
        `${data.plan}_subscriber`,
        `billing_${data.billingType}`,
        'active_member'
      ]
    );
    
    // Ajouter automatiquement au groupe Premium/Gold dans MailerLite
    const groupName = data.plan === 'premium' ? 'Premium' : 'Gold';
    await this.addToMailerLiteGroup(data.userEmail, data.userFirstName, groupName);
    console.log(`[EMAIL] ✅ Client ajouté au groupe ${groupName} dans MailerLite`);
    console.log(`[EMAIL] ✅ Email confirmation paiement préparé pour ${planName} ${billingText}`);
    
    return true;
  }
}

export const emailService = new EmailNotificationService();