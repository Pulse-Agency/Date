import { pgTable, text, serial, integer, boolean, timestamp, json, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firstName: text("firstName").notNull(),
  gender: text("gender").$type<"H" | "F">().notNull(),
  age: integer("age").notNull(),
  city: text("city").notNull(),
  region: text("region"), // Région française (ajouté le 7 juillet 2025)
  bio: text("bio"),
  interests: json("interests").$type<string[]>().default([]).notNull(),
  photos: json("photos").$type<string[]>().default([]).notNull(),
  subscription: text("subscription").$type<"gratuit" | "premium" | "gold">().default("gratuit").notNull(),
  email: text("email"),
  dailyFlashesUsed: integer("dailyFlashesUsed").default(0).notNull(),
  lastFlashReset: timestamp("lastFlashReset").defaultNow().notNull(),
  isTestProfile: boolean("isTestProfile").default(false).notNull(),
  // Système de parrainage
  referralCode: text("referralCode").unique(), // Code unique pour inviter d'autres
  referredById: integer("referredById"), // ID du parrain
  bonusFlashes: integer("bonusFlashes").default(0).notNull(), // Flashes bonus gagnés
  subscriptionEndDate: timestamp("subscriptionEndDate"), // Date de fin d'abonnement gratuit
  // Préférences de recherche
  lookingForGender: text("lookingForGender").$type<"H" | "F" | "both">().default("both"),
  lookingForAgeMin: integer("lookingForAgeMin").default(40),
  lookingForAgeMax: integer("lookingForAgeMax").default(75),
  lookingForDistance: text("lookingForDistance").$type<"same_city" | "same_region" | "anywhere">().default("same_region"),
  lookingForRelationType: text("lookingForRelationType").$type<"serious" | "friendship" | "both">().default("both"),
  preferencesCompleted: boolean("preferencesCompleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const flashes = pgTable("flashes", {
  id: serial("id").primaryKey(),
  fromUserId: integer("fromUserId").notNull(),
  toUserId: integer("toUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  user1Id: integer("user1Id").notNull(),
  user2Id: integer("user2Id").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("senderId").notNull(),
  receiverId: integer("receiverId").notNull(),
  content: text("content").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  type: text("type").$type<"match" | "message" | "flash_reminder" | "referral_bonus">().notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrerId").notNull(), // Celui qui parraine
  referredId: integer("referredId").notNull(), // Celui qui est parrainé
  status: text("status").$type<"pending" | "completed" | "rewarded">().default("pending").notNull(),
  rewardType: text("rewardType").$type<"bonus_flashes" | "free_month" | "free_premium">().notNull(),
  rewardAmount: integer("rewardAmount").default(0).notNull(), // Nombre de flashes ou jours gratuits
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"), // Quand le filleul a créé son profil
  rewardedAt: timestamp("rewardedAt"), // Quand la récompense a été donnée
});

export const abandonedCarts = pgTable("abandonedCarts", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  plan: text("plan").$type<"premium" | "gold">().notNull(),
  billingType: text("billingType").$type<"monthly" | "annual">().default("annual").notNull(),
  originalPrice: integer("originalPrice").notNull(), // Prix en centimes
  discountOffered: boolean("discountOffered").default(false).notNull(),
  discountUsed: boolean("discountUsed").default(false).notNull(),
  discountCode: text("discountCode"), // Code promo généré
  downsellOffered: boolean("downsellOffered").default(false).notNull(),
  downsellAccepted: boolean("downsellAccepted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastReminderSent: timestamp("lastReminderSent"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  dailyFlashesUsed: true,
  lastFlashReset: true,
}).extend({
  age: z.number().min(40, "L'âge minimum est 40 ans").max(75, "L'âge maximum est 75 ans"),
  bio: z.string().max(300, "La bio ne peut pas dépasser 300 caractères").optional(),
});

export const insertFlashSchema = createInsertSchema(flashes).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  isRead: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
});

export const insertAbandonedCartSchema = createInsertSchema(abandonedCarts).omit({
  id: true,
  createdAt: true,
});

// Table pour métriques quotidiennes agrégées  
export const dailyMetrics = pgTable("daily_metrics", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  newUsers: integer("new_users").default(0),
  activeUsers: integer("active_users").default(0),
  totalLogins: integer("total_logins").default(0),
  pageViews: integer("page_views").default(0),
  newFlashes: integer("new_flashes").default(0),
  newMatches: integer("new_matches").default(0),
  newMessages: integer("new_messages").default(0),
  newSubscriptions: integer("new_subscriptions").default(0),
  newsletterSignups: integer("newsletter_signups").default(0),
});

// Table pour activités utilisateur simplifiée
export const userActivities = pgTable("user_activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  activityType: text("activity_type").notNull(), // 'registration', 'login', 'flash', 'match', 'message', 'subscription'
  details: text("details"), // JSON string pour détails spécifiques
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertDailyMetricsSchema = createInsertSchema(dailyMetrics);
export const insertUserActivitySchema = createInsertSchema(userActivities);

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Flash = typeof flashes.$inferSelect;
export type InsertFlash = z.infer<typeof insertFlashSchema>;
export type Match = typeof matches.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Notification = typeof notifications.$inferSelect;
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type AbandonedCart = typeof abandonedCarts.$inferSelect;
export type InsertAbandonedCart = z.infer<typeof insertAbandonedCartSchema>;
export type UserActivity = typeof userActivities.$inferSelect;
export type InsertUserActivity = z.infer<typeof insertUserActivitySchema>;
export type DailyMetrics = typeof dailyMetrics.$inferSelect;
export type InsertDailyMetrics = z.infer<typeof insertDailyMetricsSchema>;
